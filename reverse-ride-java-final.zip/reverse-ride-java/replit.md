# ReverseRide

ReverseRide is a fair mobility marketplace where passengers define the ride and drivers compete with transparent, trust-aware bids.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)
- Java 21 domain core in `java-core/` for ride rules, bid validation, value scoring, and driver-safe pricing

## Where things live

- `artifacts/reverseride/` — the public website and passenger/driver experiences
- `artifacts/api-server/` — API adapter and persistence routes
- `lib/api-spec/openapi.yaml` — source of truth for typed API contracts
- `lib/db/src/schema/` — PostgreSQL schema
- `java-core/` — Java domain model and marketplace scoring rules

## Architecture decisions

- No records are seeded; empty database states are intentional until real passenger or driver data is submitted.
- The marketplace ranks value using more than lowest price: ETA, rating, completion, and trust all contribute.
- Fare displays use Indian rupees to match the product brief.
- Java owns the core mobility rules; the current shared API adapter exposes the typed web contract and database until the Java service is wired as the deployable server.

## Product

The website supports passenger ride requests, timed reverse auctions, bid comparison and acceptance, recurring commutes, driver demand radar, fare explanations, safety event viewing, and two-sided trust surfaces. The backend persists rides, bids, and commutes in PostgreSQL.

## User preferences

- Use Java as the main domain language.
- Do not add demo data; only display records submitted through the product.

## Gotchas

_Populate as you build — sharp edges, "always run X before Y" rules._

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
