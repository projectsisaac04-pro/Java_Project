#!/usr/bin/env bash
set -euo pipefail

export DATABASE_URL="${DATABASE_URL:-postgresql://postgres:postgres@localhost:5432/reverseride}"

echo "Using database: ${DATABASE_URL%%@*}@..."
echo "Preparing database tables..."
pnpm --filter @workspace/db run push

cleanup() {
  echo
  echo "Stopping ReverseRide..."
  kill "${API_PID:-}" "${WEB_PID:-}" 2>/dev/null || true
}

trap cleanup INT TERM EXIT

echo "Starting API on http://localhost:8080..."
PORT=8080 pnpm --filter @workspace/api-server run dev &
API_PID=$!

echo "Starting website on http://localhost:5173..."
PORT=5173 BASE_PATH=/ LOCAL_API_URL=http://localhost:8080 \
  pnpm --filter @workspace/reverseride run dev &
WEB_PID=$!

echo
echo "ReverseRide is starting."
echo "Open http://localhost:5173"
echo "Press Ctrl+C to stop both services."
echo

wait -n "${API_PID}" "${WEB_PID}"