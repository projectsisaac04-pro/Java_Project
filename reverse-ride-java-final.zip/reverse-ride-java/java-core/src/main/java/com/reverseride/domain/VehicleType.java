package com.reverseride.domain;

public enum VehicleType {
  BIKE, AUTO, CAR, PREMIUM
}