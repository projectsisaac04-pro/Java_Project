package com.reverseride.domain;

public enum RideStatus {
  DRAFT, AUCTION, BOOKED, ACTIVE, COMPLETED, CANCELLED
}