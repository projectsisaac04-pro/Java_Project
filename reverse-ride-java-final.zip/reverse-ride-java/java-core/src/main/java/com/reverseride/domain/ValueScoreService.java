package com.reverseride.domain;

import java.math.BigDecimal;

public final class ValueScoreService {
  private ValueScoreService() {}

  /**
   * Higher is better. Price matters, but ETA, reputation, completion history,
   * and trust prevent a race to the lowest unsustainable bid.
   */
  public static double score(Bid bid) {
    double priceScore = 100 / (1 + bid.amount().doubleValue());
    double etaScore = 100 / (1 + bid.etaMinutes());
    double reputationScore = (bid.rating() / 5) * 100;
    return (priceScore * 0.25) + (etaScore * 0.2) + (reputationScore * 0.2)
        + (bid.completionRate() * 0.15) + (bid.trustScore() * 0.2);
  }

  public static BigDecimal suggestedDriverBid(BigDecimal operatingCost) {
    return operatingCost.multiply(BigDecimal.valueOf(1.35)).setScale(0, java.math.RoundingMode.HALF_UP);
  }
}