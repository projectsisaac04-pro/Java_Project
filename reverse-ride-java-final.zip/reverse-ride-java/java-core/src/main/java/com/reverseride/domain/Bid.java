package com.reverseride.domain;

import java.math.BigDecimal;

public record Bid(
    String id,
    String rideId,
    String driverName,
    BigDecimal amount,
    int etaMinutes,
    double rating,
    double completionRate,
    double trustScore,
    String vehicleLabel
) {
  public Bid {
    if (amount == null || amount.signum() < 0) throw new IllegalArgumentException("Bid amount cannot be negative");
    if (etaMinutes < 0) throw new IllegalArgumentException("ETA cannot be negative");
    if (rating < 0 || rating > 5) throw new IllegalArgumentException("Rating must be between 0 and 5");
    if (completionRate < 0 || completionRate > 100) throw new IllegalArgumentException("Completion rate must be between 0 and 100");
    if (trustScore < 0 || trustScore > 100) throw new IllegalArgumentException("Trust score must be between 0 and 100");
  }
}