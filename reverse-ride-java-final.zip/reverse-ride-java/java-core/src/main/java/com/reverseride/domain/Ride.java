package com.reverseride.domain;

import java.math.BigDecimal;
import java.time.Instant;

public record Ride(
    String id,
    String pickup,
    String destination,
    RideStatus status,
    VehicleType vehicleType,
    int passengerCount,
    Instant targetArrival,
    BigDecimal maxFare,
    Instant auctionEndsAt
) {
  public Ride {
    if (pickup == null || pickup.isBlank()) throw new IllegalArgumentException("Pickup is required");
    if (destination == null || destination.isBlank()) throw new IllegalArgumentException("Destination is required");
    if (passengerCount < 1) throw new IllegalArgumentException("Passenger count must be positive");
  }
}