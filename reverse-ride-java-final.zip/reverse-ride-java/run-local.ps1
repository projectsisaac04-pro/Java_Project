$ErrorActionPreference = "Stop"

if (-not $env:DATABASE_URL) {
  $env:DATABASE_URL = "postgresql://postgres:postgres@localhost:5432/reverseride"
}

Write-Host "Preparing database tables..."
pnpm --filter @workspace/db run push

Write-Host "Starting API on http://localhost:8080..."
$env:PORT = "8080"
$api = Start-Process -FilePath "pnpm.cmd" `
  -ArgumentList "--filter", "@workspace/api-server", "run", "dev" `
  -PassThru

Write-Host "Starting website on http://localhost:5173..."
$env:PORT = "5173"
$env:BASE_PATH = "/"
$env:LOCAL_API_URL = "http://localhost:8080"
$web = Start-Process -FilePath "pnpm.cmd" `
  -ArgumentList "--filter", "@workspace/reverseride", "run", "dev" `
  -PassThru

Write-Host ""
Write-Host "ReverseRide is starting."
Write-Host "Open http://localhost:5173"
Write-Host "Press Ctrl+C to stop both services."

try {
  Wait-Process -Id $api.Id, $web.Id
}
finally {
  Stop-Process -Id $api.Id, $web.Id -Force -ErrorAction SilentlyContinue
}