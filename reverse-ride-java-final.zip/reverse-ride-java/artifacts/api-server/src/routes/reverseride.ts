import { Router, type IRouter } from "express";
import { and, asc, count, eq } from "drizzle-orm";
import {
  AcceptBidParams,
  CreateBidBody,
  CreateCommuteBody,
  CreateRideBody,
  GetRideParams,
  ListRideBidsParams,
  ListRidesQueryParams,
  UpdateRideBody,
  UpdateRideParams,
} from "@workspace/api-zod";
import { db, bidsTable, commutesTable, ridesTable } from "@workspace/db";
import { randomUUID } from "node:crypto";

const router: IRouter = Router();

const asNumber = (value: string | number | null) =>
  value === null ? null : Number(value);

const rideResponse = (ride: typeof ridesTable.$inferSelect) => ({
  ...ride,
  passengerCount: Number(ride.passengerCount),
  maxFare: asNumber(ride.maxFare),
  targetArrival: ride.targetArrival?.toISOString() ?? null,
  auctionEndsAt: ride.auctionEndsAt?.toISOString() ?? null,
  createdAt: ride.createdAt.toISOString(),
});

const bidResponse = (bid: typeof bidsTable.$inferSelect) => ({
  ...bid,
  amount: Number(bid.amount),
  etaMinutes: Number(bid.etaMinutes),
  rating: Number(bid.rating),
  completionRate: Number(bid.completionRate),
  trustScore: Number(bid.trustScore),
  createdAt: bid.createdAt.toISOString(),
});

router.get("/rides", async (req, res) => {
  const parsed = ListRidesQueryParams.safeParse(req.query);
  if (!parsed.success) return res.status(400).json({ error: "Invalid ride filters" });
  const rows = await db
    .select()
    .from(ridesTable)
    .where(parsed.data.status ? eq(ridesTable.status, parsed.data.status) : undefined)
    .orderBy(asc(ridesTable.createdAt));
  return res.json(rows.map(rideResponse));
});

router.post("/rides", async (req, res) => {
  const parsed = CreateRideBody.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Invalid ride request" });
  const body = parsed.data;
  const now = new Date();
  const auctionEndsAt = new Date(now.getTime() + (body.auctionDurationSeconds ?? 90) * 1000);
  const [ride] = await db.insert(ridesTable).values({
    id: randomUUID(),
    pickup: body.pickup,
    destination: body.destination,
    status: "auction",
    vehicleType: body.vehicleType,
    passengerCount: String(body.passengerCount ?? 1),
    targetArrival: body.targetArrival ? new Date(body.targetArrival) : null,
    maxFare: body.maxFare === null || body.maxFare === undefined ? null : String(body.maxFare),
    auctionEndsAt,
  }).returning();
  return res.status(201).json(rideResponse(ride));
});

router.get("/rides/:rideId", async (req, res) => {
  const parsed = GetRideParams.safeParse(req.params);
  if (!parsed.success) return res.status(400).json({ error: "Invalid ride id" });
  const [ride] = await db.select().from(ridesTable).where(eq(ridesTable.id, parsed.data.rideId));
  if (!ride) return res.status(404).json({ error: "Ride not found" });
  return res.json(rideResponse(ride));
});

router.patch("/rides/:rideId", async (req, res) => {
  const params = UpdateRideParams.safeParse(req.params);
  const body = UpdateRideBody.safeParse(req.body);
  if (!params.success || !body.success) return res.status(400).json({ error: "Invalid ride update" });
  const [ride] = await db.update(ridesTable).set({
    ...(body.data.status ? { status: body.data.status } : {}),
    ...(body.data.pickup ? { pickup: body.data.pickup } : {}),
    ...(body.data.destination ? { destination: body.data.destination } : {}),
    ...(body.data.selectedBidId !== undefined ? { selectedBidId: body.data.selectedBidId } : {}),
  }).where(eq(ridesTable.id, params.data.rideId)).returning();
  if (!ride) return res.status(404).json({ error: "Ride not found" });
  return res.json(rideResponse(ride));
});

router.get("/rides/:rideId/bids", async (req, res) => {
  const parsed = ListRideBidsParams.safeParse(req.params);
  if (!parsed.success) return res.status(400).json({ error: "Invalid ride id" });
  const rows = await db.select().from(bidsTable).where(eq(bidsTable.rideId, parsed.data.rideId)).orderBy(asc(bidsTable.amount));
  return res.json(rows.map(bidResponse));
});

router.post("/rides/:rideId/bids", async (req, res) => {
  const params = ListRideBidsParams.safeParse(req.params);
  const body = CreateBidBody.safeParse(req.body);
  if (!params.success || !body.success) return res.status(400).json({ error: "Invalid bid" });
  const [bid] = await db.insert(bidsTable).values({
    id: randomUUID(),
    rideId: params.data.rideId,
    driverName: body.data.driverName,
    amount: String(body.data.amount),
    etaMinutes: String(body.data.etaMinutes),
    rating: String(body.data.rating),
    completionRate: String(body.data.completionRate),
    trustScore: String(body.data.trustScore),
    vehicleLabel: body.data.vehicleLabel,
  }).returning();
  return res.status(201).json(bidResponse(bid));
});

router.post("/rides/:rideId/bids/:bidId/accept", async (req, res) => {
  const params = AcceptBidParams.safeParse(req.params);
  if (!params.success) return res.status(400).json({ error: "Invalid bid selection" });
  const [bid] = await db.select().from(bidsTable).where(and(eq(bidsTable.id, params.data.bidId), eq(bidsTable.rideId, params.data.rideId)));
  if (!bid) return res.status(404).json({ error: "Bid not found" });
  const [ride] = await db.update(ridesTable).set({ status: "booked", selectedBidId: bid.id }).where(eq(ridesTable.id, bid.rideId)).returning();
  if (!ride) return res.status(404).json({ error: "Ride not found" });
  return res.json(rideResponse(ride));
});

router.get("/rides/:rideId/fare-explanation", (_req, res) => {
  return res.json({ total: 0, distanceKm: 0, trafficAdjustment: 0, demandAdjustment: 0, timeAdjustment: 0, estimatedMinutes: 0 });
});

router.get("/rides/:rideId/safety-events", (_req, res) => {
  return res.json([]);
});

router.get("/commutes", async (_req, res) => {
  const rows = await db.select().from(commutesTable).orderBy(asc(commutesTable.label));
  return res.json(rows.map((commute) => ({ ...commute, maxFare: Number(commute.maxFare) })));
});

router.post("/commutes", async (req, res) => {
  const parsed = CreateCommuteBody.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Invalid commute" });
  const body = parsed.data;
  const [commute] = await db.insert(commutesTable).values({
    id: randomUUID(),
    label: body.label,
    pickup: body.pickup,
    destination: body.destination,
    daysOfWeek: body.daysOfWeek,
    departureTime: body.departureTime,
    targetArrival: body.targetArrival,
    maxFare: String(body.maxFare),
    vehicleType: body.vehicleType,
    active: true,
  }).returning();
  return res.status(201).json({ ...commute, maxFare: Number(commute.maxFare) });
});

router.get("/driver/demand-radar", (_req, res) => res.json([]));

router.get("/dashboard/summary", async (_req, res) => {
  const [active] = await db.select({ value: count() }).from(ridesTable).where(eq(ridesTable.status, "active"));
  const [completed] = await db.select({ value: count() }).from(ridesTable).where(eq(ridesTable.status, "completed"));
  const [commutes] = await db.select({ value: count() }).from(commutesTable);
  res.json({ activeRides: Number(active.value), completedRides: Number(completed.value), savedCommutes: Number(commutes.value), passengerScore: null, driverScore: null });
});

export default router;