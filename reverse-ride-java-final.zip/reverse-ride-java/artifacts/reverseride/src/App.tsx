import { useState, type FormEvent, type ReactNode } from 'react';
import { QueryClient, QueryClientProvider, useQueryClient } from '@tanstack/react-query';
import { Link, Route, Switch, Router as WouterRouter, useLocation, useParams } from 'wouter';
import {
  Activity, ArrowDownRight, ArrowLeft, ArrowRight, BadgeCheck, Bell, Bike, CarFront,
  Check, ChevronDown, CircleAlert, Clock3, Compass, FileText, Gauge, HeartHandshake,
  Home, Info, LifeBuoy, ListFilter, LockKeyhole, MapPin, Menu, Navigation, Plus,
  Radio, Route as RouteIcon, ShieldCheck, SlidersHorizontal, Sparkles, Star, Timer,
  TrendingUp, UserRound, UsersRound, WalletCards, X, Zap,
} from 'lucide-react';
import {
  getGetDashboardSummaryQueryKey,
  getGetDemandRadarQueryKey,
  getGetRideQueryKey,
  getExplainRideFareQueryKey,
  getListCommutesQueryKey,
  getListRideBidsQueryKey,
  getListRidesQueryKey,
  getListSafetyEventsQueryKey,
  useAcceptBid,
  useCreateBid,
  useCreateCommute,
  useCreateRide,
  useExplainRideFare,
  useGetDashboardSummary,
  useGetDemandRadar,
  useGetRide,
  useListCommutes,
  useListRideBids,
  useListRides,
  useListSafetyEvents,
} from '@workspace/api-client-react';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import './index.css';

const queryClient = new QueryClient();

const navItems = [
  { href: '/', label: 'Overview', icon: Home },
  { href: '/rides', label: 'My rides', icon: RouteIcon },
  { href: '/commutes', label: 'Commutes', icon: Clock3 },
  { href: '/driver', label: 'Driver workspace', icon: Radio },
  { href: '/safety', label: 'Safety center', icon: ShieldCheck },
  { href: '/profile', label: 'Profile & trust', icon: UserRound },
];

function formatMoney(value?: number | null) { return value == null ? '—' : `₹${value.toFixed(0)}`; }
function formatDate(value?: string | null) {
  if (!value) return 'Not set';
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? value : date.toLocaleString([], { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });
}
function statusLabel(status?: string) { return status ? status.charAt(0).toUpperCase() + status.slice(1) : 'Unknown'; }
function vehicleIcon(type?: string) { return type === 'bike' ? Bike : type === 'car' || type === 'premium' ? CarFront : Navigation; }

function SkeletonBlock({ className = '' }: { className?: string }) {
  return <div className={`skeleton rounded-xl ${className}`} aria-label="Loading" data-testid="loading-skeleton" />;
}

function EmptyState({ icon: Icon, title, copy, action }: { icon: typeof Compass; title: string; copy: string; action?: ReactNode }) {
  return (
    <div className="surface-grid flex min-h-[230px] flex-col items-center justify-center rounded-2xl border border-dashed border-[hsl(var(--border))] p-8 text-center" data-testid="empty-state">
      <div className="mb-4 grid h-12 w-12 place-items-center rounded-2xl bg-[hsl(var(--primary)/.11)] text-[hsl(var(--primary))]"><Icon size={22} /></div>
      <h3 className="display text-lg font-bold">{title}</h3>
      <p className="mt-2 max-w-sm text-sm leading-6 text-[hsl(var(--muted-foreground))]">{copy}</p>
      {action && <div className="mt-5">{action}</div>}
    </div>
  );
}

function ErrorState({ retry }: { retry?: () => void }) {
  return (
    <div className="flex items-center justify-between gap-4 rounded-2xl border border-[hsl(var(--destructive)/.25)] bg-[hsl(var(--destructive)/.06)] p-4 text-sm" data-testid="error-state">
      <div className="flex items-center gap-3"><CircleAlert size={18} className="text-[hsl(var(--destructive))]" /><span>We could not sync this view right now.</span></div>
      {retry && <button className="btn btn-line px-3 py-2 text-xs" onClick={retry} data-testid="button-retry">Try again</button>}
    </div>
  );
}

function Badge({ children, tone = 'neutral' }: { children: ReactNode; tone?: 'neutral' | 'green' | 'amber' | 'red' }) {
  const colors = { neutral: 'bg-[hsl(var(--muted))] text-[hsl(var(--muted-foreground))]', green: 'bg-[hsl(var(--primary)/.12)] text-[hsl(var(--primary))]', amber: 'bg-[hsl(var(--accent)/.22)] text-[hsl(var(--accent-foreground))]', red: 'bg-[hsl(var(--destructive)/.1)] text-[hsl(var(--destructive))]' };
  return <span className={`inline-flex items-center rounded-full px-2.5 py-1 text-[.68rem] font-bold uppercase tracking-[.08em] ${colors[tone]}`}>{children}</span>;
}

function Shell({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  return (
    <div className="min-h-[100dvh] bg-transparent">
      <aside className={`fixed inset-y-0 left-0 z-30 flex w-[248px] flex-col border-r border-[hsl(var(--border))] bg-[hsl(var(--secondary))] px-4 py-5 text-[hsl(var(--secondary-foreground))] transition-transform md:translate-x-0 ${mobileOpen ? 'translate-x-0' : '-translate-x-full'}`} data-testid="sidebar">
        <div className="mb-8 flex items-center justify-between px-3">
          <Link href="/" className="flex items-center gap-3" data-testid="link-logo">
            <span className="grid h-9 w-9 place-items-center rounded-xl bg-[hsl(var(--accent))] text-[hsl(var(--accent-foreground))]"><ArrowLeft size={17} strokeWidth={3} /></span>
            <span className="display text-lg font-bold tracking-tight">ReverseRide</span>
          </Link>
          <button className="rounded-lg p-2 md:hidden" onClick={() => setMobileOpen(false)} data-testid="button-close-menu"><X size={18} /></button>
        </div>
        <div className="px-3 pb-3 text-[.62rem] font-bold uppercase tracking-[.18em] text-[hsl(var(--secondary-foreground)/.45)]">Navigate</div>
        <nav className="space-y-1">
          {navItems.map(({ href, label, icon: Icon }) => {
            const active = href === '/' ? location === '/' : location.startsWith(href);
            return <Link key={href} href={href} onClick={() => setMobileOpen(false)} className={`group flex items-center gap-3 rounded-xl px-3 py-3 text-sm font-semibold transition-colors ${active ? 'bg-[hsl(var(--primary))] text-[hsl(var(--primary-foreground))]' : 'text-[hsl(var(--secondary-foreground)/.65)] hover:bg-[hsl(var(--secondary-foreground)/.08)] hover:text-[hsl(var(--secondary-foreground))]'}`} data-testid={`link-nav-${label.toLowerCase().replaceAll(' ', '-')}`}><Icon size={17} /><span>{label}</span>{href === '/safety' && <span className="ml-auto h-1.5 w-1.5 rounded-full bg-[hsl(var(--accent))]" />}</Link>;
          })}
        </nav>
        <div className="mt-auto rounded-2xl border border-[hsl(var(--secondary-foreground)/.12)] bg-[hsl(var(--secondary-foreground)/.05)] p-4">
          <div className="mb-3 flex items-center gap-2 text-[hsl(var(--accent))]"><HeartHandshake size={17} /><span className="eyebrow">The fair way</span></div>
          <p className="text-xs leading-5 text-[hsl(var(--secondary-foreground)/.6)]">Every bid is visible. Every trip is backed by a trust signal.</p>
        </div>
      </aside>
      {mobileOpen && <button className="fixed inset-0 z-20 bg-[hsl(var(--secondary)/.45)] md:hidden" onClick={() => setMobileOpen(false)} aria-label="Close navigation" data-testid="button-overlay" />}
      <main className="md:pl-[248px]">
        <header className="sticky top-0 z-10 flex h-[72px] items-center justify-between border-b border-[hsl(var(--border)/.7)] bg-[hsl(var(--background)/.78)] px-5 backdrop-blur-xl md:px-10">
          <button className="rounded-xl border border-[hsl(var(--border))] p-2.5 md:hidden" onClick={() => setMobileOpen(true)} data-testid="button-open-menu"><Menu size={18} /></button>
          <div className="hidden items-center gap-3 text-sm text-[hsl(var(--muted-foreground))] md:flex"><span className="h-2 w-2 rounded-full bg-[hsl(var(--primary))] shadow-[0_0_0_4px_hsl(var(--primary)/.12)]" />Live marketplace</div>
          <div className="ml-auto flex items-center gap-3">
            <button className="relative rounded-xl border border-[hsl(var(--border))] p-2.5 text-[hsl(var(--muted-foreground))] transition-colors hover:text-[hsl(var(--foreground))]" data-testid="button-notifications"><Bell size={17} /><span className="absolute right-2 top-2 h-1.5 w-1.5 rounded-full bg-[hsl(var(--accent))]" /></button>
            <Link href="/profile" className="flex items-center gap-2 rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--card)/.5)] px-2 py-1.5 text-sm font-semibold" data-testid="link-account"><span className="grid h-7 w-7 place-items-center rounded-lg bg-[hsl(var(--secondary))] text-xs text-[hsl(var(--secondary-foreground))]">RR</span><span className="hidden sm:inline">Your account</span><ChevronDown size={14} className="text-[hsl(var(--muted-foreground))]" /></Link>
          </div>
        </header>
        <div className="mx-auto max-w-[1400px] px-5 py-7 md:px-10 md:py-10">{children}</div>
      </main>
    </div>
  );
}

function PageTitle({ eyebrow, title, copy, action }: { eyebrow: string; title: string; copy: string; action?: ReactNode }) {
  return <div className="mb-8 flex flex-col justify-between gap-5 md:flex-row md:items-end"><div><div className="eyebrow mb-3 text-[hsl(var(--primary))]">{eyebrow}</div><h1 className="display text-3xl font-bold tracking-tight md:text-[2.8rem]" data-testid={`text-title-${title.toLowerCase().replaceAll(' ', '-')}`}>{title}</h1><p className="mt-2 max-w-2xl text-sm leading-6 text-[hsl(var(--muted-foreground))]">{copy}</p></div>{action}</div>;
}

function SummaryCard({ icon: Icon, label, value, foot, accent = false }: { icon: typeof Activity; label: string; value: string; foot: string; accent?: boolean }) {
  return <div className={`rounded-2xl border p-5 shadow-[var(--shadow-sm)] ${accent ? 'border-[hsl(var(--primary)/.28)] bg-[hsl(var(--primary)/.08)]' : 'border-[hsl(var(--card-border))] bg-[hsl(var(--card)/.76)]'}`} data-testid={`summary-${label.toLowerCase().replaceAll(' ', '-')}`}><div className="mb-5 flex items-center justify-between"><span className="text-xs font-semibold text-[hsl(var(--muted-foreground))]">{label}</span><span className={`grid h-8 w-8 place-items-center rounded-lg ${accent ? 'bg-[hsl(var(--primary))] text-[hsl(var(--primary-foreground))]' : 'bg-[hsl(var(--muted))] text-[hsl(var(--primary))]'}`}><Icon size={16} /></span></div><div className="display text-3xl font-bold">{value}</div><div className="mt-1 text-xs text-[hsl(var(--muted-foreground))]">{foot}</div></div>;
}

function RideRequestForm({ onCreated }: { onCreated?: (id: string) => void }) {
  const queryClient = useQueryClient();
  const createRide = useCreateRide();
  const [form, setForm] = useState({ pickup: '', destination: '', vehicleType: 'car', passengerCount: '1', targetArrival: '', maxFare: '', auctionDurationSeconds: '180' });
  const [success, setSuccess] = useState('');
  const [error, setError] = useState('');
  function submit(event: FormEvent) {
    event.preventDefault(); setError(''); setSuccess('');
    if (!form.pickup.trim() || !form.destination.trim()) { setError('Add both a pickup and destination to open the marketplace.'); return; }
    createRide.mutate({ data: { pickup: form.pickup, destination: form.destination, vehicleType: form.vehicleType as 'bike' | 'auto' | 'car' | 'premium', passengerCount: Number(form.passengerCount), targetArrival: form.targetArrival || null, maxFare: form.maxFare ? Number(form.maxFare) : null, auctionDurationSeconds: Number(form.auctionDurationSeconds) } }, {
      onSuccess: (ride) => { queryClient.invalidateQueries({ queryKey: getListRidesQueryKey() }); queryClient.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() }); setSuccess('Your request is live. Drivers nearby can now compete for it.'); setForm({ pickup: '', destination: '', vehicleType: 'car', passengerCount: '1', targetArrival: '', maxFare: '', auctionDurationSeconds: '180' }); onCreated?.(ride.id); },
      onError: () => setError('We could not open this request. Check the details and try again.'),
    });
  }
  return <form id="ride-request" onSubmit={submit} className="rounded-[1.35rem] border border-[hsl(var(--secondary)/.1)] bg-[hsl(var(--secondary))] p-5 text-[hsl(var(--secondary-foreground))] shadow-[var(--shadow-md)] md:p-7" data-testid="form-ride-request">
    <div className="mb-6 flex items-start justify-between gap-4"><div><div className="eyebrow text-[hsl(var(--accent))]">Open a fair auction</div><h2 className="display mt-2 text-2xl font-bold">Where are you headed?</h2><p className="mt-1 text-sm text-[hsl(var(--secondary-foreground)/.58)]">Set the brief. Drivers set their price.</p></div><Sparkles className="text-[hsl(var(--accent))]" size={20} /></div>
    <div className="grid gap-3 md:grid-cols-2">
      <label className="block text-xs font-semibold text-[hsl(var(--secondary-foreground)/.62)] md:col-span-2">Pickup<input className="field mt-2 border-[hsl(var(--secondary-foreground)/.14)] bg-[hsl(var(--secondary-foreground)/.07)] text-[hsl(var(--secondary-foreground))] placeholder:text-[hsl(var(--secondary-foreground)/.35)]" placeholder="Search a street, place or landmark" value={form.pickup} onChange={e => setForm({ ...form, pickup: e.target.value })} data-testid="input-pickup" /></label>
      <label className="block text-xs font-semibold text-[hsl(var(--secondary-foreground)/.62)] md:col-span-2">Destination<input className="field mt-2 border-[hsl(var(--secondary-foreground)/.14)] bg-[hsl(var(--secondary-foreground)/.07)] text-[hsl(var(--secondary-foreground))] placeholder:text-[hsl(var(--secondary-foreground)/.35)]" placeholder="Where should the driver take you?" value={form.destination} onChange={e => setForm({ ...form, destination: e.target.value })} data-testid="input-destination" /></label>
      <label className="block text-xs font-semibold text-[hsl(var(--secondary-foreground)/.62)]">Vehicle<select className="field mt-2 border-[hsl(var(--secondary-foreground)/.14)] bg-[hsl(var(--secondary-foreground)/.07)] text-[hsl(var(--secondary-foreground))]" value={form.vehicleType} onChange={e => setForm({ ...form, vehicleType: e.target.value })} data-testid="select-vehicle"><option value="bike">Bike</option><option value="auto">Auto</option><option value="car">Car</option><option value="premium">Premium</option></select></label>
      <label className="block text-xs font-semibold text-[hsl(var(--secondary-foreground)/.62)]">Passengers<input type="number" min="1" className="field mt-2 border-[hsl(var(--secondary-foreground)/.14)] bg-[hsl(var(--secondary-foreground)/.07)] text-[hsl(var(--secondary-foreground))]" value={form.passengerCount} onChange={e => setForm({ ...form, passengerCount: e.target.value })} data-testid="input-passengers" /></label>
      <label className="block text-xs font-semibold text-[hsl(var(--secondary-foreground)/.62)]">Target arrival<input type="datetime-local" className="field mt-2 border-[hsl(var(--secondary-foreground)/.14)] bg-[hsl(var(--secondary-foreground)/.07)] text-[hsl(var(--secondary-foreground))]" value={form.targetArrival} onChange={e => setForm({ ...form, targetArrival: e.target.value })} data-testid="input-target-arrival" /></label>
      <label className="block text-xs font-semibold text-[hsl(var(--secondary-foreground)/.62)]">Your max fare <span className="font-normal text-[hsl(var(--secondary-foreground)/.4)]">(optional)</span><input type="number" min="0" step="0.01" className="field mt-2 border-[hsl(var(--secondary-foreground)/.14)] bg-[hsl(var(--secondary-foreground)/.07)] text-[hsl(var(--secondary-foreground))]" placeholder="No limit" value={form.maxFare} onChange={e => setForm({ ...form, maxFare: e.target.value })} data-testid="input-max-fare" /></label>
    </div>
    {error && <div className="mt-4 flex items-center gap-2 text-sm text-[hsl(var(--accent))]" data-testid="status-ride-error"><CircleAlert size={15} />{error}</div>}
    {success && <div className="mt-4 flex items-center gap-2 text-sm text-[hsl(var(--accent))]" data-testid="status-ride-success"><Check size={15} />{success}</div>}
    <button disabled={createRide.isPending} className="btn btn-primary mt-5 w-full py-3.5 disabled:cursor-wait disabled:opacity-60" type="submit" data-testid="button-submit-ride">{createRide.isPending ? 'Opening marketplace…' : 'Request a ride'}<ArrowRight size={16} /></button>
  </form>;
}

function HomePage() {
  const { data: summary, isLoading: summaryLoading, isError: summaryError, refetch: refetchSummary } = useGetDashboardSummary({ query: { queryKey: getGetDashboardSummaryQueryKey() } });
  const { data: rides, isLoading: ridesLoading } = useListRides(undefined, { query: { queryKey: getListRidesQueryKey() } });
  const activeRide = rides?.find(ride => ['auction', 'booked', 'active'].includes(ride.status));
  return <PageTitle eyebrow="Passenger cockpit" title="Move on your terms." copy="A better way to get across town: you set the brief, local drivers bring the options." action={<Link href="/rides" className="btn btn-line" data-testid="link-view-rides">View all rides <ArrowRight size={16} /></Link>} />;
}

function Dashboard() {
  const { data: summary, isLoading: summaryLoading, isError: summaryError, refetch: refetchSummary } = useGetDashboardSummary({ query: { queryKey: getGetDashboardSummaryQueryKey() } });
  const { data: rides, isLoading: ridesLoading } = useListRides(undefined, { query: { queryKey: getListRidesQueryKey() } });
  const activeRide = rides?.find(ride => ['auction', 'booked', 'active'].includes(ride.status));
  const activeCount = summary?.activeRides ?? rides?.filter(r => ['auction', 'booked', 'active'].includes(r.status)).length ?? 0;
  return <div className="animate-rise">
    <PageTitle eyebrow="Passenger cockpit" title="Move on your terms." copy="A better way to get across town: you set the brief, local drivers bring the options." action={<Link href="/rides" className="btn btn-line" data-testid="link-view-rides">View all rides <ArrowRight size={16} /></Link>} />
    {summaryError && <div className="mb-5"><ErrorState retry={() => refetchSummary()} /></div>}
    <div className="mb-8 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
      {summaryLoading ? <><SkeletonBlock className="h-[142px]" /><SkeletonBlock className="h-[142px]" /><SkeletonBlock className="h-[142px]" /><SkeletonBlock className="h-[142px]" /></> : <><SummaryCard icon={Navigation} label="Active rides" value={String(activeCount)} foot={activeCount ? 'One is in your orbit' : 'Nothing moving yet'} accent /><SummaryCard icon={Check} label="Completed rides" value={String(summary?.completedRides ?? 0)} foot="Your ride history" /><SummaryCard icon={Clock3} label="Saved commutes" value={String(summary?.savedCommutes ?? 0)} foot="Set it once, reuse it" /><SummaryCard icon={Gauge} label="Passenger score" value={summary?.passengerScore == null ? '—' : `${summary.passengerScore}`} foot={summary?.passengerScore == null ? 'Earned through trips' : 'Trust built over time'} /></>}
    </div>
    <div className="grid gap-6 xl:grid-cols-[1.12fr_.88fr]">
      <RideRequestForm />
      <div className="space-y-5">
        <div className="flex items-center justify-between"><div><div className="eyebrow text-[hsl(var(--primary))]">In motion</div><h2 className="display mt-1 text-xl font-bold">Your active rides</h2></div><Link href="/rides" className="text-xs font-bold text-[hsl(var(--primary))]" data-testid="link-active-rides">See history</Link></div>
        {ridesLoading ? <SkeletonBlock className="h-[250px]" /> : activeRide ? <RideMiniCard ride={activeRide} /> : <EmptyState icon={Navigation} title="Your next ride starts here." copy="Open a request and let nearby drivers compete with clear, comparable bids." action={<Link href="#ride-request" className="btn btn-quiet" data-testid="link-start-request">Start with a request</Link>} />}
        <div className="rounded-2xl border border-[hsl(var(--card-border))] bg-[hsl(var(--card)/.72)] p-5">
          <div className="flex items-start gap-3"><div className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-[hsl(var(--accent)/.2)] text-[hsl(var(--accent-foreground))]"><Info size={17} /></div><div><h3 className="font-bold">How ReverseRide works</h3><p className="mt-1 text-sm leading-6 text-[hsl(var(--muted-foreground))]">No surge surprises. You see the fare, arrival estimate, vehicle and reputation signals before choosing.</p></div></div>
        </div>
      </div>
    </div>
  </div>;
}

function RideMiniCard({ ride }: { ride: any }) {
  const Icon = vehicleIcon(ride.vehicleType);
  return <Link href={`/rides/${ride.id}`} className="block rounded-2xl border border-[hsl(var(--primary)/.22)] bg-[hsl(var(--card)/.82)] p-5 shadow-[var(--shadow-sm)] transition-transform hover:-translate-y-0.5" data-testid={`card-active-ride-${ride.id}`}><div className="mb-5 flex items-center justify-between"><Badge tone={ride.status === 'active' ? 'green' : 'amber'}>{statusLabel(ride.status)}</Badge><Icon size={19} className="text-[hsl(var(--primary))]" /></div><div className="flex items-start gap-3"><div className="flex flex-col items-center pt-1"><span className="h-2 w-2 rounded-full bg-[hsl(var(--primary))]" /><span className="my-1 h-7 border-l border-dashed border-[hsl(var(--border))]" /><span className="h-2 w-2 rounded-full bg-[hsl(var(--accent))]" /></div><div className="min-w-0 space-y-3 text-sm"><div className="truncate font-semibold">{ride.pickup}</div><div className="truncate font-semibold">{ride.destination}</div></div></div><div className="mt-5 flex items-center justify-between border-t border-[hsl(var(--border))] pt-4 text-xs text-[hsl(var(--muted-foreground))]"><span>{ride.selectedBidId ? 'Driver selected' : 'Collecting bids'}</span><span className="font-mono">{formatDate(ride.createdAt)}</span></div></Link>;
}

function RidesPage() {
  const { data: rides, isLoading, isError, refetch } = useListRides(undefined, { query: { queryKey: getListRidesQueryKey() } });
  return <div className="animate-rise"><PageTitle eyebrow="Passenger cockpit / history" title="Ride requests" copy="Keep an eye on open auctions, booked trips and the rides that got you there." action={<Link href="/" className="btn btn-primary" data-testid="link-new-ride"><Plus size={16} /> New request</Link>} />{isError ? <ErrorState retry={() => refetch()} /> : isLoading ? <div className="grid gap-4 md:grid-cols-2"><SkeletonBlock className="h-[230px]" /><SkeletonBlock className="h-[230px]" /></div> : rides?.length ? <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">{rides.map(ride => <RideMiniCard key={ride.id} ride={ride} />)}</div> : <EmptyState icon={RouteIcon} title="No ride requests yet" copy="Your first request will open a transparent mini-marketplace around you." action={<Link href="/" className="btn btn-primary" data-testid="link-create-first-ride">Create your first request <ArrowRight size={16} /></Link>} />}</div>;
}

function RideDetailPage() {
  const { id = '' } = useParams<{ id: string }>();
  const queryClient = useQueryClient();
  const { data: ride, isLoading: rideLoading, isError: rideError } = useGetRide(id, { query: { enabled: !!id, queryKey: getGetRideQueryKey(id) } });
  const { data: bids, isLoading: bidsLoading } = useListRideBids(id, { query: { enabled: !!id, queryKey: getListRideBidsQueryKey(id) } });
  const { data: fare, isLoading: fareLoading } = useExplainRideFare(id, { query: { enabled: !!id, queryKey: getExplainRideFareQueryKey(id) } });
  const acceptBid = useAcceptBid();
  const [message, setMessage] = useState('');
  if (rideLoading) return <div><SkeletonBlock className="mb-5 h-8 w-40" /><SkeletonBlock className="h-[400px]" /></div>;
  if (rideError || !ride) return <ErrorState />;
  return <div className="animate-rise"><Link href="/rides" className="mb-6 inline-flex items-center gap-2 text-sm font-bold text-[hsl(var(--muted-foreground))] hover:text-[hsl(var(--foreground))]" data-testid="link-back-rides"><ArrowLeft size={16} /> Back to rides</Link><PageTitle eyebrow={`Request / ${ride.id.slice(0, 8)}`} title={`${ride.pickup} to ${ride.destination}`} copy={`Created ${formatDate(ride.createdAt)}. Compare every offer with the full context.`} action={<Badge tone={ride.status === 'active' || ride.status === 'booked' ? 'green' : 'amber'}>{statusLabel(ride.status)}</Badge>} /><div className="grid gap-6 xl:grid-cols-[1.1fr_.9fr]"><div className="space-y-6"><div className="rounded-2xl border border-[hsl(var(--card-border))] bg-[hsl(var(--card)/.72)] p-6"><div className="mb-5 flex items-center justify-between"><div><div className="eyebrow text-[hsl(var(--primary))]">Driver offers</div><h2 className="display mt-1 text-xl font-bold">{bids?.length ?? 0} bids to compare</h2></div><ListFilter size={18} className="text-[hsl(var(--muted-foreground))]" /></div>{bidsLoading ? <SkeletonBlock className="h-40" /> : bids?.length ? <div className="space-y-3">{bids.map(bid => <BidCard key={bid.id} bid={bid} rideStatus={ride.status} onAccept={() => { acceptBid.mutate({ rideId: ride.id, bidId: bid.id }, { onSuccess: () => { setMessage('Ride booked. Your driver has been notified.'); queryClient.invalidateQueries({ queryKey: getGetRideQueryKey(ride.id) }); queryClient.invalidateQueries({ queryKey: getListRideBidsQueryKey(ride.id) }); } }); }} pending={acceptBid.isPending} />)}</div> : <EmptyState icon={Radio} title="Listening for nearby drivers" copy="Your request is visible to drivers in the area. New bids will appear here." />}{message && <div className="mt-4 flex items-center gap-2 rounded-xl bg-[hsl(var(--primary)/.1)] p-3 text-sm font-semibold text-[hsl(var(--primary))]" data-testid="status-booking-success"><Check size={16} />{message}</div>}</div></div><div className="space-y-6"><div className="rounded-2xl border border-[hsl(var(--card-border))] bg-[hsl(var(--card)/.72)] p-6"><div className="eyebrow text-[hsl(var(--primary))]">Fare lens</div><h2 className="display mt-1 text-xl font-bold">Why this fare?</h2>{fareLoading ? <SkeletonBlock className="mt-5 h-36" /> : fare ? <div className="mt-5 space-y-3 text-sm"><div className="flex items-end justify-between border-b border-[hsl(var(--border))] pb-4"><span className="text-[hsl(var(--muted-foreground))]">Transparent estimate</span><strong className="display text-3xl">{formatMoney(fare.total)}</strong></div><FareRow label="Route distance" value={`${fare.distanceKm} km`} /><FareRow label="Traffic adjustment" value={formatMoney(fare.trafficAdjustment)} /><FareRow label="Demand adjustment" value={formatMoney(fare.demandAdjustment)} /><FareRow label="Time adjustment" value={formatMoney(fare.timeAdjustment)} /><FareRow label="Estimated time" value={`${fare.estimatedMinutes} min`} /></div> : <p className="mt-5 text-sm text-[hsl(var(--muted-foreground))]">Fare detail will appear once the route is ready.</p>}</div><div className="rounded-2xl bg-[hsl(var(--secondary))] p-6 text-[hsl(var(--secondary-foreground))]"><div className="flex gap-3"><LockKeyhole className="mt-0.5 text-[hsl(var(--accent))]" size={18} /><div><h3 className="font-bold">Choice stays yours</h3><p className="mt-1 text-sm leading-6 text-[hsl(var(--secondary-foreground)/.6)]">We put price and trust side by side so you can choose what matters today.</p></div></div></div></div></div></div>;
}

function FareRow({ label, value }: { label: string; value: string }) { return <div className="flex justify-between gap-4"><span className="text-[hsl(var(--muted-foreground))]">{label}</span><span className="font-mono text-xs font-medium">{value}</span></div>; }
function BidCard({ bid, rideStatus, onAccept, pending }: { bid: any; rideStatus: string; onAccept: () => void; pending: boolean }) {
  return <div className="rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--card)/.55)] p-4 transition-colors hover:border-[hsl(var(--primary)/.35)]" data-testid={`card-bid-${bid.id}`}><div className="flex items-start justify-between gap-3"><div className="flex items-center gap-3"><div className="grid h-10 w-10 place-items-center rounded-xl bg-[hsl(var(--secondary))] text-sm font-bold text-[hsl(var(--accent))]">{bid.driverName.slice(0, 1).toUpperCase()}</div><div><div className="font-bold">{bid.driverName}</div><div className="mt-0.5 text-xs text-[hsl(var(--muted-foreground))]">{bid.vehicleLabel}</div></div></div><div className="text-right"><div className="display text-xl font-bold">{formatMoney(bid.amount)}</div><div className="text-xs text-[hsl(var(--muted-foreground))]">{bid.etaMinutes} min away</div></div></div><div className="mt-4 grid grid-cols-3 gap-2 border-t border-[hsl(var(--border))] pt-3 text-xs"><span><strong className="block text-sm">{bid.rating.toFixed(1)}</strong><span className="text-[hsl(var(--muted-foreground))]">Rating</span></span><span><strong className="block text-sm">{bid.completionRate}%</strong><span className="text-[hsl(var(--muted-foreground))]">Completion</span></span><span><strong className="block text-sm text-[hsl(var(--primary))]">{bid.trustScore}</strong><span className="text-[hsl(var(--muted-foreground))]">Trust score</span></span></div>{!['booked', 'active', 'completed', 'cancelled'].includes(rideStatus) && <button className="btn btn-primary mt-4 w-full py-2.5 text-sm" onClick={onAccept} disabled={pending} data-testid={`button-accept-bid-${bid.id}`}>{pending ? 'Booking…' : 'Choose this driver'}<Check size={15} /></button>}</div>;
}

function CommutesPage() {
  const queryClient = useQueryClient();
  const { data: commutes, isLoading, isError, refetch } = useListCommutes({ query: { queryKey: getListCommutesQueryKey() } });
  const createCommute = useCreateCommute();
  const [open, setOpen] = useState(false);
  const [saved, setSaved] = useState(false);
  const [form, setForm] = useState({ label: '', pickup: '', destination: '', days: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'], departureTime: '08:30', targetArrival: '09:00', maxFare: '', vehicleType: 'car' });
  const toggleDay = (day: string) => setForm({ ...form, days: form.days.includes(day) ? form.days.filter(d => d !== day) : [...form.days, day] });
  function submit(event: FormEvent) { event.preventDefault(); createCommute.mutate({ data: { label: form.label, pickup: form.pickup, destination: form.destination, daysOfWeek: form.days, departureTime: form.departureTime, targetArrival: form.targetArrival, maxFare: Number(form.maxFare), vehicleType: form.vehicleType as 'bike' | 'auto' | 'car' | 'premium' } }, { onSuccess: () => { queryClient.invalidateQueries({ queryKey: getListCommutesQueryKey() }); queryClient.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() }); setSaved(true); setOpen(false); } }); }
  return <div className="animate-rise"><PageTitle eyebrow="Passenger cockpit / rhythm" title="Commutes, without the autopilot." copy="Save the routes you repeat and keep the right to choose every time." action={<button className="btn btn-primary" onClick={() => { setOpen(!open); setSaved(false); }} data-testid="button-add-commute"><Plus size={16} /> Add commute</button>} />{saved && <div className="mb-5 flex items-center gap-2 rounded-xl bg-[hsl(var(--primary)/.1)] p-3 text-sm font-semibold text-[hsl(var(--primary))]" data-testid="status-commute-success"><Check size={16} />Commute saved. It is ready for your next morning.</div>}{open && <form onSubmit={submit} className="mb-6 rounded-2xl border border-[hsl(var(--primary)/.25)] bg-[hsl(var(--card)/.85)] p-5 shadow-[var(--shadow-sm)] md:p-6" data-testid="form-commute"><div className="mb-5 flex items-center justify-between"><div><div className="eyebrow text-[hsl(var(--primary))]">A repeatable brief</div><h2 className="display mt-1 text-xl font-bold">Save a commute</h2></div><button type="button" className="rounded-lg p-2 text-[hsl(var(--muted-foreground))]" onClick={() => setOpen(false)} data-testid="button-close-commute"><X size={17} /></button></div><div className="grid gap-3 md:grid-cols-2"><label className="text-xs font-semibold">Label<input className="field mt-2" placeholder="Studio mornings" required value={form.label} onChange={e => setForm({ ...form, label: e.target.value })} data-testid="input-commute-label" /></label><label className="text-xs font-semibold">Vehicle<select className="field mt-2" value={form.vehicleType} onChange={e => setForm({ ...form, vehicleType: e.target.value })} data-testid="select-commute-vehicle"><option value="bike">Bike</option><option value="auto">Auto</option><option value="car">Car</option><option value="premium">Premium</option></select></label><label className="text-xs font-semibold">Pickup<input className="field mt-2" required value={form.pickup} onChange={e => setForm({ ...form, pickup: e.target.value })} data-testid="input-commute-pickup" /></label><label className="text-xs font-semibold">Destination<input className="field mt-2" required value={form.destination} onChange={e => setForm({ ...form, destination: e.target.value })} data-testid="input-commute-destination" /></label><label className="text-xs font-semibold">Leave at<input type="time" className="field mt-2" value={form.departureTime} onChange={e => setForm({ ...form, departureTime: e.target.value })} data-testid="input-departure-time" /></label><label className="text-xs font-semibold">Arrive by<input type="time" className="field mt-2" value={form.targetArrival} onChange={e => setForm({ ...form, targetArrival: e.target.value })} data-testid="input-commute-arrival" /></label><label className="text-xs font-semibold">Max fare<input type="number" min="0" step=".01" required className="field mt-2" value={form.maxFare} onChange={e => setForm({ ...form, maxFare: e.target.value })} data-testid="input-commute-fare" /></label></div><div className="mt-4"><div className="mb-2 text-xs font-semibold">Days</div><div className="flex flex-wrap gap-2">{['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map(day => <button type="button" key={day} className={`rounded-lg border px-3 py-2 text-xs font-bold transition-colors ${form.days.includes(day) ? 'border-[hsl(var(--primary))] bg-[hsl(var(--primary)/.11)] text-[hsl(var(--primary))]' : 'border-[hsl(var(--border))] text-[hsl(var(--muted-foreground))]'}`} onClick={() => toggleDay(day)} data-testid={`button-day-${day.toLowerCase()}`}>{day}</button>)}</div></div><button className="btn btn-primary mt-5" disabled={createCommute.isPending} data-testid="button-submit-commute">{createCommute.isPending ? 'Saving…' : 'Save commute'}<Check size={15} /></button></form>}{isError ? <ErrorState retry={() => refetch()} /> : isLoading ? <div className="grid gap-4 md:grid-cols-2"><SkeletonBlock className="h-48" /><SkeletonBlock className="h-48" /></div> : commutes?.length ? <div className="grid gap-4 md:grid-cols-2">{commutes.map(commute => <CommuteCard key={commute.id} commute={commute} />)}</div> : <EmptyState icon={Clock3} title="No saved commutes" copy="Make the routes you repeat easier to request, while keeping the final choice in your hands." action={<button className="btn btn-primary" onClick={() => setOpen(true)} data-testid="button-create-empty-commute">Save a commute <Plus size={15} /></button>} />}</div>;
}
function CommuteCard({ commute }: { commute: any }) { return <div className="rounded-2xl border border-[hsl(var(--card-border))] bg-[hsl(var(--card)/.74)] p-5 shadow-[var(--shadow-sm)]" data-testid={`card-commute-${commute.id}`}><div className="flex items-start justify-between"><div><Badge tone={commute.active ? 'green' : 'neutral'}>{commute.active ? 'Active' : 'Paused'}</Badge><h2 className="display mt-3 text-xl font-bold">{commute.label}</h2></div><Clock3 size={19} className="text-[hsl(var(--primary))]" /></div><div className="mt-5 space-y-2 text-sm"><div className="flex items-center gap-2"><MapPin size={15} className="text-[hsl(var(--primary))]" />{commute.pickup}</div><div className="ml-[7px] h-4 border-l border-dashed border-[hsl(var(--border))]" /><div className="flex items-center gap-2"><MapPin size={15} className="text-[hsl(var(--accent))]" />{commute.destination}</div></div><div className="mt-5 grid grid-cols-3 gap-3 border-t border-[hsl(var(--border))] pt-4 text-xs"><div><span className="block font-mono font-medium">{commute.daysOfWeek.join(' · ')}</span><span className="text-[hsl(var(--muted-foreground))]">Days</span></div><div><span className="block font-mono font-medium">{commute.departureTime}</span><span className="text-[hsl(var(--muted-foreground))]">Leave</span></div><div><span className="block font-mono font-medium">{formatMoney(commute.maxFare)}</span><span className="text-[hsl(var(--muted-foreground))]">Max fare</span></div></div></div>; }

function DriverPage() {
  const { data: zones, isLoading: zonesLoading, isError: zonesError, refetch: refetchZones } = useGetDemandRadar({ query: { queryKey: getGetDemandRadarQueryKey() } });
  const { data: rides, isLoading: ridesLoading } = useListRides({ status: 'auction' }, { query: { queryKey: getListRidesQueryKey({ status: 'auction' }) } });
  const [selected, setSelected] = useState<string>('');
  const ride = rides?.find(item => item.id === selected) ?? rides?.[0];
  const createBid = useCreateBid();
  const [form, setForm] = useState({ driverName: '', amount: '', etaMinutes: '8', rating: '', completionRate: '', trustScore: '', vehicleLabel: '' });
  const [success, setSuccess] = useState('');
  function submit(event: FormEvent) { event.preventDefault(); if (!ride) return; createBid.mutate({ rideId: ride.id, data: { driverName: form.driverName, amount: Number(form.amount), etaMinutes: Number(form.etaMinutes), rating: Number(form.rating), completionRate: Number(form.completionRate), trustScore: Number(form.trustScore), vehicleLabel: form.vehicleLabel } }, { onSuccess: () => { setSuccess('Bid sent. The passenger can now compare your offer.'); setForm({ driverName: '', amount: '', etaMinutes: '8', rating: '', completionRate: '', trustScore: '', vehicleLabel: '' }); } }); }
  return <div className="animate-rise"><PageTitle eyebrow="Driver side / live market" title="Meet the demand." copy="See where rides are forming, then make a clear offer that earns the right trip." action={<Badge tone="green"><span className="mr-1.5 h-1.5 w-1.5 rounded-full bg-current" />Available to bid</Badge>} /><div className="grid gap-6 xl:grid-cols-[1fr_1.15fr]"><div className="space-y-6"><div className="rounded-2xl border border-[hsl(var(--card-border))] bg-[hsl(var(--card)/.74)] p-5"><div className="mb-5 flex items-center justify-between"><div><div className="eyebrow text-[hsl(var(--primary))]">Demand radar</div><h2 className="display mt-1 text-xl font-bold">Where movement is building</h2></div><TrendingUp size={19} className="text-[hsl(var(--primary))]" /></div>{zonesError ? <ErrorState retry={() => refetchZones()} /> : zonesLoading ? <div className="space-y-3"><SkeletonBlock className="h-16" /><SkeletonBlock className="h-16" /><SkeletonBlock className="h-16" /></div> : zones?.length ? <div className="space-y-2">{zones.map(zone => <div className="flex items-center justify-between rounded-xl border border-[hsl(var(--border))] p-3" key={zone.name} data-testid={`row-demand-${zone.name}`}><div className="flex items-center gap-3"><span className={`h-2.5 w-2.5 rounded-full ${zone.level === 'high' ? 'bg-[hsl(var(--accent))]' : zone.level === 'medium' ? 'bg-[hsl(var(--primary))]' : 'bg-[hsl(var(--muted-foreground))]'}`} /><div><div className="text-sm font-bold">{zone.name}</div><div className="text-xs text-[hsl(var(--muted-foreground))]">{statusLabel(zone.level)} demand</div></div></div><div className="flex items-center gap-2 font-mono text-xs">{zone.direction === 'down' ? <ArrowDownRight size={14} /> : <ArrowRight size={14} />}{zone.changePercent > 0 ? '+' : ''}{zone.changePercent}%</div></div>)}</div> : <EmptyState icon={Compass} title="Radar is quiet" copy="Demand signals will appear here when passenger requests enter the marketplace." />}</div><div className="rounded-2xl bg-[hsl(var(--secondary))] p-5 text-[hsl(var(--secondary-foreground))]"><div className="flex items-center gap-3"><BadgeCheck className="text-[hsl(var(--accent))]" size={19} /><div><div className="font-bold">Clear bids travel further</div><p className="mt-1 text-xs leading-5 text-[hsl(var(--secondary-foreground)/.58)]">Passengers compare your price, ETA, vehicle and trust score together.</p></div></div></div></div><div className="rounded-2xl border border-[hsl(var(--card-border))] bg-[hsl(var(--card)/.74)] p-5 md:p-6"><div className="mb-5 flex items-center justify-between"><div><div className="eyebrow text-[hsl(var(--primary))]">Open passenger requests</div><h2 className="display mt-1 text-xl font-bold">{rides?.length ?? 0} opportunities nearby</h2></div><SlidersHorizontal size={18} className="text-[hsl(var(--muted-foreground))]" /></div>{ridesLoading ? <SkeletonBlock className="h-36" /> : rides?.length ? <div className="space-y-3">{rides.map(item => <button key={item.id} className={`block w-full rounded-xl border p-4 text-left transition-colors ${ride?.id === item.id ? 'border-[hsl(var(--primary))] bg-[hsl(var(--primary)/.07)]' : 'border-[hsl(var(--border))] hover:border-[hsl(var(--primary)/.35)]'}`} onClick={() => setSelected(item.id)} data-testid={`button-select-ride-${item.id}`}><div className="flex items-start justify-between gap-3"><div className="min-w-0"><div className="truncate text-sm font-bold">{item.pickup}</div><div className="my-1 ml-1 border-l border-dashed border-[hsl(var(--border))] pl-3 text-xs text-[hsl(var(--muted-foreground))]">{item.destination}</div></div><span className="shrink-0 font-mono text-xs text-[hsl(var(--muted-foreground))]">{formatDate(item.auctionEndsAt)}</span></div></button>)}<div className="my-6 h-px bg-[hsl(var(--border))]" /><h3 className="display mb-4 text-lg font-bold">Place your bid</h3>{success && <div className="mb-4 flex gap-2 rounded-xl bg-[hsl(var(--primary)/.1)] p-3 text-sm font-semibold text-[hsl(var(--primary))]" data-testid="status-bid-success"><Check size={16} />{success}</div>}<form onSubmit={submit} className="grid gap-3 sm:grid-cols-2" data-testid="form-bid"><label className="text-xs font-semibold">Your name<input className="field mt-2" required value={form.driverName} onChange={e => setForm({ ...form, driverName: e.target.value })} data-testid="input-driver-name" /></label><label className="text-xs font-semibold">Vehicle label<input className="field mt-2" required placeholder="Silver hatchback" value={form.vehicleLabel} onChange={e => setForm({ ...form, vehicleLabel: e.target.value })} data-testid="input-driver-vehicle" /></label><label className="text-xs font-semibold">Offer amount<input type="number" min="0" step=".01" className="field mt-2" required value={form.amount} onChange={e => setForm({ ...form, amount: e.target.value })} data-testid="input-bid-amount" /></label><label className="text-xs font-semibold">ETA in minutes<input type="number" min="0" className="field mt-2" required value={form.etaMinutes} onChange={e => setForm({ ...form, etaMinutes: e.target.value })} data-testid="input-bid-eta" /></label><label className="text-xs font-semibold">Rating<input type="number" min="0" max="5" step=".1" className="field mt-2" required value={form.rating} onChange={e => setForm({ ...form, rating: e.target.value })} data-testid="input-bid-rating" /></label><label className="text-xs font-semibold">Completion rate<input type="number" min="0" max="100" className="field mt-2" required value={form.completionRate} onChange={e => setForm({ ...form, completionRate: e.target.value })} data-testid="input-bid-completion" /></label><label className="text-xs font-semibold">Trust score<input type="number" min="0" max="100" className="field mt-2" required value={form.trustScore} onChange={e => setForm({ ...form, trustScore: e.target.value })} data-testid="input-bid-trust" /></label><button disabled={createBid.isPending} className="btn btn-primary self-end sm:mt-5" data-testid="button-submit-bid">{createBid.isPending ? 'Sending…' : 'Send bid'}<Zap size={15} /></button></form></div> : <EmptyState icon={Radio} title="No open requests nearby" copy="The driver marketplace is waiting for its next passenger brief." />}</div></div></div>;
}

function SafetyPage() {
  const { data: rides, isLoading: ridesLoading } = useListRides({ status: 'active' }, { query: { queryKey: getListRidesQueryKey({ status: 'active' }) } });
  const rideId = rides?.[0]?.id ?? '';
  const { data: events, isLoading: eventsLoading } = useListSafetyEvents(rideId, { query: { enabled: !!rideId, queryKey: getListSafetyEventsQueryKey(rideId) } });
  return <div className="animate-rise"><PageTitle eyebrow="Protection layer" title="Safety, in the foreground." copy="The trip details and safety signals you need, without hunting through a menu." /><div className="mb-6 grid gap-4 sm:grid-cols-3"><div className="rounded-2xl border border-[hsl(var(--primary)/.2)] bg-[hsl(var(--primary)/.08)] p-5"><ShieldCheck className="mb-5 text-[hsl(var(--primary))]" size={21} /><div className="font-bold">Trip protection</div><p className="mt-1 text-xs leading-5 text-[hsl(var(--muted-foreground))]">Available on every active ride.</p></div><div className="rounded-2xl border border-[hsl(var(--card-border))] bg-[hsl(var(--card)/.7)] p-5"><LifeBuoy className="mb-5 text-[hsl(var(--accent-foreground))]" size={21} /><div className="font-bold">Help when needed</div><p className="mt-1 text-xs leading-5 text-[hsl(var(--muted-foreground))]">Safety events are logged to the trip.</p></div><div className="rounded-2xl border border-[hsl(var(--card-border))] bg-[hsl(var(--card)/.7)] p-5"><LockKeyhole className="mb-5 text-[hsl(var(--primary))]" size={21} /><div className="font-bold">Private by design</div><p className="mt-1 text-xs leading-5 text-[hsl(var(--muted-foreground))]">Only your active ride appears here.</p></div></div>{ridesLoading ? <SkeletonBlock className="h-64" /> : rides?.length && rideId ? <div className="grid gap-6 xl:grid-cols-[1fr_.8fr]"><div className="rounded-2xl border border-[hsl(var(--card-border))] bg-[hsl(var(--card)/.74)] p-6"><div className="eyebrow text-[hsl(var(--primary))]">Active trip</div><h2 className="display mt-1 text-2xl font-bold">{rides[0].pickup} → {rides[0].destination}</h2><div className="mt-6 flex items-center gap-3 rounded-xl bg-[hsl(var(--muted)/.65)] p-4"><div className="grid h-10 w-10 place-items-center rounded-xl bg-[hsl(var(--primary))] text-[hsl(var(--primary-foreground))]"><Navigation size={17} /></div><div><div className="text-sm font-bold">Trip monitoring is on</div><div className="text-xs text-[hsl(var(--muted-foreground))]">Ride ID {rideId.slice(0, 8)}</div></div><span className="ml-auto h-2 w-2 rounded-full bg-[hsl(var(--primary))] live-line" /></div></div><div className="rounded-2xl border border-[hsl(var(--card-border))] bg-[hsl(var(--card)/.74)] p-6"><div className="mb-5 flex items-center justify-between"><div><div className="eyebrow text-[hsl(var(--primary))]">Safety log</div><h2 className="display mt-1 text-xl font-bold">{events?.length ?? 0} events</h2></div><Activity size={18} className="text-[hsl(var(--muted-foreground))]" /></div>{eventsLoading ? <SkeletonBlock className="h-24" /> : events?.length ? <div className="space-y-3">{events.map(event => <div key={event.id} className="flex gap-3 rounded-xl border border-[hsl(var(--border))] p-3" data-testid={`event-safety-${event.id}`}><CircleAlert size={16} className={event.severity === 'critical' ? 'text-[hsl(var(--destructive))]' : event.severity === 'warning' ? 'text-[hsl(var(--accent-foreground))]' : 'text-[hsl(var(--primary))]'} /><div><div className="text-sm font-bold">{event.type}</div><p className="mt-1 text-xs text-[hsl(var(--muted-foreground))]">{event.message}</p><div className="mt-2 font-mono text-[.65rem] text-[hsl(var(--muted-foreground))]">{formatDate(event.createdAt)}</div></div></div>)}</div> : <EmptyState icon={ShieldCheck} title="No safety events" copy="A quiet log is a good log. We will surface anything that needs your attention." />}</div></div> : <EmptyState icon={ShieldCheck} title="No active trip" copy="When you are on the move, your active trip and its safety log will appear here." action={<Link href="/" className="btn btn-primary" data-testid="link-request-safe-ride">Request a ride <ArrowRight size={15} /></Link>} />}</div>;
}

function ProfilePage() {
  const { data: summary, isLoading } = useGetDashboardSummary({ query: { queryKey: getGetDashboardSummaryQueryKey() } });
  return <div className="animate-rise"><PageTitle eyebrow="Account / trust" title="Your reputation, made visible." copy="A clear record of how you show up helps good passengers and drivers find each other." /><div className="grid gap-6 xl:grid-cols-[.8fr_1.2fr]"><div className="rounded-2xl bg-[hsl(var(--secondary))] p-6 text-[hsl(var(--secondary-foreground))] md:p-7"><div className="grid h-16 w-16 place-items-center rounded-2xl bg-[hsl(var(--accent))] text-xl font-bold text-[hsl(var(--accent-foreground))]">RR</div><h2 className="display mt-6 text-2xl font-bold">Your account</h2><p className="mt-2 text-sm leading-6 text-[hsl(var(--secondary-foreground)/.58)]">Identity details stay yours. Your scores are built from real trips, not guesses.</p><div className="mt-8 border-t border-[hsl(var(--secondary-foreground)/.12)] pt-5"><div className="flex items-center gap-2 text-sm font-semibold"><BadgeCheck size={17} className="text-[hsl(var(--accent))]" />Trust signals are always explained</div></div></div><div className="space-y-6"><div className="grid gap-4 sm:grid-cols-2">{isLoading ? <><SkeletonBlock className="h-36" /><SkeletonBlock className="h-36" /></> : <><SummaryCard icon={UserRound} label="Passenger score" value={summary?.passengerScore == null ? '—' : `${summary.passengerScore}`} foot={summary?.passengerScore == null ? 'Not rated yet' : 'Based on completed rides'} /><SummaryCard icon={CarFront} label="Driver score" value={summary?.driverScore == null ? '—' : `${summary.driverScore}`} foot={summary?.driverScore == null ? 'Not rated yet' : 'Based on completed trips'} /></>}</div><div className="rounded-2xl border border-[hsl(var(--card-border))] bg-[hsl(var(--card)/.74)] p-6"><div className="eyebrow text-[hsl(var(--primary))]">Your control panel</div><h2 className="display mt-1 text-xl font-bold">Trust by design</h2><div className="mt-5 space-y-4"><div className="flex gap-3"><BadgeCheck size={18} className="mt-0.5 shrink-0 text-[hsl(var(--primary))]" /><div><div className="text-sm font-bold">Transparent choice</div><p className="mt-1 text-xs leading-5 text-[hsl(var(--muted-foreground))]">See the price, ETA, vehicle and completion record before accepting.</p></div></div><div className="flex gap-3"><HeartHandshake size={18} className="mt-0.5 shrink-0 text-[hsl(var(--primary))]" /><div><div className="text-sm font-bold">Mutual accountability</div><p className="mt-1 text-xs leading-5 text-[hsl(var(--muted-foreground))]">Passengers and drivers both contribute to a healthier marketplace.</p></div></div></div></div></div></div></div>;
}

function Router() {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}><Shell><Switch><Route path="/" component={Dashboard} /><Route path="/rides" component={RidesPage} /><Route path="/rides/:id" component={RideDetailPage} /><Route path="/commutes" component={CommutesPage} /><Route path="/driver" component={DriverPage} /><Route path="/safety" component={SafetyPage} /><Route path="/profile" component={ProfilePage} /><Route component={NotFound} /></Switch></Shell></ErrorBoundary>;
}

function App() {
  return <QueryClientProvider client={queryClient}><TooltipProvider><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><Router /></WouterRouter><Toaster /></TooltipProvider></QueryClientProvider>;
}

export default App;