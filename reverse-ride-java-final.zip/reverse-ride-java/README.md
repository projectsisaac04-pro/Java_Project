# ReverseRide

ReverseRide is an AI-powered fair mobility marketplace where passengers define a ride and nearby drivers compete with transparent bids.

This repository contains:

- `artifacts/reverseride` — React + Vite website
- `artifacts/api-server` — Express API adapter and REST routes
- `lib/db` — PostgreSQL schema and Drizzle ORM setup
- `lib/api-spec` — OpenAPI source contract
- `java-core` — Java 21 mobility domain model and bid/value scoring rules

No rides, drivers, bids, scores, or fake activity are seeded. The app starts with empty states and only displays data submitted through its forms or API.

## Requirements

- Node.js 20+
- pnpm 9+
- PostgreSQL
- Java 21 (for the Java domain module)
- Maven (optional, for compiling `java-core`)

## 1. Install dependencies

```bash
pnpm install
```

## 2. Configure PostgreSQL

Set `DATABASE_URL` to your local PostgreSQL connection string.

macOS/Linux:

```bash
export DATABASE_URL="postgresql://postgres:password@localhost:5432/reverseride"
```

Windows PowerShell:

```powershell
$env:DATABASE_URL="postgresql://postgres:password@localhost:5432/reverseride"
```

Then create the tables:

```bash
pnpm --filter @workspace/db run push
```

## 3. Start the API

Open terminal 1:

```bash
export PORT=8080
pnpm --filter @workspace/api-server run dev
```

The API is available at `http://localhost:8080/api`.

## 4. Start the website

Open terminal 2:

```bash
export PORT=5173
export BASE_PATH=/
export LOCAL_API_URL=http://localhost:8080
pnpm --filter @workspace/reverseride run dev
```

Open `http://localhost:5173`.

## One-command local run

After PostgreSQL is running, you can start the database setup, API, and website together:

```bash
pnpm dev:local
```

The launcher uses this default local connection:

```text
postgresql://postgres:postgres@localhost:5432/reverseride
```

If your PostgreSQL username, password, host, port, or database name is different, set `DATABASE_URL` first:

```bash
DATABASE_URL="postgresql://myuser:mypassword@localhost:5432/mydatabase" pnpm dev:local
```

### Windows PowerShell

Run:

```powershell
pnpm install
.\run-local.ps1
```

If your database credentials are different:

```powershell
$env:DATABASE_URL="postgresql://username:password@localhost:5432/database_name"
.\run-local.ps1
```

On Windows PowerShell:

```powershell
$env:PORT="5173"
$env:BASE_PATH="/"
$env:LOCAL_API_URL="http://localhost:8080"
pnpm --filter @workspace/reverseride run dev
```

## 5. Compile the Java domain core

```bash
mvn -q -f java-core/pom.xml compile
```

The Java module contains the core `Ride`, `Bid`, `RideStatus`, `VehicleType`, and `ValueScoreService` domain rules. The current web adapter is Express-based so the supplied pnpm workspace runs immediately; the Java module is isolated and ready to become the deployable Spring Boot service layer.

## Useful checks

```bash
pnpm run typecheck
pnpm --filter @workspace/api-server run typecheck
pnpm --filter @workspace/reverseride run typecheck
```

## Main API routes

- `GET/POST /api/rides`
- `GET/PATCH /api/rides/:rideId`
- `GET/POST /api/rides/:rideId/bids`
- `POST /api/rides/:rideId/bids/:bidId/accept`
- `GET /api/rides/:rideId/fare-explanation`
- `GET /api/rides/:rideId/safety-events`
- `GET/POST /api/commutes`
- `GET /api/driver/demand-radar`
- `GET /api/dashboard/summary`