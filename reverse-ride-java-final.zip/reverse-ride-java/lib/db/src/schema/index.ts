// Export your models here. Add one export per file
// export * from "./posts";
//
// Each model/table should ideally be split into different files.
// Each model/table should define a Drizzle table, insert schema, and types:
//
//   import { pgTable, text, serial } from "drizzle-orm/pg-core";
//   import { createInsertSchema } from "drizzle-zod";
//   import { z } from "zod/v4";
//
//   export const postsTable = pgTable("posts", {
//     id: serial("id").primaryKey(),
//     title: text("title").notNull(),
//   });
//
//   export const insertPostSchema = createInsertSchema(postsTable).omit({ id: true });
//   export type InsertPost = z.infer<typeof insertPostSchema>;
//   export type Post = typeof postsTable.$inferSelect;

import { createInsertSchema } from "drizzle-zod";
import {
  boolean,
  numeric,
  pgTable,
  text,
  timestamp,
} from "drizzle-orm/pg-core";

export const ridesTable = pgTable("rides", {
  id: text("id").primaryKey(),
  pickup: text("pickup").notNull(),
  destination: text("destination").notNull(),
  status: text("status").notNull().default("auction"),
  vehicleType: text("vehicle_type").notNull(),
  passengerCount: numeric("passenger_count").notNull().default("1"),
  targetArrival: timestamp("target_arrival", { withTimezone: true }),
  maxFare: numeric("max_fare"),
  auctionEndsAt: timestamp("auction_ends_at", { withTimezone: true }),
  selectedBidId: text("selected_bid_id"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const bidsTable = pgTable("bids", {
  id: text("id").primaryKey(),
  rideId: text("ride_id").notNull(),
  driverName: text("driver_name").notNull(),
  amount: numeric("amount").notNull(),
  etaMinutes: numeric("eta_minutes").notNull(),
  rating: numeric("rating").notNull(),
  completionRate: numeric("completion_rate").notNull(),
  trustScore: numeric("trust_score").notNull(),
  vehicleLabel: text("vehicle_label").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const commutesTable = pgTable("commutes", {
  id: text("id").primaryKey(),
  label: text("label").notNull(),
  pickup: text("pickup").notNull(),
  destination: text("destination").notNull(),
  daysOfWeek: text("days_of_week").array().notNull(),
  departureTime: text("departure_time").notNull(),
  targetArrival: text("target_arrival").notNull(),
  maxFare: numeric("max_fare").notNull(),
  vehicleType: text("vehicle_type").notNull(),
  active: boolean("active").notNull().default(true),
});

export const insertRideSchema = createInsertSchema(ridesTable);
export const insertBidSchema = createInsertSchema(bidsTable);
export const insertCommuteSchema = createInsertSchema(commutesTable);

export type Ride = typeof ridesTable.$inferSelect;
export type Bid = typeof bidsTable.$inferSelect;
export type Commute = typeof commutesTable.$inferSelect;