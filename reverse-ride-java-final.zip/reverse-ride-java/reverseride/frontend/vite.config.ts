import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';
import path from 'node:path';

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), '');
  // WEB_PORT, not PORT: PORT belongs to the Java API and is set by the launcher.
  const port = Number(env.WEB_PORT || 5173);
  // In development the web app calls /api on its own origin and Vite forwards it to the Java API.
  const apiProxyTarget = env.API_PROXY_TARGET || 'http://localhost:8080';

  return {
    plugins: [react(), tailwindcss()],
    resolve: { alias: { '@': path.resolve(import.meta.dirname, 'src') } },
    server: {
      port,
      strictPort: true,
      proxy: { '/api': { target: apiProxyTarget, changeOrigin: true } },
    },
    preview: { port },
  };
});
