// Typed client for the ReverseRide Java API.

export type Role = 'passenger' | 'driver';
export type VehicleType = 'bike' | 'auto' | 'car' | 'premium';
export type RideStatus = 'draft' | 'auction' | 'booked' | 'active' | 'completed' | 'cancelled';

export const RIDE_STATUSES: RideStatus[] = ['draft', 'auction', 'booked', 'active', 'completed', 'cancelled'];
export const VEHICLE_TYPES: VehicleType[] = ['bike', 'auto', 'car', 'premium'];

export interface AuthConfig {
  googleConfigured: boolean;
  googleClientId: string | null;
}

export interface Me {
  id: string;
  email: string;
  name: string;
  pictureUrl: string | null;
  activeRole: Role;
  roles: Role[];
}

export interface Ride {
  id: string;
  pickup: string;
  destination: string;
  vehicleType: VehicleType;
  passengerCount: number;
  targetArrival: string | null;
  maxFare: number | null;
  status: RideStatus;
  auctionEndsAt: string | null;
  acceptingBids: boolean;
  selectedBidId: string | null;
  bidCount: number;
  createdAt: string;
}

export interface CreateRideInput {
  pickup: string;
  destination: string;
  vehicleType: VehicleType;
  passengerCount: number;
  targetArrival: string | null;
  maxFare: number | null;
  auctionDurationSeconds: number;
}

export interface ScoreComponent {
  factor: 'price' | 'eta' | 'rating' | 'completion' | 'trust';
  label: string;
  weight: number;
  score: number;
  contribution: number;
}

export interface Bid {
  id: string;
  rideId: string;
  driverName: string;
  vehicleLabel: string;
  amount: number;
  etaMinutes: number;
  rating: number;
  completionRate: number;
  trustScore: number;
  createdAt: string;
  selected: boolean;
  valueScore: { total: number; components: ScoreComponent[] };
}

export interface OpenRide {
  id: string;
  pickup: string;
  destination: string;
  vehicleType: VehicleType;
  passengerCount: number;
  targetArrival: string | null;
  maxFare: number | null;
  auctionEndsAt: string;
  bidCount: number;
  myBidAmount: number | null;
}

export interface PlaceBidInput {
  vehicleLabel: string;
  amount: number;
  etaMinutes: number;
  rating: number;
  completionRate: number;
  trustScore: number;
}

export interface DriverTrip {
  id: string;
  pickup: string;
  destination: string;
  vehicleType: VehicleType;
  passengerCount: number;
  targetArrival: string | null;
  status: RideStatus;
  agreedAmount: number;
  etaMinutes: number;
  vehicleLabel: string;
  createdAt: string;
}

export interface SuggestedBid {
  operatingCost: number;
  multiplier: number;
  suggestedBid: number;
  note: string;
}

export interface Commute {
  id: string;
  label: string;
  pickup: string;
  destination: string;
  vehicleType: VehicleType;
  daysOfWeek: string[];
  departureTime: string;
  targetArrival: string;
  maxFare: number;
  active: boolean;
}

export interface CreateCommuteInput {
  label: string;
  pickup: string;
  destination: string;
  vehicleType: VehicleType;
  daysOfWeek: string[];
  departureTime: string;
  targetArrival: string;
  maxFare: number;
}

export interface FareExplanation {
  available: boolean;
  reason: string;
  estimatedTotal: number | null;
  distanceKm: number | null;
  trafficComponent: number | null;
  demandComponent: number | null;
  timeComponent: number | null;
  estimatedMinutes: number | null;
}

export interface SafetyLog {
  available: boolean;
  reason: string;
  events: { id: string; type: string; severity: string; message: string; createdAt: string }[];
}

export interface DashboardSummary {
  activeRides: number;
  completedRides: number;
  savedCommutes: number;
  passengerScore: number | null;
}

/** Error thrown for any non-2xx response; carries the server's message and per-field errors. */
export class ApiError extends Error {
  constructor(
    readonly status: number,
    message: string,
    readonly fieldErrors: Record<string, string> = {},
  ) {
    super(message);
    this.name = 'ApiError';
  }
}

// Empty means "same origin": in development Vite proxies /api to the Java API.
const API_BASE = (import.meta.env.VITE_API_BASE_URL ?? '').replace(/\/+$/, '');

async function request<T>(method: string, path: string, body?: unknown): Promise<T> {
  let response: Response;
  try {
    response = await fetch(`${API_BASE}/api${path}`, {
      method,
      credentials: 'include',
      headers: body === undefined ? undefined : { 'Content-Type': 'application/json' },
      body: body === undefined ? undefined : JSON.stringify(body),
    });
  } catch {
    throw new ApiError(0, 'Could not reach the ReverseRide API. Is the Java server running?');
  }
  if (response.status === 204) return undefined as T;
  const text = await response.text();
  const data = text ? safeJson(text) : null;
  if (!response.ok) {
    const message = (data && typeof data.error === 'string' && data.error) || `Request failed (${response.status})`;
    throw new ApiError(response.status, message, (data && data.fieldErrors) || {});
  }
  return data as T;
}

function safeJson(text: string) {
  try {
    return JSON.parse(text);
  } catch {
    return null;
  }
}

const get = <T>(path: string) => request<T>('GET', path);
const post = <T>(path: string, body?: unknown) => request<T>('POST', path, body);
const patch = <T>(path: string, body?: unknown) => request<T>('PATCH', path, body);

export const api = {
  authConfig: () => get<AuthConfig>('/auth/config'),
  me: () => get<Me>('/auth/me'),
  signInWithGoogle: (credential: string, role: Role) => post<Me>('/auth/google', { credential, role }),
  switchRole: (role: Role) => post<Me>('/auth/role', { role }),
  logout: () => post<void>('/auth/logout'),

  rides: (status?: RideStatus) => get<Ride[]>(status ? `/rides?status=${status}` : '/rides'),
  ride: (id: string) => get<Ride>(`/rides/${id}`),
  createRide: (input: CreateRideInput) => post<Ride>('/rides', input),
  rideBids: (id: string) => get<Bid[]>(`/rides/${id}/bids`),
  acceptBid: (rideId: string, bidId: string) => post<Ride>(`/rides/${rideId}/bids/${bidId}/accept`),
  cancelRide: (id: string) => post<Ride>(`/rides/${id}/cancel`),
  fareExplanation: (id: string) => get<FareExplanation>(`/rides/${id}/fare-explanation`),
  dashboard: () => get<DashboardSummary>('/dashboard/summary'),

  commutes: () => get<Commute[]>('/commutes'),
  createCommute: (input: CreateCommuteInput) => post<Commute>('/commutes', input),
  setCommuteActive: (id: string, active: boolean) => patch<Commute>(`/commutes/${id}`, { active }),

  openRides: () => get<OpenRide[]>('/driver/open-rides'),
  placeBid: (rideId: string, input: PlaceBidInput) => post<OpenRide>(`/driver/rides/${rideId}/bids`, input),
  driverTrips: () => get<DriverTrip[]>('/driver/trips'),
  startTrip: (id: string) => post<DriverTrip>(`/driver/trips/${id}/start`),
  completeTrip: (id: string) => post<DriverTrip>(`/driver/trips/${id}/complete`),
  suggestedBid: (operatingCost: number) => get<SuggestedBid>(`/driver/suggested-bid?operatingCost=${operatingCost}`),

  safetyLog: (rideId: string) => get<SafetyLog>(`/safety/rides/${rideId}`),
};
