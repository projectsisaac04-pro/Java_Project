import type { RideStatus, VehicleType } from './api';

const rupees = new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 2, minimumFractionDigits: 0 });

export function formatMoney(value: number | null | undefined) {
  return value == null ? '—' : rupees.format(value);
}

export function formatDateTime(value: string | null | undefined) {
  if (!value) return 'Not set';
  const date = new Date(value);
  return Number.isNaN(date.getTime())
    ? value
    : date.toLocaleString('en-IN', { day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' });
}

/** "2m 05s left", or null once the time has passed. */
export function timeLeft(until: string | null | undefined, now: number) {
  if (!until) return null;
  const ms = new Date(until).getTime() - now;
  if (ms <= 0) return null;
  const total = Math.ceil(ms / 1000);
  const minutes = Math.floor(total / 60);
  const seconds = total % 60;
  return minutes > 0 ? `${minutes}m ${String(seconds).padStart(2, '0')}s left` : `${seconds}s left`;
}

export const statusLabel: Record<RideStatus, string> = {
  draft: 'Draft',
  auction: 'In auction',
  booked: 'Booked',
  active: 'On trip',
  completed: 'Completed',
  cancelled: 'Cancelled',
};

export const vehicleLabel: Record<VehicleType, string> = {
  bike: 'Bike',
  auto: 'Auto',
  car: 'Car',
  premium: 'Premium',
};

/** Converts a datetime-local value (local time, no zone) to an ISO instant. */
export function localInputToIso(value: string) {
  return value ? new Date(value).toISOString() : null;
}
