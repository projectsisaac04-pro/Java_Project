import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { api, ApiError, type Me, type Role } from './api';
import { disableGoogleAutoSelect } from './google';

export const ME_KEY = ['auth', 'me'] as const;

/** The signed-in user, or null when there is no valid session. */
export function useMe() {
  return useQuery<Me | null>({
    queryKey: ME_KEY,
    queryFn: async () => {
      try {
        return await api.me();
      } catch (error) {
        if (error instanceof ApiError && error.status === 401) return null;
        throw error;
      }
    },
    staleTime: 5 * 60_000,
    retry: false,
  });
}

/** Signing in or switching role changes what every other query returns, so all cached data is dropped. */
export function useSwitchRole() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (role: Role) => api.switchRole(role),
    onSuccess: (me) => {
      client.removeQueries({ predicate: (q) => q.queryKey[0] !== 'auth' });
      client.setQueryData(ME_KEY, me);
    },
  });
}

export function useSignOut() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: () => api.logout(),
    onSettled: () => {
      disableGoogleAutoSelect();
      client.removeQueries({ predicate: (q) => q.queryKey[0] !== 'auth' });
      client.setQueryData(ME_KEY, null);
    },
  });
}

export function homeFor(role: Role) {
  return role === 'driver' ? '/driver' : '/';
}
