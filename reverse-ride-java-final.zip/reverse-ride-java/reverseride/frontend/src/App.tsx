import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Link, Redirect, Route, Switch } from 'wouter';
import { ArrowLeft, Compass } from 'lucide-react';
import { ApiError, type Me } from '@/lib/api';
import { homeFor, useMe } from '@/lib/auth';
import { Shell } from '@/components/Shell';
import { EmptyState, ErrorState, Skeleton } from '@/components/ui';
import { WelcomePage } from '@/pages/WelcomePage';
import { PassengerHomePage } from '@/pages/PassengerHomePage';
import { RidesPage } from '@/pages/RidesPage';
import { RideDetailPage } from '@/pages/RideDetailPage';
import { CommutesPage } from '@/pages/CommutesPage';
import { DriverPage } from '@/pages/DriverPage';
import { SafetyPage } from '@/pages/SafetyPage';
import { ProfilePage } from '@/pages/ProfilePage';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      // A 401/403 will not fix itself on retry.
      retry: (count, error) => !(error instanceof ApiError && error.status >= 400 && error.status < 500) && count < 2,
      refetchOnWindowFocus: true,
    },
  },
});

function AuthGate() {
  const me = useMe();
  if (me.isLoading) {
    return (
      <div className="grid min-h-dvh place-items-center">
        <div className="flex items-center gap-3">
          <span className="grid h-10 w-10 place-items-center rounded-xl bg-orange text-navy"><ArrowLeft size={18} strokeWidth={3} aria-hidden /></span>
          <Skeleton className="h-6 w-40" />
        </div>
      </div>
    );
  }
  if (me.isError) {
    return (
      <div className="mx-auto max-w-lg px-4 py-20">
        <ErrorState message={me.error.message} retry={() => me.refetch()} />
      </div>
    );
  }
  if (!me.data) return <WelcomePage />;
  return <SignedInApp me={me.data} />;
}

function SignedInApp({ me }: { me: Me }) {
  const firstName = me.name.split(' ')[0] || me.name;
  const passenger = me.activeRole === 'passenger';
  const home = homeFor(me.activeRole);
  return (
    <Shell me={me}>
      <Switch>
        <Route path="/">{passenger ? <PassengerHomePage firstName={firstName} /> : <Redirect to={home} />}</Route>
        <Route path="/rides">{passenger ? <RidesPage /> : <Redirect to={home} />}</Route>
        <Route path="/rides/:id">{passenger ? <RideDetailPage /> : <Redirect to={home} />}</Route>
        <Route path="/commutes">{passenger ? <CommutesPage /> : <Redirect to={home} />}</Route>
        <Route path="/driver">{passenger ? <Redirect to={home} /> : <DriverPage firstName={firstName} />}</Route>
        <Route path="/safety"><SafetyPage role={me.activeRole} /></Route>
        <Route path="/profile"><ProfilePage me={me} /></Route>
        <Route>
          <EmptyState icon={Compass} title="Page not found" copy="That address does not exist." action={<Link href={home} className="btn btn-primary">Go home</Link>} />
        </Route>
      </Switch>
    </Shell>
  );
}

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthGate />
    </QueryClientProvider>
  );
}
