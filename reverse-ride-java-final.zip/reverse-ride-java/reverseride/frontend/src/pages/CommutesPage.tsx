import { useState, type FormEvent } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Check, Clock3, MapPin, Pause, Play, Plus, X } from 'lucide-react';
import { api, ApiError, VEHICLE_TYPES, type Commute, type VehicleType } from '@/lib/api';
import { formatMoney, vehicleLabel } from '@/lib/format';
import { EmptyState, ErrorState, FieldError, Notice, PageTitle, Skeleton } from '@/components/ui';

const DAYS = ['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN'];
const initial = { label: '', pickup: '', destination: '', vehicleType: 'car' as VehicleType, days: ['MON', 'TUE', 'WED', 'THU', 'FRI'], departureTime: '08:30', targetArrival: '09:15', maxFare: '' };
type Errors = Partial<Record<'label' | 'pickup' | 'destination' | 'daysOfWeek' | 'departureTime' | 'targetArrival' | 'maxFare', string>>;

export function CommutesPage() {
  const queryClient = useQueryClient();
  const commutes = useQuery({ queryKey: ['commutes'], queryFn: api.commutes });
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState(initial);
  const [errors, setErrors] = useState<Errors>({});
  const [saved, setSaved] = useState(false);

  const create = useMutation({
    mutationFn: api.createCommute,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['commutes'] });
      queryClient.invalidateQueries({ queryKey: ['dashboard'] });
      setSaved(true);
      setOpen(false);
      setForm(initial);
    },
    onError: (e) => e instanceof ApiError && setErrors(e.fieldErrors),
  });

  function submit(event: FormEvent) {
    event.preventDefault();
    const found: Errors = {};
    if (!form.label.trim()) found.label = 'Give this commute a label';
    if (!form.pickup.trim()) found.pickup = 'Add a pickup point';
    if (!form.destination.trim()) found.destination = 'Add a destination';
    if (!form.days.length) found.daysOfWeek = 'Pick at least one day';
    if (!form.departureTime) found.departureTime = 'Set a departure time';
    if (!form.targetArrival) found.targetArrival = 'Set a target arrival';
    const fare = Number(form.maxFare);
    if (!form.maxFare || !Number.isFinite(fare) || fare < 1 || fare > 100000) found.maxFare = 'Between ₹1 and ₹1,00,000';
    setErrors(found);
    if (Object.keys(found).length) return;
    create.mutate({
      label: form.label.trim(),
      pickup: form.pickup.trim(),
      destination: form.destination.trim(),
      vehicleType: form.vehicleType,
      daysOfWeek: form.days,
      departureTime: form.departureTime,
      targetArrival: form.targetArrival,
      maxFare: fare,
    });
  }

  const toggleDay = (day: string) => setForm((f) => ({ ...f, days: f.days.includes(day) ? f.days.filter((d) => d !== day) : [...f.days, day] }));

  return (
    <div className="animate-rise">
      <PageTitle
        eyebrow="Passenger cockpit / rhythm"
        title="Commutes, without autopilot."
        copy="Save the trips you repeat. A saved commute never books anything on its own; you still open each request and choose the driver."
        action={
          <button className="btn btn-primary" onClick={() => { setOpen(!open); setSaved(false); }} aria-expanded={open}>
            <Plus size={16} aria-hidden /> Add commute
          </button>
        }
      />

      {saved && <div className="mb-5"><Notice tone="success">Commute saved.</Notice></div>}

      {open && (
        <form onSubmit={submit} noValidate className="card mb-6 p-5 md:p-6">
          <div className="mb-5 flex items-center justify-between">
            <div>
              <div className="eyebrow text-teal">A repeatable brief</div>
              <h2 className="display mt-1 text-xl font-bold">Save a commute</h2>
            </div>
            <button type="button" className="rounded-lg p-2 text-muted hover:text-ink" onClick={() => setOpen(false)} aria-label="Close form"><X size={17} /></button>
          </div>
          <div className="grid gap-4 md:grid-cols-2">
            <label className="label">Label<input className="field" placeholder="Office mornings" value={form.label} onChange={(e) => setForm({ ...form, label: e.target.value })} maxLength={120} /><FieldError message={errors.label} /></label>
            <label className="label">Vehicle
              <select className="field" value={form.vehicleType} onChange={(e) => setForm({ ...form, vehicleType: e.target.value as VehicleType })}>
                {VEHICLE_TYPES.map((v) => <option key={v} value={v}>{vehicleLabel[v]}</option>)}
              </select>
            </label>
            <label className="label">Pickup<input className="field" value={form.pickup} onChange={(e) => setForm({ ...form, pickup: e.target.value })} maxLength={300} /><FieldError message={errors.pickup} /></label>
            <label className="label">Destination<input className="field" value={form.destination} onChange={(e) => setForm({ ...form, destination: e.target.value })} maxLength={300} /><FieldError message={errors.destination} /></label>
            <label className="label">Leave at<input type="time" className="field" value={form.departureTime} onChange={(e) => setForm({ ...form, departureTime: e.target.value })} /><FieldError message={errors.departureTime} /></label>
            <label className="label">Arrive by<input type="time" className="field" value={form.targetArrival} onChange={(e) => setForm({ ...form, targetArrival: e.target.value })} /><FieldError message={errors.targetArrival} /></label>
            <label className="label">Maximum fare, ₹<input type="number" min={1} step="0.01" className="field" value={form.maxFare} onChange={(e) => setForm({ ...form, maxFare: e.target.value })} /><FieldError message={errors.maxFare} /></label>
          </div>
          <fieldset className="mt-4">
            <legend className="label mb-2">Days</legend>
            <div className="flex flex-wrap gap-2">
              {DAYS.map((day) => {
                const on = form.days.includes(day);
                return (
                  <button type="button" key={day} aria-pressed={on} onClick={() => toggleDay(day)} className={`rounded-lg border px-3 py-2 font-mono text-xs font-medium transition-colors ${on ? 'border-teal bg-teal-soft text-teal-deep' : 'border-line text-muted hover:text-ink'}`}>
                    {day.charAt(0) + day.slice(1).toLowerCase()}
                  </button>
                );
              })}
            </div>
            <FieldError message={errors.daysOfWeek} />
          </fieldset>
          {create.isError && !(create.error instanceof ApiError && Object.keys(create.error.fieldErrors).length) && <div className="mt-4"><Notice tone="error">{create.error.message}</Notice></div>}
          <button className="btn btn-primary mt-5" disabled={create.isPending}>{create.isPending ? 'Saving…' : 'Save commute'}<Check size={15} aria-hidden /></button>
        </form>
      )}

      {commutes.isError ? (
        <ErrorState message={commutes.error.message} retry={() => commutes.refetch()} />
      ) : commutes.isLoading ? (
        <div className="grid gap-4 md:grid-cols-2"><Skeleton className="h-48" /><Skeleton className="h-48" /></div>
      ) : commutes.data?.length ? (
        <div className="grid gap-4 md:grid-cols-2">{commutes.data.map((c) => <CommuteCard key={c.id} commute={c} />)}</div>
      ) : (
        <EmptyState icon={Clock3} title="No saved commutes" copy="Save a route you repeat so it is quicker to describe next time." action={<button className="btn btn-primary" onClick={() => setOpen(true)}>Save a commute <Plus size={15} aria-hidden /></button>} />
      )}
    </div>
  );
}

function CommuteCard({ commute }: { commute: Commute }) {
  const queryClient = useQueryClient();
  const toggle = useMutation({
    mutationFn: () => api.setCommuteActive(commute.id, !commute.active),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['commutes'] }),
  });
  return (
    <article className={`card p-5 ${commute.active ? '' : 'opacity-75'}`}>
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <span className={`inline-flex rounded-full px-2.5 py-1 font-mono text-[0.66rem] uppercase tracking-wider ${commute.active ? 'bg-teal-soft text-teal-deep' : 'bg-cream-deep text-muted'}`}>{commute.active ? 'Active' : 'Paused'}</span>
          <h2 className="display mt-3 truncate text-xl font-bold">{commute.label}</h2>
        </div>
        <button className="btn btn-line px-3 py-1.5 text-xs" onClick={() => toggle.mutate()} disabled={toggle.isPending}>
          {commute.active ? <><Pause size={13} aria-hidden /> Pause</> : <><Play size={13} aria-hidden /> Resume</>}
        </button>
      </div>
      <div className="mt-4 space-y-1.5 text-sm">
        <div className="flex items-center gap-2"><MapPin size={15} className="shrink-0 text-teal" aria-hidden /><span className="truncate">{commute.pickup}</span></div>
        <div className="flex items-center gap-2"><MapPin size={15} className="shrink-0 text-orange" aria-hidden /><span className="truncate">{commute.destination}</span></div>
      </div>
      <dl className="mt-5 grid grid-cols-2 gap-3 border-t border-line pt-4 text-xs sm:grid-cols-4">
        <div><dd className="font-mono font-medium">{commute.daysOfWeek.map((d) => d.charAt(0) + d.slice(1, 3).toLowerCase()).join(' ')}</dd><dt className="text-muted">Days</dt></div>
        <div><dd className="font-mono font-medium">{commute.departureTime}–{commute.targetArrival}</dd><dt className="text-muted">Leave–arrive</dt></div>
        <div><dd className="font-mono font-medium">{vehicleLabel[commute.vehicleType]}</dd><dt className="text-muted">Vehicle</dt></div>
        <div><dd className="font-mono font-medium">{formatMoney(commute.maxFare)}</dd><dt className="text-muted">Max fare</dt></div>
      </dl>
      {toggle.isError && <div className="mt-3"><Notice tone="error">{toggle.error.message}</Notice></div>}
    </article>
  );
}
