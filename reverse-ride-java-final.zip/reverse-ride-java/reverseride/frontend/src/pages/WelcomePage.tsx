import { useEffect, useRef, useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import { ArrowLeft, BadgeCheck, CarFront, Check, Gauge, Scale, UserRound, type LucideIcon } from 'lucide-react';
import { api, type Role } from '@/lib/api';
import { homeFor, ME_KEY } from '@/lib/auth';
import { loadGoogleIdentity } from '@/lib/google';
import { Notice, Skeleton } from '@/components/ui';

const roles: { role: Role; title: string; copy: string; icon: LucideIcon; points: string[] }[] = [
  {
    role: 'passenger',
    title: 'I need a ride',
    copy: 'Describe your trip and compare offers from drivers.',
    icon: UserRound,
    points: ['Set pickup, destination and an optional fare limit', 'See price, ETA and trust side by side', 'You choose the driver'],
  },
  {
    role: 'driver',
    title: 'I drive',
    copy: 'See open requests and send a clear, competitive offer.',
    icon: CarFront,
    points: ['Browse requests while their auction is open', 'Name your own price and ETA', 'Run the trips you win'],
  },
];

/** First screen: pick passenger or driver, then continue with Google. */
export function WelcomePage() {
  const [role, setRole] = useState<Role | null>(null);
  const roleRef = useRef<Role | null>(null);
  roleRef.current = role;
  const buttonRef = useRef<HTMLDivElement>(null);
  const [error, setError] = useState('');
  const [signingIn, setSigningIn] = useState(false);
  const [googleReady, setGoogleReady] = useState(false);
  const queryClient = useQueryClient();
  const [, navigate] = useLocation();
  const config = useQuery({ queryKey: ['auth', 'config'], queryFn: api.authConfig, staleTime: Infinity, retry: 1 });

  const clientId = config.data?.googleConfigured ? config.data.googleClientId : null;

  useEffect(() => {
    if (!clientId || !role || !buttonRef.current) return;
    let cancelled = false;
    setError('');
    loadGoogleIdentity()
      .then((google) => {
        if (cancelled || !buttonRef.current) return;
        google.initialize({
          client_id: clientId,
          ux_mode: 'popup',
          auto_select: false,
          callback: async ({ credential }) => {
            const chosen = roleRef.current;
            if (!chosen) return;
            setSigningIn(true);
            setError('');
            try {
              const me = await api.signInWithGoogle(credential, chosen);
              queryClient.setQueryData(ME_KEY, me);
              navigate(homeFor(me.activeRole));
            } catch (e) {
              setError(e instanceof Error ? e.message : 'Sign-in failed. Please try again.');
            } finally {
              setSigningIn(false);
            }
          },
        });
        buttonRef.current.innerHTML = '';
        google.renderButton(buttonRef.current, { type: 'standard', theme: 'filled_black', size: 'large', text: 'continue_with', shape: 'pill', width: 300 });
        setGoogleReady(true);
      })
      .catch((e: Error) => !cancelled && setError(e.message));
    return () => {
      cancelled = true;
    };
  }, [clientId, role, queryClient, navigate]);

  return (
    <div className="min-h-dvh lg:grid lg:grid-cols-[1.05fr_1fr]">
      <section className="relative overflow-hidden bg-navy px-6 py-10 text-cream md:px-14 md:py-14">
        <div className="flex items-center gap-3">
          <span className="grid h-10 w-10 place-items-center rounded-xl bg-orange text-navy">
            <ArrowLeft size={18} strokeWidth={3} aria-hidden />
          </span>
          <span className="display text-xl font-bold">ReverseRide</span>
        </div>
        <div className="mt-14 max-w-xl lg:mt-24">
          <div className="eyebrow text-orange">Fair mobility marketplace</div>
          <h1 className="display mt-4 text-4xl font-bold leading-[1.05] md:text-6xl">You set the trip. Drivers make the offers.</h1>
          <p className="mt-5 max-w-md text-base leading-7 text-cream/65">
            No unexplained surge. Every offer shows its price, arrival time, vehicle and trust signals together, so the choice stays yours.
          </p>
        </div>
        <ul className="mt-10 grid max-w-xl gap-3 sm:grid-cols-3 lg:mt-16">
          {[
            { icon: Scale, text: 'Offers side by side' },
            { icon: Gauge, text: 'Explained value score' },
            { icon: BadgeCheck, text: 'Passenger decides' },
          ].map(({ icon: Icon, text }) => (
            <li key={text} className="flex items-center gap-2.5 rounded-xl border border-cream/10 bg-cream/5 px-3 py-3 text-sm font-semibold">
              <Icon size={16} className="shrink-0 text-orange" aria-hidden />
              {text}
            </li>
          ))}
        </ul>
      </section>

      <section className="flex items-center px-4 py-10 md:px-14">
        <div className="mx-auto w-full max-w-lg animate-rise">
          <div className="eyebrow text-teal">Step 1 of 2</div>
          <h2 className="display mt-2 text-3xl font-bold">How will you use ReverseRide?</h2>
          <p className="mt-2 text-sm text-muted">You can switch between passenger and driver mode any time after signing in.</p>

          <div className="mt-6 grid gap-3" role="radiogroup" aria-label="Choose how you will use ReverseRide">
            {roles.map(({ role: value, title, copy, icon: Icon, points }) => {
              const selected = role === value;
              return (
                <button
                  key={value}
                  type="button"
                  role="radio"
                  aria-checked={selected}
                  onClick={() => setRole(value)}
                  className={`card flex gap-4 p-5 text-left transition-all ${selected ? 'border-teal ring-2 ring-teal/25' : 'hover:border-teal/40'}`}
                >
                  <span className={`grid h-11 w-11 shrink-0 place-items-center rounded-xl ${selected ? 'bg-teal text-white' : 'bg-cream-deep text-teal'}`}>
                    <Icon size={20} aria-hidden />
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="flex items-center justify-between gap-2">
                      <span className="display text-lg font-bold">{title}</span>
                      <span className={`grid h-5 w-5 place-items-center rounded-full border ${selected ? 'border-teal bg-teal text-white' : 'border-line'}`} aria-hidden>
                        {selected && <Check size={12} strokeWidth={3} />}
                      </span>
                    </span>
                    <span className="mt-1 block text-sm text-muted">{copy}</span>
                    <span className="mt-3 block space-y-1">
                      {points.map((p) => (
                        <span key={p} className="flex items-center gap-2 text-xs text-ink/75">
                          <span className="h-1 w-1 rounded-full bg-orange" aria-hidden />
                          {p}
                        </span>
                      ))}
                    </span>
                  </span>
                </button>
              );
            })}
          </div>

          <div className="mt-8 border-t border-line pt-6">
            <div className="eyebrow text-teal">Step 2 of 2</div>
            <h3 className="display mt-2 text-xl font-bold">Sign in</h3>

            {config.isLoading ? (
              <Skeleton className="mt-4 h-11 w-[300px]" />
            ) : config.isError ? (
              <div className="mt-4">
                <Notice tone="error">{config.error.message}</Notice>
                <button className="btn btn-line mt-3" onClick={() => config.refetch()}>
                  Try again
                </button>
              </div>
            ) : !clientId ? (
              <div className="mt-4">
                <Notice tone="info">
                  Google sign-in is not configured on this server yet. Set <code className="font-mono">GOOGLE_CLIENT_ID</code> for the API and restart it. The README explains how to create the client ID.
                </Notice>
              </div>
            ) : !role ? (
              <p className="mt-3 text-sm text-muted">Choose passenger or driver above to continue with Google.</p>
            ) : (
              <div className="mt-4">
                <p className="mb-3 text-sm text-muted">
                  Continue as a <strong className="text-ink">{role}</strong>.
                </p>
                <div ref={buttonRef} className="min-h-11" aria-busy={!googleReady} />
                {!googleReady && !error && <Skeleton className="h-11 w-[300px]" />}
                {signingIn && <p className="mt-3 text-sm font-semibold text-teal">Signing you in…</p>}
              </div>
            )}
            {error && (
              <div className="mt-4">
                <Notice tone="error">{error}</Notice>
              </div>
            )}
            <p className="mt-6 text-xs leading-5 text-muted">
              We use your Google name, email and profile photo to create your ReverseRide account. We never see your Google password.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}
