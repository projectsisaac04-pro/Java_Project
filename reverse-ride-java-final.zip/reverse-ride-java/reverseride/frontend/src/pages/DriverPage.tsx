import { useState, type FormEvent } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { BadgeCheck, Calculator, Check, Flag, Play, Radio, RefreshCw, Users, Zap } from 'lucide-react';
import { api, ApiError, type DriverTrip, type OpenRide, type PlaceBidInput } from '@/lib/api';
import { formatDateTime, formatMoney, timeLeft, vehicleLabel } from '@/lib/format';
import { VehicleIcon } from '@/components/RideCard';
import { EmptyState, ErrorState, FieldError, Notice, PageTitle, RouteLine, Skeleton, StatusBadge, useNow } from '@/components/ui';

const OPEN_REFRESH_MS = 15_000;

export function DriverPage({ firstName }: { firstName: string }) {
  const now = useNow();
  const open = useQuery({ queryKey: ['driver', 'open'], queryFn: api.openRides, refetchInterval: OPEN_REFRESH_MS });
  const trips = useQuery({ queryKey: ['driver', 'trips'], queryFn: api.driverTrips, refetchInterval: OPEN_REFRESH_MS });
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const visible = open.data?.filter((r) => timeLeft(r.auctionEndsAt, now)) ?? [];
  const selected = visible.find((r) => r.id === selectedId) ?? visible.find((r) => r.myBidAmount == null) ?? visible[0];

  const upcoming = trips.data?.filter((t) => t.status === 'booked' || t.status === 'active') ?? [];
  const past = trips.data?.filter((t) => t.status === 'completed' || t.status === 'cancelled') ?? [];

  return (
    <div className="animate-rise">
      <PageTitle
        eyebrow="Driver workspace"
        title={`Make a clear offer, ${firstName}.`}
        copy="Open requests stay here while their bidding window is open. Passengers compare your price, ETA, vehicle and trust signals together."
        action={<span className="inline-flex items-center gap-1.5 text-xs text-muted"><RefreshCw size={12} aria-hidden /> Refreshes every 15s</span>}
      />

      {!!upcoming.length && (
        <section className="mb-8" aria-labelledby="trips-heading">
          <h2 id="trips-heading" className="display mb-3 text-xl font-bold">Your booked trips</h2>
          <div className="grid gap-4 md:grid-cols-2">{upcoming.map((t) => <TripCard key={t.id} trip={t} />)}</div>
        </section>
      )}

      <div className="grid gap-6 xl:grid-cols-[.95fr_1.05fr]">
        <section className="card p-5 md:p-6" aria-labelledby="open-heading">
          <div className="eyebrow text-teal">Open passenger requests</div>
          <h2 id="open-heading" className="display mt-1 text-xl font-bold">{visible.length} open {visible.length === 1 ? 'request' : 'requests'}</h2>
          <div className="mt-5">
            {open.isError ? (
              <ErrorState message={open.error.message} retry={() => open.refetch()} />
            ) : open.isLoading ? (
              <div className="space-y-3"><Skeleton className="h-24" /><Skeleton className="h-24" /></div>
            ) : visible.length ? (
              <ul className="space-y-3">
                {visible.map((ride) => (
                  <li key={ride.id}>
                    <OpenRideRow ride={ride} now={now} active={selected?.id === ride.id} onSelect={() => setSelectedId(ride.id)} />
                  </li>
                ))}
              </ul>
            ) : (
              <EmptyState icon={Radio} title="No open requests right now" copy="When a passenger opens an auction, it appears here until the bidding window closes." />
            )}
          </div>
        </section>

        <div className="space-y-6">
          {selected ? <BidForm key={selected.id} ride={selected} now={now} /> : (
            <div className="panel-navy p-6">
              <div className="eyebrow text-orange">Place a bid</div>
              <p className="mt-2 text-sm text-cream/60">Select an open request to make an offer.</p>
            </div>
          )}
          <SuggestedBid />
        </div>
      </div>

      {!!past.length && (
        <section className="mt-8" aria-labelledby="history-heading">
          <h2 id="history-heading" className="display mb-3 text-xl font-bold">Trip history</h2>
          <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">{past.map((t) => <TripCard key={t.id} trip={t} />)}</div>
        </section>
      )}
      {trips.isError && <div className="mt-6"><ErrorState message={trips.error.message} retry={() => trips.refetch()} /></div>}
    </div>
  );
}

function OpenRideRow({ ride, now, active, onSelect }: { ride: OpenRide; now: number; active: boolean; onSelect: () => void }) {
  return (
    <button onClick={onSelect} aria-pressed={active} className={`block w-full rounded-xl border p-4 text-left transition-colors ${active ? 'border-teal bg-teal-soft/50' : 'border-line bg-paper hover:border-teal/35'}`}>
      <div className="flex items-start justify-between gap-3">
        <RouteLine pickup={ride.pickup} destination={ride.destination} />
        <span className="shrink-0 rounded-full bg-orange-soft px-2 py-1 font-mono text-[0.66rem] text-[#9a4a12]">{timeLeft(ride.auctionEndsAt, now)}</span>
      </div>
      <div className="mt-3 flex flex-wrap gap-x-4 gap-y-1 border-t border-line pt-3 text-xs text-muted">
        <span className="flex items-center gap-1"><VehicleIcon type={ride.vehicleType} size={13} />{vehicleLabel[ride.vehicleType]}</span>
        <span className="flex items-center gap-1"><Users size={13} aria-hidden />{ride.passengerCount}</span>
        <span>Max {ride.maxFare == null ? 'not set' : formatMoney(ride.maxFare)}</span>
        {ride.targetArrival && <span>Arrive by {formatDateTime(ride.targetArrival)}</span>}
        <span>{ride.bidCount} {ride.bidCount === 1 ? 'offer' : 'offers'}</span>
        {ride.myBidAmount != null && <span className="font-bold text-teal">Your bid {formatMoney(ride.myBidAmount)}</span>}
      </div>
    </button>
  );
}

const emptyBid = { vehicleLabel: '', amount: '', etaMinutes: '', rating: '', completionRate: '', trustScore: '' };
type BidErrors = Partial<Record<keyof typeof emptyBid, string>>;

function validateBid(form: typeof emptyBid, maxFare: number | null): BidErrors {
  const e: BidErrors = {};
  const num = (v: string) => (v.trim() === '' ? NaN : Number(v));
  if (!form.vehicleLabel.trim()) e.vehicleLabel = 'Describe your vehicle';
  const amount = num(form.amount);
  if (!Number.isFinite(amount) || amount < 1 || amount > 100000) e.amount = 'Between ₹1 and ₹1,00,000';
  else if (maxFare != null && amount > maxFare) e.amount = `The passenger's limit is ${formatMoney(maxFare)}`;
  const eta = num(form.etaMinutes);
  if (!Number.isInteger(eta) || eta < 0 || eta > 180) e.etaMinutes = 'Whole minutes, 0–180';
  const rating = num(form.rating);
  if (!Number.isFinite(rating) || rating < 0 || rating > 5) e.rating = 'Between 0 and 5';
  const completion = num(form.completionRate);
  if (!Number.isFinite(completion) || completion < 0 || completion > 100) e.completionRate = 'Between 0 and 100';
  const trust = num(form.trustScore);
  if (!Number.isFinite(trust) || trust < 0 || trust > 100) e.trustScore = 'Between 0 and 100';
  return e;
}

function BidForm({ ride, now }: { ride: OpenRide; now: number }) {
  const queryClient = useQueryClient();
  const [form, setForm] = useState(emptyBid);
  const [errors, setErrors] = useState<BidErrors>({});
  const place = useMutation({
    mutationFn: (input: PlaceBidInput) => api.placeBid(ride.id, input),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['driver', 'open'] }),
    onError: (e) => e instanceof ApiError && setErrors(e.fieldErrors as BidErrors),
  });

  if (ride.myBidAmount != null) {
    return (
      <div className="panel-navy p-6">
        <div className="eyebrow text-orange">Offer sent</div>
        <h3 className="display mt-2 text-xl font-bold">You bid {formatMoney(ride.myBidAmount)} on this ride</h3>
        <p className="mt-2 text-sm text-cream/60">One offer per driver per request. If the passenger chooses you, the trip appears under “Your booked trips”.</p>
      </div>
    );
  }

  function submit(event: FormEvent) {
    event.preventDefault();
    const found = validateBid(form, ride.maxFare);
    setErrors(found);
    if (Object.keys(found).length) return;
    place.mutate({
      vehicleLabel: form.vehicleLabel.trim(),
      amount: Number(form.amount),
      etaMinutes: Number(form.etaMinutes),
      rating: Number(form.rating),
      completionRate: Number(form.completionRate),
      trustScore: Number(form.trustScore),
    });
  }

  const field = (key: keyof typeof emptyBid, label: string, props: React.InputHTMLAttributes<HTMLInputElement>) => (
    <label className="block text-xs font-semibold text-cream/70">
      {label}
      <input className="field-dark" value={form[key]} aria-invalid={!!errors[key]} onChange={(e) => { setForm({ ...form, [key]: e.target.value }); setErrors({ ...errors, [key]: undefined }); }} {...props} />
      <FieldError message={errors[key]} />
    </label>
  );

  return (
    <form onSubmit={submit} noValidate className="panel-navy p-5 md:p-6">
      <div className="eyebrow text-orange">Place your bid</div>
      <h3 className="display mt-2 truncate text-xl font-bold">{ride.pickup} → {ride.destination}</h3>
      <p className="mt-1 text-xs text-cream/50">Bidding closes in {timeLeft(ride.auctionEndsAt, now)?.replace(' left', '') ?? '—'}</p>
      <div className="mt-5 grid gap-4 sm:grid-cols-2">
        <div className="sm:col-span-2">{field('vehicleLabel', 'Vehicle', { placeholder: 'White Swift Dzire · KA 01 AB 1234', maxLength: 120 })}</div>
        {field('amount', 'Your offer, ₹', { type: 'number', min: 1, step: '0.01', inputMode: 'decimal' })}
        {field('etaMinutes', 'ETA to pickup, minutes', { type: 'number', min: 0, max: 180, inputMode: 'numeric' })}
        {field('rating', 'Your rating (0–5)', { type: 'number', min: 0, max: 5, step: '0.1', inputMode: 'decimal' })}
        {field('completionRate', 'Completion rate, %', { type: 'number', min: 0, max: 100, step: '0.01', inputMode: 'decimal' })}
        {field('trustScore', 'Trust score (0–100)', { type: 'number', min: 0, max: 100, step: '0.01', inputMode: 'decimal' })}
      </div>
      <p className="mt-4 flex gap-2 text-[0.72rem] leading-5 text-cream/50">
        <BadgeCheck size={14} className="mt-0.5 shrink-0 text-orange" aria-hidden />
        Rating, completion rate and trust score are self-reported for now and shown to the passenger as entered. No verified rating history exists yet.
      </p>
      {place.isError && !(place.error instanceof ApiError && Object.keys(place.error.fieldErrors).length) && <div className="mt-4"><Notice tone="error">{place.error.message}</Notice></div>}
      <button className="btn btn-accent mt-5 w-full py-3" disabled={place.isPending}>{place.isPending ? 'Sending…' : 'Send offer'}<Zap size={15} aria-hidden /></button>
    </form>
  );
}

function SuggestedBid() {
  const [cost, setCost] = useState('');
  const value = Number(cost);
  const valid = cost !== '' && Number.isFinite(value) && value > 0 && value <= 100000;
  const suggestion = useQuery({ queryKey: ['driver', 'suggested', value], queryFn: () => api.suggestedBid(value), enabled: valid });
  return (
    <section className="card p-5" aria-labelledby="suggest-heading">
      <div className="flex items-center gap-2">
        <Calculator size={17} className="text-teal" aria-hidden />
        <h3 id="suggest-heading" className="font-bold">Bid helper</h3>
      </div>
      <label className="label mt-3">
        Your operating cost for this trip, ₹
        <input type="number" min={1} step="0.01" className="field" value={cost} onChange={(e) => setCost(e.target.value)} placeholder="Fuel, time, wear…" />
      </label>
      {cost !== '' && !valid && <FieldError message="Between ₹1 and ₹1,00,000" />}
      {valid && (suggestion.isLoading ? <Skeleton className="mt-3 h-12" /> : suggestion.isError ? (
        <div className="mt-3"><ErrorState message={suggestion.error.message} /></div>
      ) : suggestion.data && (
        <div className="mt-3 rounded-xl bg-teal-soft p-3">
          <div className="text-sm">Suggested offer <strong className="display text-lg">{formatMoney(suggestion.data.suggestedBid)}</strong> <span className="font-mono text-xs text-muted">= cost × {suggestion.data.multiplier}</span></div>
          <p className="mt-1 text-xs text-muted">{suggestion.data.note}</p>
        </div>
      ))}
    </section>
  );
}

function TripCard({ trip }: { trip: DriverTrip }) {
  const queryClient = useQueryClient();
  const advance = useMutation({
    mutationFn: () => (trip.status === 'booked' ? api.startTrip(trip.id) : api.completeTrip(trip.id)),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['driver'] }),
  });
  return (
    <article className="card p-5">
      <div className="mb-4 flex items-center justify-between">
        <StatusBadge status={trip.status} />
        <span className="display text-lg font-bold">{formatMoney(trip.agreedAmount)}</span>
      </div>
      <RouteLine pickup={trip.pickup} destination={trip.destination} />
      <div className="mt-4 flex flex-wrap gap-x-4 gap-y-1 border-t border-line pt-3 text-xs text-muted">
        <span>{trip.vehicleLabel}</span>
        <span className="flex items-center gap-1"><Users size={13} aria-hidden />{trip.passengerCount}</span>
        {trip.targetArrival && <span>Arrive by {formatDateTime(trip.targetArrival)}</span>}
      </div>
      {advance.isError && <div className="mt-3"><Notice tone="error">{advance.error.message}</Notice></div>}
      {(trip.status === 'booked' || trip.status === 'active') && (
        <button className="btn btn-primary mt-4 w-full" onClick={() => advance.mutate()} disabled={advance.isPending}>
          {trip.status === 'booked' ? <><Play size={15} aria-hidden /> {advance.isPending ? 'Starting…' : 'Start trip (passenger picked up)'}</> : <><Flag size={15} aria-hidden /> {advance.isPending ? 'Finishing…' : 'Complete trip'}</>}
        </button>
      )}
      {trip.status === 'completed' && <p className="mt-3 flex items-center gap-1.5 text-xs font-semibold text-teal"><Check size={13} aria-hidden /> Completed</p>}
    </article>
  );
}

