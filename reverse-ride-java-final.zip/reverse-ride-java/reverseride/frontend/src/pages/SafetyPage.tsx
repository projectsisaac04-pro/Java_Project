import { useQuery } from '@tanstack/react-query';
import { Link } from 'wouter';
import { Activity, ArrowRight, LifeBuoy, LockKeyhole, Navigation, ShieldCheck, ShieldOff } from 'lucide-react';
import { api, type Role } from '@/lib/api';
import { EmptyState, ErrorState, Notice, PageTitle, RouteLine, Skeleton } from '@/components/ui';

/** Shows the user's active trip and its safety log. Integrations are not connected and the page says so. */
export function SafetyPage({ role }: { role: Role }) {
  const passengerRides = useQuery({ queryKey: ['rides', 'active'], queryFn: () => api.rides('active'), enabled: role === 'passenger' });
  const driverTrips = useQuery({ queryKey: ['driver', 'trips'], queryFn: api.driverTrips, enabled: role === 'driver' });
  const source = role === 'passenger' ? passengerRides : driverTrips;
  const activeTrip = role === 'passenger'
    ? passengerRides.data?.[0]
    : driverTrips.data?.find((t) => t.status === 'active');
  const log = useQuery({ queryKey: ['safety', activeTrip?.id], queryFn: () => api.safetyLog(activeTrip!.id), enabled: !!activeTrip });

  return (
    <div className="animate-rise">
      <PageTitle eyebrow="Protection layer" title="Safety, in the foreground." copy="Your active trip and its safety log, without hunting through menus." />

      <div className="mb-6">
        <Notice tone="info">
          Live trip monitoring, emergency contact and automatic safety-event recording are <strong>not connected yet</strong>. In an emergency, call 112.
        </Notice>
      </div>

      <div className="mb-6 grid gap-4 sm:grid-cols-3">
        {[
          { icon: ShieldOff, title: 'Trip monitoring', copy: 'Not available yet. Trips are not tracked.' },
          { icon: LifeBuoy, title: 'Emergency help', copy: 'Not connected. Use 112 for emergencies.' },
          { icon: LockKeyhole, title: 'Private by design', copy: 'Only your own active trip appears here.' },
        ].map(({ icon: Icon, title, copy }) => (
          <div key={title} className="card p-5">
            <Icon className="mb-4 text-teal" size={20} aria-hidden />
            <div className="font-bold">{title}</div>
            <p className="mt-1 text-xs leading-5 text-muted">{copy}</p>
          </div>
        ))}
      </div>

      {source.isLoading ? (
        <Skeleton className="h-56" />
      ) : source.isError ? (
        <ErrorState message={source.error.message} retry={() => source.refetch()} />
      ) : activeTrip ? (
        <div className="grid gap-6 xl:grid-cols-[1fr_.85fr]">
          <section className="card p-6">
            <div className="eyebrow text-teal">Active trip</div>
            <div className="mt-4"><RouteLine pickup={activeTrip.pickup} destination={activeTrip.destination} /></div>
            <div className="mt-6 flex items-center gap-3 rounded-xl bg-cream-deep/60 p-4">
              <div className="grid h-10 w-10 place-items-center rounded-xl bg-navy text-orange"><Navigation size={17} aria-hidden /></div>
              <div>
                <div className="text-sm font-bold">Trip in progress</div>
                <div className="font-mono text-xs text-muted">Ride {activeTrip.id.slice(0, 8)}</div>
              </div>
            </div>
          </section>
          <section className="card p-6">
            <div className="mb-4 flex items-center justify-between">
              <div>
                <div className="eyebrow text-teal">Safety log</div>
                <h2 className="display mt-1 text-xl font-bold">Events</h2>
              </div>
              <Activity size={18} className="text-muted" aria-hidden />
            </div>
            {log.isLoading ? <Skeleton className="h-24" /> : log.isError ? <ErrorState message={log.error.message} retry={() => log.refetch()} /> : log.data?.available ? (
              log.data.events.length ? (
                <ul className="space-y-2">{log.data.events.map((e) => <li key={e.id} className="rounded-xl border border-line p-3 text-sm"><strong>{e.type}</strong> {e.message}</li>)}</ul>
              ) : <p className="text-sm text-muted">No events recorded for this trip.</p>
            ) : (
              <EmptyState icon={ShieldOff} title="Safety log unavailable" copy={log.data?.reason ?? 'Safety-event recording is not connected yet.'} />
            )}
          </section>
        </div>
      ) : (
        <EmptyState
          icon={ShieldCheck}
          title="No active trip"
          copy={role === 'passenger' ? 'When a driver starts your booked trip, it appears here.' : 'When you start a booked trip, it appears here.'}
          action={role === 'passenger'
            ? <Link href="/" className="btn btn-primary">Request a ride <ArrowRight size={15} aria-hidden /></Link>
            : <Link href="/driver" className="btn btn-primary">Driver workspace <ArrowRight size={15} aria-hidden /></Link>}
        />
      )}
    </div>
  );
}
