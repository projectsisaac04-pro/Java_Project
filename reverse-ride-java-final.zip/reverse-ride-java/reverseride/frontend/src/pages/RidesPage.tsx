import { useQuery } from '@tanstack/react-query';
import { Link, useSearchParams } from 'wouter';
import { Plus, Route as RouteIcon } from 'lucide-react';
import { api, RIDE_STATUSES, type RideStatus } from '@/lib/api';
import { statusLabel } from '@/lib/format';
import { RideCard } from '@/components/RideCard';
import { EmptyState, ErrorState, PageTitle, Skeleton, useNow } from '@/components/ui';

export function RidesPage() {
  const [params, setParams] = useSearchParams();
  const raw = params.get('status');
  const status = RIDE_STATUSES.includes(raw as RideStatus) ? (raw as RideStatus) : undefined;
  const rides = useQuery({ queryKey: ['rides', status ?? 'all'], queryFn: () => api.rides(status) });
  const now = useNow();

  const filters: { value?: RideStatus; label: string }[] = [{ label: 'All' }, ...RIDE_STATUSES.filter((s) => s !== 'draft').map((s) => ({ value: s, label: statusLabel[s] }))];

  return (
    <div className="animate-rise">
      <PageTitle
        eyebrow="Passenger cockpit / history"
        title="Ride requests"
        copy="Open auctions, booked trips and everything you have finished or cancelled."
        action={<Link href="/" className="btn btn-primary"><Plus size={16} aria-hidden /> New request</Link>}
      />

      <div className="mb-6 flex flex-wrap gap-2" role="group" aria-label="Filter by status">
        {filters.map((f) => {
          const active = f.value === status;
          return (
            <button
              key={f.label}
              aria-pressed={active}
              onClick={() => setParams(f.value ? { status: f.value } : {})}
              className={`rounded-full border px-3.5 py-1.5 text-xs font-bold transition-colors ${active ? 'border-teal bg-teal text-white' : 'border-line bg-paper text-muted hover:border-teal/40 hover:text-ink'}`}
            >
              {f.label}
            </button>
          );
        })}
      </div>

      {rides.isError ? (
        <ErrorState message={rides.error.message} retry={() => rides.refetch()} />
      ) : rides.isLoading ? (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">{Array.from({ length: 3 }, (_, i) => <Skeleton key={i} className="h-[200px]" />)}</div>
      ) : rides.data?.length ? (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">{rides.data.map((ride) => <RideCard key={ride.id} ride={ride} now={now} />)}</div>
      ) : (
        <EmptyState
          icon={RouteIcon}
          title={status ? `No ${statusLabel[status].toLowerCase()} rides` : 'No ride requests yet'}
          copy={status ? 'Try another filter, or open a new request.' : 'Your first request opens a transparent mini-marketplace for your trip.'}
          action={<Link href="/" className="btn btn-primary">Request a ride</Link>}
        />
      )}
    </div>
  );
}
