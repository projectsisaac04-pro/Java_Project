import { useMemo, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Link, useParams } from 'wouter';
import { ArrowLeft, Check, ChevronDown, Info, LockKeyhole, Radio, RefreshCw, Users, X } from 'lucide-react';
import { api, type Bid, type Ride } from '@/lib/api';
import { formatDateTime, formatMoney, timeLeft, vehicleLabel } from '@/lib/format';
import { VehicleIcon } from '@/components/RideCard';
import { EmptyState, ErrorState, Notice, RouteLine, Skeleton, StatusBadge, useNow } from '@/components/ui';

const LIVE_REFRESH_MS = 10_000;

export function RideDetailPage() {
  const { id = '' } = useParams<{ id: string }>();
  const queryClient = useQueryClient();
  const now = useNow();
  const ride = useQuery({
    queryKey: ['rides', 'detail', id],
    queryFn: () => api.ride(id),
    refetchInterval: (q) => (q.state.data?.status === 'auction' ? LIVE_REFRESH_MS : false),
  });
  const inAuction = ride.data?.status === 'auction';
  const bids = useQuery({
    queryKey: ['rides', 'bids', id],
    queryFn: () => api.rideBids(id),
    enabled: !!ride.data,
    refetchInterval: inAuction ? LIVE_REFRESH_MS : false,
  });
  const fare = useQuery({ queryKey: ['rides', 'fare', id], queryFn: () => api.fareExplanation(id), enabled: !!ride.data });

  const refreshRide = () => {
    queryClient.invalidateQueries({ queryKey: ['rides'] });
    queryClient.invalidateQueries({ queryKey: ['dashboard'] });
  };
  const accept = useMutation({ mutationFn: (bidId: string) => api.acceptBid(id, bidId), onSuccess: refreshRide });
  const cancel = useMutation({ mutationFn: () => api.cancelRide(id), onSuccess: refreshRide });
  const [confirmCancel, setConfirmCancel] = useState(false);
  const [sort, setSort] = useState<'price' | 'value'>('price');

  const sortedBids = useMemo(() => {
    const list = [...(bids.data ?? [])];
    return sort === 'value' ? list.sort((a, b) => b.valueScore.total - a.valueScore.total) : list;
  }, [bids.data, sort]);
  const topScore = bids.data?.length ? Math.max(...bids.data.map((b) => b.valueScore.total)) : null;

  if (ride.isLoading) return <div><Skeleton className="mb-5 h-8 w-40" /><Skeleton className="h-[420px]" /></div>;
  if (ride.isError || !ride.data) {
    return (
      <div className="space-y-4">
        <BackLink />
        <ErrorState message={ride.error?.message ?? 'Ride not found.'} retry={() => ride.refetch()} />
      </div>
    );
  }

  const r = ride.data;
  const left = inAuction ? timeLeft(r.auctionEndsAt, now) : null;
  const canCancel = r.status === 'auction' || r.status === 'booked' || r.status === 'draft';

  return (
    <div className="animate-rise">
      <BackLink />
      <div className="mb-8 flex flex-col justify-between gap-5 md:flex-row md:items-end">
        <div className="min-w-0">
          <div className="eyebrow mb-3 text-teal">Request · {r.id.slice(0, 8)}</div>
          <h1 className="display break-words text-3xl font-bold md:text-[2.4rem] md:leading-tight">
            {r.pickup} <span className="text-orange">→</span> {r.destination}
          </h1>
          <p className="mt-2 text-sm text-muted">Requested {formatDateTime(r.createdAt)}</p>
        </div>
        <StatusBadge status={r.status} />
      </div>

      <div className="grid gap-6 xl:grid-cols-[1.15fr_.85fr]">
        <section className="card p-5 md:p-6" aria-labelledby="offers-heading">
          <div className="mb-5 flex flex-wrap items-start justify-between gap-3">
            <div>
              <div className="eyebrow text-teal">Driver offers</div>
              <h2 id="offers-heading" className="display mt-1 text-xl font-bold">
                {bids.data?.length ?? 0} {bids.data?.length === 1 ? 'offer' : 'offers'} to compare
              </h2>
              {inAuction && (
                <p className="mt-1 flex items-center gap-1.5 text-xs text-muted">
                  <RefreshCw size={12} aria-hidden /> {left ? `Bidding open · ${left}` : 'Bidding closed. You can still choose an offer.'} · refreshes every 10s
                </p>
              )}
            </div>
            {!!bids.data?.length && (
              <div className="flex rounded-xl border border-line bg-cream-deep/50 p-1 text-xs font-bold" role="group" aria-label="Sort offers">
                {(['price', 'value'] as const).map((s) => (
                  <button key={s} aria-pressed={sort === s} onClick={() => setSort(s)} className={`rounded-lg px-3 py-1.5 ${sort === s ? 'bg-paper text-ink shadow-sm' : 'text-muted'}`}>
                    {s === 'price' ? 'Lowest price' : 'Value score'}
                  </button>
                ))}
              </div>
            )}
          </div>

          {accept.isSuccess && <div className="mb-4"><Notice tone="success">Ride booked. Your chosen driver will see it in their workspace the next time it refreshes.</Notice></div>}
          {accept.isError && <div className="mb-4"><Notice tone="error">{accept.error.message}</Notice></div>}

          {bids.isLoading ? (
            <Skeleton className="h-40" />
          ) : bids.isError ? (
            <ErrorState message={bids.error.message} retry={() => bids.refetch()} />
          ) : sortedBids.length ? (
            <ul className="space-y-3">
              {sortedBids.map((bid) => (
                <li key={bid.id}>
                  <BidCard
                    bid={bid}
                    ride={r}
                    best={bids.data!.length > 1 && bid.valueScore.total === topScore}
                    pending={accept.isPending && accept.variables === bid.id}
                    disabled={accept.isPending}
                    onAccept={() => accept.mutate(bid.id)}
                  />
                </li>
              ))}
            </ul>
          ) : (
            <EmptyState
              icon={Radio}
              title={inAuction && left ? 'Waiting for offers' : 'No offers received'}
              copy={inAuction && left ? 'Drivers in driver mode can see your request now. Offers appear here as they arrive.' : 'This request closed without any offers. You can open a new request.'}
              action={!left ? <Link href="/" className="btn btn-primary">New request</Link> : undefined}
            />
          )}
        </section>

        <div className="space-y-6">
          <section className="card p-5 md:p-6">
            <div className="eyebrow text-teal">Trip brief</div>
            <div className="mt-4"><RouteLine pickup={r.pickup} destination={r.destination} /></div>
            <dl className="mt-5 grid grid-cols-2 gap-4 border-t border-line pt-5 text-sm">
              <Detail label="Vehicle"><span className="flex items-center gap-1.5"><VehicleIcon type={r.vehicleType} size={15} className="text-teal" />{vehicleLabel[r.vehicleType]}</span></Detail>
              <Detail label="Passengers"><span className="flex items-center gap-1.5"><Users size={15} className="text-teal" aria-hidden />{r.passengerCount}</span></Detail>
              <Detail label="Target arrival">{formatDateTime(r.targetArrival)}</Detail>
              <Detail label="Maximum fare">{r.maxFare == null ? 'No limit' : formatMoney(r.maxFare)}</Detail>
              <Detail label="Bidding closes">{formatDateTime(r.auctionEndsAt)}</Detail>
            </dl>
            {canCancel && (
              <div className="mt-5 border-t border-line pt-5">
                {cancel.isError && <div className="mb-3"><Notice tone="error">{cancel.error.message}</Notice></div>}
                {confirmCancel ? (
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-sm font-semibold">Cancel this ride?</span>
                    <button className="btn bg-danger px-3 py-2 text-white hover:brightness-95" onClick={() => cancel.mutate()} disabled={cancel.isPending}>
                      {cancel.isPending ? 'Cancelling…' : 'Yes, cancel'}
                    </button>
                    <button className="btn btn-line px-3 py-2" onClick={() => setConfirmCancel(false)}>Keep it</button>
                  </div>
                ) : (
                  <button className="btn btn-line text-danger" onClick={() => setConfirmCancel(true)}><X size={15} aria-hidden /> Cancel ride</button>
                )}
              </div>
            )}
          </section>

          <section className="card p-5 md:p-6" aria-labelledby="fare-heading">
            <div className="eyebrow text-teal">Fare lens</div>
            <h2 id="fare-heading" className="display mt-1 text-xl font-bold">Fare breakdown</h2>
            {fare.isLoading ? (
              <Skeleton className="mt-4 h-28" />
            ) : fare.isError ? (
              <div className="mt-4"><ErrorState message={fare.error.message} retry={() => fare.refetch()} /></div>
            ) : (
              <>
                {!fare.data?.available && <div className="mt-4"><Notice tone="info">{fare.data?.reason}</Notice></div>}
                <dl className="mt-4 space-y-2.5 text-sm">
                  {[
                    ['Estimated total', fare.data?.estimatedTotal, formatMoney],
                    ['Route distance', fare.data?.distanceKm, (v: number) => `${v} km`],
                    ['Traffic component', fare.data?.trafficComponent, formatMoney],
                    ['Demand component', fare.data?.demandComponent, formatMoney],
                    ['Time component', fare.data?.timeComponent, formatMoney],
                    ['Estimated duration', fare.data?.estimatedMinutes, (v: number) => `${v} min`],
                  ].map(([label, value, fmt]) => (
                    <div key={label as string} className="flex justify-between gap-4">
                      <dt className="text-muted">{label as string}</dt>
                      <dd className="font-mono text-xs">{value == null ? 'Not calculated' : (fmt as (v: number) => string)(value as number)}</dd>
                    </div>
                  ))}
                </dl>
              </>
            )}
          </section>

          <div className="panel-navy flex gap-3 p-5">
            <LockKeyhole className="mt-0.5 shrink-0 text-orange" size={18} aria-hidden />
            <div>
              <h3 className="font-bold">The choice stays yours</h3>
              <p className="mt-1 text-sm leading-6 text-cream/60">The value score explains trade-offs; it never books a driver for you. Ratings, completion rates and trust scores are currently self-reported by drivers.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function BackLink() {
  return (
    <Link href="/rides" className="mb-6 inline-flex items-center gap-2 text-sm font-bold text-muted hover:text-ink">
      <ArrowLeft size={16} aria-hidden /> Back to rides
    </Link>
  );
}

function Detail({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <dt className="eyebrow text-muted">{label}</dt>
      <dd className="mt-1 font-semibold">{children}</dd>
    </div>
  );
}

function BidCard({ bid, ride, best, pending, disabled, onAccept }: { bid: Bid; ride: Ride; best: boolean; pending: boolean; disabled: boolean; onAccept: () => void }) {
  const [open, setOpen] = useState(false);
  const canAccept = ride.status === 'auction' && !ride.selectedBidId;
  return (
    <article className={`rounded-xl border bg-paper p-4 transition-colors ${bid.selected ? 'border-teal ring-2 ring-teal/20' : 'border-line hover:border-teal/35'}`} aria-label={`Offer from ${bid.driverName}`}>
      <div className="flex items-start justify-between gap-3">
        <div className="flex min-w-0 items-center gap-3">
          <div className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-navy font-bold text-orange">{bid.driverName.slice(0, 1).toUpperCase()}</div>
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2">
              <span className="truncate font-bold">{bid.driverName}</span>
              {bid.selected && <span className="rounded-full bg-teal px-2 py-0.5 font-mono text-[0.62rem] uppercase tracking-wider text-white">Chosen</span>}
              {best && !bid.selected && <span className="rounded-full bg-orange-soft px-2 py-0.5 font-mono text-[0.62rem] uppercase tracking-wider text-[#9a4a12]">Top value</span>}
            </div>
            <div className="mt-0.5 truncate text-xs text-muted">{bid.vehicleLabel}</div>
          </div>
        </div>
        <div className="text-right">
          <div className="display text-xl font-bold">{formatMoney(bid.amount)}</div>
          <div className="text-xs text-muted">{bid.etaMinutes} min away</div>
        </div>
      </div>

      <dl className="mt-4 grid grid-cols-4 gap-2 border-t border-line pt-3 text-xs">
        <Metric label="Rating" value={bid.rating.toFixed(1)} />
        <Metric label="Completion" value={`${bid.completionRate}%`} />
        <Metric label="Trust" value={String(bid.trustScore)} />
        <Metric label="Value score" value={bid.valueScore.total.toFixed(1)} highlight />
      </dl>

      <button className="mt-3 flex items-center gap-1 text-xs font-bold text-teal" aria-expanded={open} onClick={() => setOpen(!open)}>
        <ChevronDown size={14} className={`transition-transform ${open ? 'rotate-180' : ''}`} aria-hidden />
        {open ? 'Hide' : 'Show'} score breakdown
      </button>
      {open && (
        <div className="mt-3 space-y-2 rounded-xl bg-cream-deep/50 p-3">
          {bid.valueScore.components.map((c) => (
            <div key={c.factor} className="grid grid-cols-[110px_1fr_auto] items-center gap-3 text-xs">
              <span className="font-semibold">{c.label} <span className="font-mono text-muted">{Math.round(c.weight * 100)}%</span></span>
              <span className="h-1.5 overflow-hidden rounded-full bg-line" aria-hidden>
                <span className="block h-full rounded-full bg-teal" style={{ width: `${c.score}%` }} />
              </span>
              <span className="font-mono text-muted">{c.score.toFixed(0)} → +{c.contribution.toFixed(1)}</span>
            </div>
          ))}
          <p className="flex gap-1.5 pt-1 text-[0.7rem] leading-5 text-muted">
            <Info size={12} className="mt-0.5 shrink-0" aria-hidden />
            Price and ETA are scored against the best offer on this ride (best = 100). Rating is out of 5; completion and trust are already 0–100.
          </p>
        </div>
      )}

      {canAccept && (
        <button className="btn btn-primary mt-4 w-full" onClick={onAccept} disabled={disabled}>
          {pending ? 'Booking…' : `Choose ${bid.driverName.split(' ')[0]} for ${formatMoney(bid.amount)}`}
          <Check size={15} aria-hidden />
        </button>
      )}
    </article>
  );
}

function Metric({ label, value, highlight = false }: { label: string; value: string; highlight?: boolean }) {
  return (
    <div>
      <dd className={`font-mono text-sm font-medium ${highlight ? 'text-teal' : ''}`}>{value}</dd>
      <dt className="text-muted">{label}</dt>
    </div>
  );
}
