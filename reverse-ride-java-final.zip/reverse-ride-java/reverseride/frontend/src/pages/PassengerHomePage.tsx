import { useQuery } from '@tanstack/react-query';
import { Link } from 'wouter';
import { ArrowRight, Check, Clock3, Gauge, Info, Navigation } from 'lucide-react';
import { api } from '@/lib/api';
import { RideRequestForm } from '@/components/RideRequestForm';
import { RideCard } from '@/components/RideCard';
import { EmptyState, ErrorState, PageTitle, Skeleton, SummaryCard, useNow } from '@/components/ui';

export function PassengerHomePage({ firstName }: { firstName: string }) {
  const summary = useQuery({ queryKey: ['dashboard'], queryFn: api.dashboard });
  const rides = useQuery({ queryKey: ['rides', 'all'], queryFn: () => api.rides() });
  const now = useNow();
  const current = rides.data?.filter((r) => r.status === 'auction' || r.status === 'booked' || r.status === 'active').slice(0, 3) ?? [];
  const recent = current.length ? current : rides.data?.slice(0, 2) ?? [];

  return (
    <div className="animate-rise">
      <PageTitle
        eyebrow="Passenger cockpit"
        title={`Move on your terms, ${firstName}.`}
        copy="Describe your trip, let drivers bring their offers, and choose with the full picture."
        action={<Link href="/rides" className="btn btn-line">All rides <ArrowRight size={16} aria-hidden /></Link>}
      />

      {summary.isError && <div className="mb-5"><ErrorState message={summary.error.message} retry={() => summary.refetch()} /></div>}
      <div className="mb-8 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {summary.isLoading ? (
          Array.from({ length: 4 }, (_, i) => <Skeleton key={i} className="h-[138px]" />)
        ) : (
          <>
            <SummaryCard accent icon={Navigation} label="Active rides" value={String(summary.data?.activeRides ?? 0)} foot="In auction, booked or on trip" />
            <SummaryCard icon={Check} label="Completed" value={String(summary.data?.completedRides ?? 0)} foot="Finished trips" />
            <SummaryCard icon={Clock3} label="Saved commutes" value={String(summary.data?.savedCommutes ?? 0)} foot="Reusable trip briefs" />
            <SummaryCard
              icon={Gauge}
              label="Passenger score"
              value={summary.data?.passengerScore == null ? '—' : String(summary.data.passengerScore)}
              foot={summary.data?.passengerScore == null ? 'Not earned yet: no ratings exist' : 'From rated trips'}
            />
          </>
        )}
      </div>

      <div className="grid gap-6 xl:grid-cols-[1.1fr_.9fr]">
        <RideRequestForm />
        <div className="space-y-5">
          <div>
            <div className="eyebrow text-teal">{current.length ? 'In motion' : 'Recent'}</div>
            <h2 className="display mt-1 text-xl font-bold">{current.length ? 'Your active rides' : 'Your latest requests'}</h2>
          </div>
          {rides.isLoading ? (
            <Skeleton className="h-[200px]" />
          ) : rides.isError ? (
            <ErrorState message={rides.error.message} retry={() => rides.refetch()} />
          ) : recent.length ? (
            <div className="space-y-3">{recent.map((ride) => <RideCard key={ride.id} ride={ride} now={now} />)}</div>
          ) : (
            <EmptyState icon={Navigation} title="Your next ride starts here" copy="Open a request and nearby drivers can send clear, comparable offers." />
          )}
          <div className="card flex items-start gap-3 p-5">
            <div className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-orange-soft text-[#9a4a12]"><Info size={17} aria-hidden /></div>
            <div>
              <h3 className="font-bold">How it works</h3>
              <p className="mt-1 text-sm leading-6 text-muted">
                Drivers bid during your bidding window. Each offer shows its price, ETA, vehicle, rating, completion rate and trust score, plus a value score that explains how they compare. You pick one.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
