import { useQuery } from '@tanstack/react-query';
import { BadgeCheck, CarFront, Gauge, HeartHandshake, Scale, UserRound } from 'lucide-react';
import type { Me } from '@/lib/api';
import { api } from '@/lib/api';
import { PageTitle, Skeleton, SummaryCard } from '@/components/ui';

const factors = [
  { label: 'Price', weight: 25, how: 'Compared with the cheapest offer on the same ride. Cheapest = 100; twice the price = 50.' },
  { label: 'Arrival time', weight: 20, how: 'Compared with the fastest offer: (fastest + 1) ÷ (ETA + 1) × 100.' },
  { label: 'Rating', weight: 20, how: 'Rating out of 5, scaled to 0–100.' },
  { label: 'Completion rate', weight: 15, how: 'Share of accepted trips completed, already 0–100.' },
  { label: 'Trust score', weight: 20, how: 'Trust signal on a 0–100 scale.' },
];

export function ProfilePage({ me }: { me: Me }) {
  const summary = useQuery({ queryKey: ['dashboard'], queryFn: api.dashboard, enabled: me.activeRole === 'passenger' });

  return (
    <div className="animate-rise">
      <PageTitle eyebrow="Account & trust" title="Your reputation, explained." copy="How ReverseRide compares offers, and what we know about your account." />
      <div className="grid gap-6 xl:grid-cols-[.8fr_1.2fr]">
        <section className="panel-navy p-6 md:p-7">
          {me.pictureUrl ? (
            <img src={me.pictureUrl} alt="" referrerPolicy="no-referrer" className="h-16 w-16 rounded-2xl object-cover" />
          ) : (
            <div className="grid h-16 w-16 place-items-center rounded-2xl bg-orange text-2xl font-bold text-navy">{me.name.slice(0, 1).toUpperCase()}</div>
          )}
          <h2 className="display mt-5 text-2xl font-bold">{me.name}</h2>
          <p className="mt-1 text-sm text-cream/60">{me.email}</p>
          <dl className="mt-6 space-y-3 border-t border-cream/10 pt-5 text-sm">
            <div className="flex justify-between"><dt className="text-cream/55">Signed in with</dt><dd className="font-semibold">Google</dd></div>
            <div className="flex justify-between"><dt className="text-cream/55">Current mode</dt><dd className="font-semibold capitalize">{me.activeRole}</dd></div>
            <div className="flex justify-between"><dt className="text-cream/55">Modes used</dt><dd className="font-semibold capitalize">{me.roles.join(' & ')}</dd></div>
          </dl>
          <p className="mt-6 flex gap-2 text-xs leading-5 text-cream/55">
            <BadgeCheck size={15} className="shrink-0 text-orange" aria-hidden />
            Driver identity, licence and vehicle checks are not implemented. Any Google account can use driver mode.
          </p>
        </section>

        <div className="space-y-6">
          <div className="grid gap-4 sm:grid-cols-2">
            {me.activeRole === 'passenger' && summary.isLoading ? <><Skeleton className="h-36" /><Skeleton className="h-36" /></> : (
              <>
                <SummaryCard icon={UserRound} label="Passenger score" value={summary.data?.passengerScore == null ? '—' : String(summary.data.passengerScore)} foot="Not earned yet: no rating history exists" />
                <SummaryCard icon={CarFront} label="Driver score" value="—" foot="Not earned yet: no rating history exists" />
              </>
            )}
          </div>

          <section className="card p-6" aria-labelledby="value-heading">
            <div className="flex items-center gap-2">
              <Scale size={18} className="text-teal" aria-hidden />
              <h2 id="value-heading" className="display text-xl font-bold">How the value score works</h2>
            </div>
            <p className="mt-2 text-sm leading-6 text-muted">Each factor is first put on a 0–100 scale, so rupees and minutes are never mixed with percentages. The weighted sum is the value score. It explains trade-offs; it never picks a driver.</p>
            <ul className="mt-5 space-y-3">
              {factors.map((f) => (
                <li key={f.label} className="grid grid-cols-[1fr_auto] gap-x-4 gap-y-1 rounded-xl border border-line p-3">
                  <span className="text-sm font-bold">{f.label}</span>
                  <span className="font-mono text-sm text-teal">{f.weight}%</span>
                  <span className="col-span-2 text-xs leading-5 text-muted">{f.how}</span>
                  <span className="col-span-2 h-1.5 overflow-hidden rounded-full bg-cream-deep" aria-hidden>
                    <span className="block h-full rounded-full bg-teal" style={{ width: `${f.weight * 4}%` }} />
                  </span>
                </li>
              ))}
            </ul>
            <p className="mt-4 flex gap-2 text-xs leading-5 text-muted">
              <Gauge size={14} className="mt-0.5 shrink-0" aria-hidden />
              Rating, completion rate and trust score are currently entered by drivers with each offer, not taken from a verified history.
            </p>
          </section>

          <section className="card flex gap-3 p-6">
            <HeartHandshake size={18} className="mt-0.5 shrink-0 text-teal" aria-hidden />
            <div>
              <h3 className="font-bold">Mutual accountability</h3>
              <p className="mt-1 text-sm leading-6 text-muted">Scores will be earned from rated trips once ratings are introduced. Until then nothing is shown rather than an invented number.</p>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}
