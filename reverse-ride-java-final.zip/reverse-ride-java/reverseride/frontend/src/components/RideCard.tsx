import { Link } from 'wouter';
import { Bike, CarFront, Navigation } from 'lucide-react';
import type { Ride, VehicleType } from '@/lib/api';
import { formatDateTime, formatMoney, timeLeft, vehicleLabel } from '@/lib/format';
import { RouteLine, StatusBadge } from './ui';

export function VehicleIcon({ type, size = 18, className = '' }: { type: VehicleType; size?: number; className?: string }) {
  const Icon = type === 'bike' ? Bike : type === 'auto' ? Navigation : CarFront;
  return <Icon size={size} className={className} aria-label={vehicleLabel[type]} />;
}

export function RideCard({ ride, now }: { ride: Ride; now: number }) {
  const left = ride.status === 'auction' ? timeLeft(ride.auctionEndsAt, now) : null;
  return (
    <Link href={`/rides/${ride.id}`} className="card block p-5 transition-transform hover:-translate-y-0.5 hover:border-teal/40">
      <div className="mb-4 flex items-center justify-between">
        <StatusBadge status={ride.status} />
        <VehicleIcon type={ride.vehicleType} className="text-teal" />
      </div>
      <RouteLine pickup={ride.pickup} destination={ride.destination} />
      <div className="mt-5 flex items-center justify-between gap-3 border-t border-line pt-4 text-xs text-muted">
        <span>
          {ride.status === 'auction'
            ? `${ride.bidCount} ${ride.bidCount === 1 ? 'offer' : 'offers'} · ${left ?? 'bidding closed'}`
            : ride.maxFare != null
              ? `Max ${formatMoney(ride.maxFare)}`
              : vehicleLabel[ride.vehicleType]}
        </span>
        <span className="font-mono">{formatDateTime(ride.createdAt)}</span>
      </div>
    </Link>
  );
}
