import { useEffect, useState, type ReactNode } from 'react';
import { CircleAlert, Check, Info, type LucideIcon } from 'lucide-react';
import type { RideStatus } from '@/lib/api';
import { statusLabel } from '@/lib/format';

export function Skeleton({ className = '' }: { className?: string }) {
  return <div className={`skeleton ${className}`} role="status" aria-label="Loading" />;
}

export function PageTitle({ eyebrow, title, copy, action }: { eyebrow: string; title: string; copy?: string; action?: ReactNode }) {
  return (
    <div className="mb-8 flex flex-col justify-between gap-5 md:flex-row md:items-end">
      <div>
        <div className="eyebrow mb-3 text-teal">{eyebrow}</div>
        <h1 className="display text-3xl font-bold md:text-[2.6rem] md:leading-[1.08]">{title}</h1>
        {copy && <p className="mt-2 max-w-2xl text-sm leading-6 text-muted">{copy}</p>}
      </div>
      {action}
    </div>
  );
}

export function EmptyState({ icon: Icon, title, copy, action }: { icon: LucideIcon; title: string; copy: string; action?: ReactNode }) {
  return (
    <div className="flex min-h-[220px] flex-col items-center justify-center rounded-2xl border border-dashed border-line bg-paper/50 p-8 text-center">
      <div className="mb-4 grid h-12 w-12 place-items-center rounded-2xl bg-teal-soft text-teal">
        <Icon size={22} aria-hidden />
      </div>
      <h3 className="display text-lg font-bold">{title}</h3>
      <p className="mt-2 max-w-sm text-sm leading-6 text-muted">{copy}</p>
      {action && <div className="mt-5">{action}</div>}
    </div>
  );
}

export function ErrorState({ message, retry }: { message?: string; retry?: () => void }) {
  return (
    <div role="alert" className="flex flex-wrap items-center justify-between gap-4 rounded-2xl border border-danger/25 bg-danger-soft/70 p-4 text-sm">
      <div className="flex items-center gap-3">
        <CircleAlert size={18} className="shrink-0 text-danger" aria-hidden />
        <span>{message ?? 'We could not load this right now.'}</span>
      </div>
      {retry && (
        <button className="btn btn-line px-3 py-1.5 text-xs" onClick={retry}>
          Try again
        </button>
      )}
    </div>
  );
}

export function Notice({ tone, children }: { tone: 'success' | 'error' | 'info'; children: ReactNode }) {
  const styles = {
    success: 'border-teal/25 bg-teal-soft text-teal-deep',
    error: 'border-danger/25 bg-danger-soft text-danger',
    info: 'border-line bg-cream-deep/60 text-ink',
  }[tone];
  const Icon = tone === 'success' ? Check : tone === 'error' ? CircleAlert : Info;
  return (
    <div role={tone === 'error' ? 'alert' : 'status'} className={`flex items-start gap-2.5 rounded-xl border p-3 text-sm font-semibold ${styles}`}>
      <Icon size={16} className="mt-0.5 shrink-0" aria-hidden />
      <div>{children}</div>
    </div>
  );
}

export function FieldError({ message }: { message?: string }) {
  return message ? <p className="field-error">{message}</p> : null;
}

const statusTone: Record<RideStatus, string> = {
  draft: 'bg-cream-deep text-muted',
  auction: 'bg-orange-soft text-[#9a4a12]',
  booked: 'bg-teal-soft text-teal-deep',
  active: 'bg-teal text-white',
  completed: 'bg-navy/10 text-navy',
  cancelled: 'bg-danger-soft text-danger',
};

export function StatusBadge({ status }: { status: RideStatus }) {
  return <span className={`inline-flex items-center rounded-full px-2.5 py-1 font-mono text-[0.66rem] font-medium uppercase tracking-[0.1em] ${statusTone[status]}`}>{statusLabel[status]}</span>;
}

export function SummaryCard({ icon: Icon, label, value, foot, accent = false }: { icon: LucideIcon; label: string; value: string; foot: string; accent?: boolean }) {
  return (
    <div className={`rounded-2xl border p-5 shadow-[var(--shadow-soft)] ${accent ? 'border-teal/30 bg-teal-soft/70' : 'border-line bg-paper/85'}`}>
      <div className="mb-5 flex items-center justify-between">
        <span className="eyebrow text-muted">{label}</span>
        <span className={`grid h-8 w-8 place-items-center rounded-lg ${accent ? 'bg-teal text-white' : 'bg-cream-deep text-teal'}`}>
          <Icon size={16} aria-hidden />
        </span>
      </div>
      <div className="display text-3xl font-bold">{value}</div>
      <div className="mt-1 text-xs text-muted">{foot}</div>
    </div>
  );
}

export function RouteLine({ pickup, destination, dark = false }: { pickup: string; destination: string; dark?: boolean }) {
  return (
    <div className="flex items-start gap-3">
      <div className="flex flex-col items-center pt-1.5" aria-hidden>
        <span className="h-2 w-2 rounded-full bg-teal" />
        <span className={`my-1 h-6 border-l border-dashed ${dark ? 'border-cream/30' : 'border-line'}`} />
        <span className="h-2 w-2 rounded-full bg-orange" />
      </div>
      <div className="min-w-0 space-y-3 text-sm">
        <div className="truncate font-semibold"><span className="sr-only">From </span>{pickup}</div>
        <div className="truncate font-semibold"><span className="sr-only">To </span>{destination}</div>
      </div>
    </div>
  );
}

/** Current time that re-renders every second, for countdowns. */
export function useNow(intervalMs = 1000) {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const id = window.setInterval(() => setNow(Date.now()), intervalMs);
    return () => window.clearInterval(id);
  }, [intervalMs]);
  return now;
}
