import { useState, type FormEvent } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Link } from 'wouter';
import { ArrowRight } from 'lucide-react';
import { api, ApiError, VEHICLE_TYPES, type VehicleType } from '@/lib/api';
import { localInputToIso, vehicleLabel } from '@/lib/format';
import { FieldError, Notice } from './ui';

const AUCTION_OPTIONS = [
  { seconds: 60, label: '1 minute' },
  { seconds: 120, label: '2 minutes' },
  { seconds: 180, label: '3 minutes' },
  { seconds: 300, label: '5 minutes' },
  { seconds: 600, label: '10 minutes' },
];

const initial = { pickup: '', destination: '', vehicleType: 'car' as VehicleType, passengerCount: '1', targetArrival: '', maxFare: '', auctionDurationSeconds: '180' };

type Errors = Partial<Record<keyof typeof initial, string>>;

function validate(form: typeof initial): Errors {
  const errors: Errors = {};
  if (!form.pickup.trim()) errors.pickup = 'Add a pickup point';
  if (!form.destination.trim()) errors.destination = 'Add a destination';
  const count = Number(form.passengerCount);
  if (!Number.isInteger(count) || count < 1 || count > 8) errors.passengerCount = 'Between 1 and 8 passengers';
  if (form.targetArrival && new Date(form.targetArrival).getTime() <= Date.now()) errors.targetArrival = 'Pick a time in the future';
  if (form.maxFare) {
    const fare = Number(form.maxFare);
    if (!Number.isFinite(fare) || fare < 1 || fare > 100000) errors.maxFare = 'Between ₹1 and ₹1,00,000';
  }
  return errors;
}

export function RideRequestForm() {
  const queryClient = useQueryClient();
  const [form, setForm] = useState(initial);
  const [errors, setErrors] = useState<Errors>({});
  const [createdId, setCreatedId] = useState<string | null>(null);
  const create = useMutation({
    mutationFn: api.createRide,
    onSuccess: (ride) => {
      queryClient.invalidateQueries({ queryKey: ['rides'] });
      queryClient.invalidateQueries({ queryKey: ['dashboard'] });
      setCreatedId(ride.id);
      setForm(initial);
    },
    onError: (error) => error instanceof ApiError && setErrors(error.fieldErrors as Errors),
  });

  function set<K extends keyof typeof initial>(key: K, value: (typeof initial)[K]) {
    setForm((f) => ({ ...f, [key]: value }));
    setErrors((e) => ({ ...e, [key]: undefined }));
  }

  function submit(event: FormEvent) {
    event.preventDefault();
    setCreatedId(null);
    const found = validate(form);
    setErrors(found);
    if (Object.keys(found).length) return;
    create.mutate({
      pickup: form.pickup.trim(),
      destination: form.destination.trim(),
      vehicleType: form.vehicleType,
      passengerCount: Number(form.passengerCount),
      targetArrival: localInputToIso(form.targetArrival),
      maxFare: form.maxFare ? Number(form.maxFare) : null,
      auctionDurationSeconds: Number(form.auctionDurationSeconds),
    });
  }

  return (
    <form id="ride-request" onSubmit={submit} noValidate className="panel-navy p-5 md:p-7">
      <div className="eyebrow text-orange">Open an auction</div>
      <h2 className="display mt-2 text-2xl font-bold">Where are you headed?</h2>
      <p className="mt-1 text-sm text-cream/60">Set the brief. Drivers set their price.</p>

      <div className="mt-6 grid gap-4 md:grid-cols-2">
        <label className="block text-xs font-semibold text-cream/70 md:col-span-2">
          Pickup
          <input className="field-dark" placeholder="Street, place or landmark" value={form.pickup} onChange={(e) => set('pickup', e.target.value)} aria-invalid={!!errors.pickup} maxLength={300} />
          <FieldError message={errors.pickup} />
        </label>
        <label className="block text-xs font-semibold text-cream/70 md:col-span-2">
          Destination
          <input className="field-dark" placeholder="Where should the driver take you?" value={form.destination} onChange={(e) => set('destination', e.target.value)} aria-invalid={!!errors.destination} maxLength={300} />
          <FieldError message={errors.destination} />
        </label>
        <label className="block text-xs font-semibold text-cream/70">
          Vehicle
          <select className="field-dark" value={form.vehicleType} onChange={(e) => set('vehicleType', e.target.value as VehicleType)}>
            {VEHICLE_TYPES.map((v) => (
              <option key={v} value={v}>{vehicleLabel[v]}</option>
            ))}
          </select>
        </label>
        <label className="block text-xs font-semibold text-cream/70">
          Passengers
          <input type="number" min={1} max={8} className="field-dark" value={form.passengerCount} onChange={(e) => set('passengerCount', e.target.value)} aria-invalid={!!errors.passengerCount} />
          <FieldError message={errors.passengerCount} />
        </label>
        <label className="block text-xs font-semibold text-cream/70">
          Target arrival <span className="font-normal text-cream/40">(optional)</span>
          <input type="datetime-local" className="field-dark [color-scheme:dark]" value={form.targetArrival} onChange={(e) => set('targetArrival', e.target.value)} aria-invalid={!!errors.targetArrival} />
          <FieldError message={errors.targetArrival} />
        </label>
        <label className="block text-xs font-semibold text-cream/70">
          Maximum fare, ₹ <span className="font-normal text-cream/40">(optional)</span>
          <input type="number" min={1} step="0.01" className="field-dark" placeholder="No limit" value={form.maxFare} onChange={(e) => set('maxFare', e.target.value)} aria-invalid={!!errors.maxFare} />
          <FieldError message={errors.maxFare} />
        </label>
        <label className="block text-xs font-semibold text-cream/70 md:col-span-2">
          Bidding window
          <select className="field-dark" value={form.auctionDurationSeconds} onChange={(e) => set('auctionDurationSeconds', e.target.value)}>
            {AUCTION_OPTIONS.map((o) => (
              <option key={o.seconds} value={o.seconds}>{o.label}</option>
            ))}
          </select>
          <FieldError message={errors.auctionDurationSeconds} />
          <span className="mt-1.5 block text-[0.7rem] font-normal text-cream/45">Drivers can bid until the window closes. You can still choose among received offers afterwards.</span>
        </label>
      </div>

      {create.isError && !(create.error instanceof ApiError && Object.keys(create.error.fieldErrors).length) && (
        <div className="mt-4"><Notice tone="error">{create.error.message}</Notice></div>
      )}
      {createdId && (
        <div className="mt-4">
          <Notice tone="success">
            Your request is open for bids.{' '}
            <Link href={`/rides/${createdId}`} className="underline underline-offset-2">Watch offers arrive</Link>
          </Notice>
        </div>
      )}

      <button type="submit" disabled={create.isPending} className="btn btn-accent mt-6 w-full py-3.5">
        {create.isPending ? 'Opening auction…' : 'Request offers'}
        <ArrowRight size={16} aria-hidden />
      </button>
    </form>
  );
}
