import { useState, type ReactNode } from 'react';
import { Link, useLocation } from 'wouter';
import { ArrowLeft, CarFront, Clock3, Home, LogOut, Menu, Radio, Repeat2, Route as RouteIcon, ShieldCheck, UserRound, X, type LucideIcon } from 'lucide-react';
import type { Me } from '@/lib/api';
import { homeFor, useSignOut, useSwitchRole } from '@/lib/auth';

interface NavItem {
  href: string;
  label: string;
  icon: LucideIcon;
}

const passengerNav: NavItem[] = [
  { href: '/', label: 'Overview', icon: Home },
  { href: '/rides', label: 'My rides', icon: RouteIcon },
  { href: '/commutes', label: 'Commutes', icon: Clock3 },
  { href: '/safety', label: 'Safety center', icon: ShieldCheck },
  { href: '/profile', label: 'Profile & trust', icon: UserRound },
];

const driverNav: NavItem[] = [
  { href: '/driver', label: 'Driver workspace', icon: Radio },
  { href: '/safety', label: 'Safety center', icon: ShieldCheck },
  { href: '/profile', label: 'Profile & trust', icon: UserRound },
];

function Avatar({ me, size = 32 }: { me: Me; size?: number }) {
  return me.pictureUrl ? (
    <img src={me.pictureUrl} alt="" width={size} height={size} referrerPolicy="no-referrer" className="rounded-lg object-cover" style={{ width: size, height: size }} />
  ) : (
    <span className="grid place-items-center rounded-lg bg-orange font-bold text-navy" style={{ width: size, height: size }}>
      {me.name.slice(0, 1).toUpperCase()}
    </span>
  );
}

export function Shell({ me, children }: { me: Me; children: ReactNode }) {
  const [location, navigate] = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const switchRole = useSwitchRole();
  const signOut = useSignOut();
  const isDriver = me.activeRole === 'driver';
  const nav = isDriver ? driverNav : passengerNav;
  const otherRole = isDriver ? 'passenger' : 'driver';

  function changeMode() {
    switchRole.mutate(otherRole, { onSuccess: (next) => navigate(homeFor(next.activeRole)) });
  }

  return (
    <div className="min-h-dvh">
      <aside
        className={`fixed inset-y-0 left-0 z-30 flex w-[252px] flex-col bg-navy px-4 py-5 text-cream transition-transform md:translate-x-0 ${mobileOpen ? 'translate-x-0' : '-translate-x-full'}`}
        aria-label="Main navigation"
      >
        <div className="mb-8 flex items-center justify-between px-2">
          <Link href={homeFor(me.activeRole)} className="flex items-center gap-3" onClick={() => setMobileOpen(false)}>
            <span className="grid h-9 w-9 place-items-center rounded-xl bg-orange text-navy">
              <ArrowLeft size={17} strokeWidth={3} aria-hidden />
            </span>
            <span className="display text-lg font-bold">ReverseRide</span>
          </Link>
          <button className="rounded-lg p-2 md:hidden" onClick={() => setMobileOpen(false)} aria-label="Close navigation">
            <X size={18} />
          </button>
        </div>

        <div className="mx-2 mb-5 flex items-center gap-2 rounded-xl border border-cream/10 bg-cream/5 p-2.5">
          {isDriver ? <CarFront size={16} className="text-orange" aria-hidden /> : <UserRound size={16} className="text-orange" aria-hidden />}
          <span className="eyebrow text-cream/80">{isDriver ? 'Driver mode' : 'Passenger mode'}</span>
        </div>

        <nav className="space-y-1">
          {nav.map(({ href, label, icon: Icon }) => {
            const active = href === '/' ? location === '/' : location.startsWith(href);
            return (
              <Link
                key={href}
                href={href}
                onClick={() => setMobileOpen(false)}
                aria-current={active ? 'page' : undefined}
                className={`flex items-center gap-3 rounded-xl px-3 py-3 text-sm font-semibold transition-colors ${active ? 'bg-teal text-white' : 'text-cream/65 hover:bg-cream/10 hover:text-cream'}`}
              >
                <Icon size={17} aria-hidden />
                {label}
              </Link>
            );
          })}
        </nav>

        <div className="mt-auto space-y-2">
          <button className="btn btn-ghost-light w-full justify-start" onClick={changeMode} disabled={switchRole.isPending}>
            <Repeat2 size={16} aria-hidden />
            {switchRole.isPending ? 'Switching…' : `Switch to ${otherRole} mode`}
          </button>
          {switchRole.isError && <p className="px-1 text-xs text-orange">{switchRole.error.message}</p>}
          <div className="rounded-2xl border border-cream/10 bg-cream/5 p-4 text-xs leading-5 text-cream/60">
            Every offer shows price, ETA, vehicle and trust together. The passenger always makes the final choice.
          </div>
        </div>
      </aside>

      {mobileOpen && <button className="fixed inset-0 z-20 bg-navy/45 md:hidden" onClick={() => setMobileOpen(false)} aria-label="Close navigation" />}

      <div className="md:pl-[252px]">
        <header className="sticky top-0 z-10 flex h-[68px] items-center gap-3 border-b border-line/80 bg-cream/85 px-4 backdrop-blur-xl md:px-10">
          <button className="rounded-xl border border-line bg-paper p-2.5 md:hidden" onClick={() => setMobileOpen(true)} aria-label="Open navigation">
            <Menu size={18} />
          </button>
          <div className="ml-auto flex items-center gap-2 sm:gap-3">
            <div className="flex items-center gap-2.5 rounded-xl border border-line bg-paper/80 py-1.5 pl-1.5 pr-3">
              <Avatar me={me} />
              <div className="hidden leading-tight sm:block">
                <div className="max-w-[180px] truncate text-sm font-bold">{me.name}</div>
                <div className="max-w-[180px] truncate text-xs text-muted">{me.email}</div>
              </div>
            </div>
            <button className="btn btn-line px-3" onClick={() => signOut.mutate(undefined, { onSettled: () => navigate('/') })} disabled={signOut.isPending}>
              <LogOut size={16} aria-hidden />
              <span className="hidden sm:inline">Sign out</span>
            </button>
          </div>
        </header>
        <main className="mx-auto max-w-[1360px] px-4 py-7 md:px-10 md:py-10">{children}</main>
      </div>
    </div>
  );
}
