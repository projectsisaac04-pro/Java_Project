/// <reference types="vite/client" />

interface ImportMetaEnv {
  /** Origin of the Java API, e.g. https://api.example.com. Leave empty to call /api on the same origin. */
  readonly VITE_API_BASE_URL?: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
