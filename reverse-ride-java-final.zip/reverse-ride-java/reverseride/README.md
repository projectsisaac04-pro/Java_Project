# ReverseRide

A fair mobility marketplace. A passenger describes the trip they need; drivers send transparent offers; the passenger compares price, ETA, vehicle and reputation side by side and chooses one.

- **backend/**: Java 21 + Spring Boot 4 REST API, holding all business rules (Spring Data JPA, Flyway, Bean Validation, Spring Security)
- **frontend/**: React 19 + TypeScript + Vite 7, Tailwind CSS 4, Wouter, TanStack React Query
- **Database**: PostgreSQL. The schema is created by Flyway migrations, with **no seed data**.
- **Sign-in**: Google. The first screen asks whether you're joining as a **passenger** or a **driver**, then shows the Google button.

## Quick start on Windows (one command)

Open the `reverseride` folder in VS Code, open the terminal (**Ctrl+`**) and run:

```powershell
copy .env.example .env      # first time only, then fill in .env (DB password, GOOGLE_CLIENT_ID, SESSION_SECRET)
.\run.cmd -Check            # checks Java 21, Node, pnpm, ports and settings, and starts nothing
.\run.cmd                   # starts the Java API + website and opens http://localhost:5173
```

Press **Ctrl+C** to stop both. In VS Code you can also press **Ctrl+Shift+B** ("ReverseRide: start").
The launcher picks JDK 21 even if `JAVA_HOME` points elsewhere, uses the first free API port from 8080 to 8090, asks for the PostgreSQL password if `.env` has none, creates the `reverseride` database if needed, and installs website packages on the first run.

## What works

| Area | Status |
|---|---|
| Google sign-in with passenger / driver choice | ✅ Google ID token verified on the server (signature, issuer, audience, expiry, verified email); session kept in an HttpOnly, SameSite=Lax signed cookie. You can switch modes later from the sidebar. |
| Ride requests | ✅ Pickup, destination, vehicle (bike/auto/car/premium), passengers (1–8), optional target arrival, optional max fare, and a bidding window (30–600 s, default 180 s). Validated on client and server. |
| Ride lifecycle | ✅ `draft → auction → booked → active → completed`, and `cancelled` from draft, auction or booked. Illegal transitions return 409. |
| Driver bids | ✅ Only while the auction is open; never above the passenger's max fare; one bid per driver per ride; you can't bid on your own request. |
| Bid acceptance | ✅ Transactional with a row lock: the bid must belong to the ride, the ride must still be in `auction`, and only one bid can ever be accepted. |
| Value score | ✅ Java `ValueScoreService`, shown as a per-factor breakdown (see below). It informs; it never picks a driver. |
| Suggested bid | ✅ Operating cost × 1.35, rounded to a whole rupee, labelled as a suggestion. |
| Driver trips | ✅ The chosen driver can start a trip (`booked → active`) and complete it (`active → completed`). |
| Recurring commutes | ✅ Create, list, pause/resume. A commute never books anything on its own. |
| History & dashboard | ✅ Status filters; counts of active, completed and saved commutes. |
| Refresh | Ride detail polls every 10 s during an auction; the driver workspace polls every 15 s. There are no push or real-time streams. |

### Not implemented (labelled as unavailable in the UI)

- **Fare breakdown**: no routing, traffic or pricing provider is integrated. The API returns `available: false` with null figures rather than invented numbers.
- **Safety monitoring / emergency / safety-event recording**: not connected. The safety log says so explicitly.
- **Passenger and driver scores**: there is no rating history yet, so they show "—".
- **Driver rating, completion rate and trust score on bids** are **self-reported** by the driver and labelled that way.
- No payments, maps or geocoding, live tracking, notifications or chat, and no driver identity, licence or vehicle verification. Any Google account can use driver mode.
- No AI features.

### Value score

Each factor is normalised to 0–100 (higher is better) before weighting, so rupees and minutes are never mixed with percentages:

| Factor | Weight | Normalisation |
|---|---|---|
| Price | 25% | `100 × lowest offer on this ride / this offer` |
| ETA | 20% | `100 × (fastest ETA + 1) / (this ETA + 1)` |
| Rating | 20% | `rating / 5 × 100` |
| Completion rate | 15% | already 0–100 |
| Trust score | 20% | already 0–100 |

Total = Σ score × weight, rounded to one decimal place.

## Prerequisites

- **Java 21** (JDK). The Maven wrapper (`mvnw`) downloads Maven for you.
- **Node.js 20+** and **pnpm 9+** (`npm install -g pnpm`)
- **PostgreSQL 14+**, local or hosted (e.g. Neon)
- A **Google OAuth client ID** (free)

## 1. Create a Google OAuth client ID

1. Open <https://console.cloud.google.com/apis/credentials> and select or create a project.
2. If prompted, configure the OAuth consent screen (External; add yourself as a test user).
3. **Create credentials → OAuth client ID → Application type: Web application**.
4. Under **Authorized JavaScript origins**, add `http://localhost:5173`, plus your production web origin later.
5. Copy the client ID (`…apps.googleusercontent.com`). It's public, not a secret. No client secret is needed.

## 2. Create the database

```bash
psql -U postgres -c "CREATE DATABASE reverseride;"
```

Flyway creates all tables when the API starts.

## 3. Start the API

### Windows PowerShell

```powershell
cd reverseride\backend
$env:JAVA_HOME = "C:\Program Files\Java\jdk-21.0.12"   # if JAVA_HOME points to an older JDK
$env:DATABASE_URL = "jdbc:postgresql://localhost:5432/reverseride"
$env:DATABASE_USERNAME = "postgres"
$env:DATABASE_PASSWORD = "<your postgres password>"
$env:GOOGLE_CLIENT_ID = "<your-client-id>.apps.googleusercontent.com"
$env:SESSION_SECRET = "<at least 32 random characters>"
.\mvnw.cmd spring-boot:run
```

### macOS / Linux

```bash
cd reverseride/backend
export DATABASE_URL="jdbc:postgresql://localhost:5432/reverseride"
export DATABASE_USERNAME="postgres"
export DATABASE_PASSWORD="<your postgres password>"
export GOOGLE_CLIENT_ID="<your-client-id>.apps.googleusercontent.com"
export SESSION_SECRET="$(openssl rand -base64 48)"
./mvnw spring-boot:run
```

The API listens on `http://localhost:8080` (`GET /api/health`). If port 8080 is taken (on the machine this was built on, a program called "Connect" uses it), set `PORT=8081` for the API and `API_PROXY_TARGET=http://localhost:8081` for the frontend.

Hosted PostgreSQL (e.g. Neon): convert `postgres://user:pass@host/db?sslmode=require` to `DATABASE_URL=jdbc:postgresql://host/db?sslmode=require`, and put the user and password in `DATABASE_USERNAME` / `DATABASE_PASSWORD`.

If `SESSION_SECRET` is unset, the API generates a random one and logs a warning. Sessions then reset on every restart.

## 4. Start the web app

In a second terminal:

```bash
cd reverseride/frontend
pnpm install
pnpm dev
```

Open <http://localhost:5173>. Vite forwards `/api` to the Java API, so cookies are first-party. To use another API address in development, set `API_PROXY_TARGET` (PowerShell: `$env:API_PROXY_TARGET="http://localhost:8081"`).

To try the full flow alone, sign in as a passenger in one browser profile and as a driver in another (or use a different Google account). You can't bid on your own request.

## Tests and builds

```bash
# Backend: domain rules, scoring, validation and an end-to-end API flow (in-memory H2, Google verifier stubbed)
cd reverseride/backend
./mvnw test            # Windows: .\mvnw.cmd test

# Frontend: type-check and production build
cd reverseride/frontend
pnpm typecheck
pnpm build
```

## Production notes

- Serve the frontend `dist/` and the API behind one origin with `/api` routed to the Java service, or set `VITE_API_BASE_URL` at build time and add the web origin to `CORS_ALLOWED_ORIGINS`.
- Over HTTPS, set `SESSION_COOKIE_SECURE=true`.
- Add your production web origin to the Google client's Authorized JavaScript origins.

## API overview

| Method & path | Who | Purpose |
|---|---|---|
| `GET /api/auth/config` | public | Whether Google sign-in is configured, and the client ID |
| `POST /api/auth/google` `{credential, role}` | public | Verify the Google ID token, create/update the account, set the session cookie |
| `GET /api/auth/me` · `POST /api/auth/role` · `POST /api/auth/logout` | signed in | Current user · switch passenger/driver mode · sign out |
| `GET/POST /api/rides`, `GET /api/rides/{id}` | passenger | List (`?status=`), create, view own rides |
| `GET /api/rides/{id}/bids` | passenger | Offers with value-score breakdown |
| `POST /api/rides/{id}/bids/{bidId}/accept` · `POST /api/rides/{id}/cancel` | passenger | Book · cancel |
| `GET /api/rides/{id}/fare-explanation` | passenger | Returns `available: false` until a pricing provider exists |
| `GET /api/dashboard/summary` | passenger | Counts for the dashboard |
| `GET/POST /api/commutes`, `PATCH /api/commutes/{id}` | passenger | Saved commutes, pause/resume |
| `GET /api/driver/open-rides` · `POST /api/driver/rides/{id}/bids` | driver | Open auctions · place a bid |
| `GET /api/driver/trips` · `POST /api/driver/trips/{id}/start` · `…/complete` | driver | Trips won · lifecycle |
| `GET /api/driver/suggested-bid?operatingCost=` | driver | Cost × 1.35 suggestion |
| `GET /api/safety/rides/{id}` | ride's passenger or chosen driver | Returns `available: false` until safety integrations exist |

Errors always look like `{"error": "...", "fieldErrors": {"field": "message"}}`.
