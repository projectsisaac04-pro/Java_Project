package com.reverseride.scoring;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.math.BigDecimal;
import java.util.List;

import org.junit.jupiter.api.Test;

import com.reverseride.scoring.ValueScoreService.Factor;
import com.reverseride.scoring.ValueScoreService.Offer;
import com.reverseride.scoring.ValueScoreService.ValueScore;

class ValueScoreServiceTest {

    private final ValueScoreService service = new ValueScoreService();

    private static Offer offer(String amount, int eta, String rating, String completion, String trust) {
        return new Offer(new BigDecimal(amount), eta, new BigDecimal(rating), new BigDecimal(completion), new BigDecimal(trust));
    }

    private static BigDecimal component(ValueScore score, Factor factor) {
        return score.components().stream().filter(c -> c.factor() == factor).findFirst().orElseThrow().score();
    }

    @Test
    void weightsAddUpToOneHundredPercent() {
        BigDecimal sum = BigDecimal.ZERO;
        for (Factor factor : Factor.values()) {
            sum = sum.add(factor.weight());
        }
        assertThat(sum).isEqualByComparingTo("1.00");
    }

    @Test
    void perfectSingleOfferScoresOneHundred() {
        ValueScore score = service.scoreAll(List.of(offer("200", 5, "5.0", "100", "100"))).getFirst();
        assertThat(score.total()).isEqualByComparingTo("100.0");
    }

    @Test
    void normalisesEachFactorToZeroToHundred() {
        List<ValueScore> scores = service.scoreAll(List.of(
                offer("200", 4, "4.0", "90", "80"),
                offer("400", 9, "5.0", "100", "100")));

        ValueScore cheap = scores.get(0);
        assertThat(component(cheap, Factor.PRICE)).isEqualByComparingTo("100.0");
        assertThat(component(cheap, Factor.ETA)).isEqualByComparingTo("100.0");
        assertThat(component(cheap, Factor.RATING)).isEqualByComparingTo("80.0");
        assertThat(component(cheap, Factor.COMPLETION)).isEqualByComparingTo("90.0");
        assertThat(component(cheap, Factor.TRUST)).isEqualByComparingTo("80.0");
        // 0.25*100 + 0.20*100 + 0.20*80 + 0.15*90 + 0.20*80
        assertThat(cheap.total()).isEqualByComparingTo("90.5");

        ValueScore pricey = scores.get(1);
        assertThat(component(pricey, Factor.PRICE)).isEqualByComparingTo("50.0");   // 200 / 400
        assertThat(component(pricey, Factor.ETA)).isEqualByComparingTo("50.0");     // (4+1) / (9+1)
        // 0.25*50 + 0.20*50 + 0.20*100 + 0.15*100 + 0.20*100
        assertThat(pricey.total()).isEqualByComparingTo("77.5");
    }

    @Test
    void trustCanOutweighASmallPriceDifference() {
        List<ValueScore> scores = service.scoreAll(List.of(
                offer("190", 6, "3.5", "70", "40"),
                offer("200", 6, "4.8", "98", "95")));
        assertThat(scores.get(1).total()).isGreaterThan(scores.get(0).total());
    }

    @Test
    void zeroMinuteEtaIsHandled() {
        List<ValueScore> scores = service.scoreAll(List.of(offer("100", 0, "4", "90", "90"), offer("100", 3, "4", "90", "90")));
        assertThat(component(scores.get(0), Factor.ETA)).isEqualByComparingTo("100.0");
        assertThat(component(scores.get(1), Factor.ETA)).isEqualByComparingTo("25.0");
    }

    @Test
    void contributionsSumToTotal() {
        ValueScore score = service.scoreAll(List.of(offer("150", 3, "4.2", "88", "73"), offer("180", 2, "4.9", "97", "91"))).getFirst();
        BigDecimal sum = score.components().stream().map(ValueScoreService.Component::contribution).reduce(BigDecimal.ZERO, BigDecimal::add);
        assertThat(sum.subtract(score.total()).abs()).isLessThanOrEqualTo(new BigDecimal("0.3"));
    }

    @Test
    void emptyInputGivesEmptyOutput() {
        assertThat(service.scoreAll(List.of())).isEmpty();
    }

    @Test
    void rejectsNonPositiveAmounts() {
        assertThatThrownBy(() -> service.scoreAll(List.of(offer("0", 3, "4", "90", "90"))))
                .isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    void suggestedBidIsOperatingCostTimesOnePointThreeFiveRoundedToRupee() {
        assertThat(service.suggestedBid(new BigDecimal("200"))).isEqualByComparingTo("270");
        assertThat(service.suggestedBid(new BigDecimal("123"))).isEqualByComparingTo("166");   // 166.05
        assertThat(service.suggestedBid(new BigDecimal("101"))).isEqualByComparingTo("136");   // 136.35
        assertThat(service.suggestedBid(new BigDecimal("10")).scale()).isZero();
        assertThatThrownBy(() -> service.suggestedBid(BigDecimal.ZERO)).isInstanceOf(IllegalArgumentException.class);
    }
}
