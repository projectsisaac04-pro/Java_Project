package com.reverseride;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.Clock;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.util.concurrent.atomic.AtomicReference;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Primary;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import com.jayway.jsonpath.JsonPath;
import com.reverseride.auth.GoogleIdTokenVerifier;
import com.reverseride.auth.GoogleIdentity;
import com.reverseride.auth.SessionTokenService;
import com.reverseride.web.ApiException;

import jakarta.servlet.http.Cookie;

/**
 * End-to-end API flow on an in-memory database. Google verification is replaced by a stub that
 * accepts tokens of the form {@code test:<subject>}; everything else (sessions, roles, rules,
 * persistence) is the real application.
 */
@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
@Import(MarketplaceFlowIntegrationTest.TestBeans.class)
class MarketplaceFlowIntegrationTest {

    static final Instant START = Instant.parse("2026-10-01T09:00:00Z");

    @TestConfiguration
    static class TestBeans {
        @Bean
        @Primary
        MutableClock testClock() {
            return new MutableClock(START);
        }

        @Bean
        @Primary
        GoogleIdTokenVerifier stubGoogleVerifier() {
            return token -> {
                if (!token.startsWith("test:")) {
                    throw new ApiException(HttpStatus.UNAUTHORIZED, "Google could not confirm this sign-in.");
                }
                String subject = token.substring(5);
                return new GoogleIdentity(subject, subject + "@example.test", "User " + subject, null);
            };
        }
    }

    static class MutableClock extends Clock {
        private final AtomicReference<Instant> now;

        MutableClock(Instant start) {
            this.now = new AtomicReference<>(start);
        }

        void advanceSeconds(long seconds) {
            now.updateAndGet(i -> i.plusSeconds(seconds));
        }

        @Override
        public ZoneId getZone() {
            return ZoneOffset.UTC;
        }

        @Override
        public Clock withZone(ZoneId zone) {
            return this;
        }

        @Override
        public Instant instant() {
            return now.get();
        }
    }

    @Autowired
    MockMvc mvc;

    @Autowired
    MutableClock clock;

    private Cookie signIn(String subject, String role) throws Exception {
        MvcResult result = mvc.perform(post("/api/auth/google").contentType(MediaType.APPLICATION_JSON)
                        .content("{\"credential\":\"test:" + subject + "\",\"role\":\"" + role + "\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.activeRole").value(role))
                .andReturn();
        Cookie cookie = result.getResponse().getCookie(SessionTokenService.COOKIE_NAME);
        assertThat(cookie).isNotNull();
        assertThat(cookie.isHttpOnly()).isTrue();
        return cookie;
    }

    private String createRide(Cookie passenger, String extraJson) throws Exception {
        MvcResult result = mvc.perform(post("/api/rides").cookie(passenger).contentType(MediaType.APPLICATION_JSON)
                        .content("{\"pickup\":\"Koramangala\",\"destination\":\"Airport\",\"vehicleType\":\"car\",\"passengerCount\":2"
                                + extraJson + "}"))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.status").value("auction"))
                .andReturn();
        return JsonPath.read(result.getResponse().getContentAsString(), "$.id");
    }

    private static String bidJson(String amount, int eta, String rating) {
        return "{\"vehicleLabel\":\"White sedan\",\"amount\":" + amount + ",\"etaMinutes\":" + eta + ",\"rating\":" + rating
                + ",\"completionRate\":96,\"trustScore\":88}";
    }

    @Test
    void rejectsUnauthenticatedAndInvalidSignIns() throws Exception {
        mvc.perform(get("/api/rides")).andExpect(status().isUnauthorized());
        mvc.perform(get("/api/auth/me")).andExpect(status().isUnauthorized());
        mvc.perform(post("/api/auth/google").contentType(MediaType.APPLICATION_JSON).content("{\"credential\":\"forged\",\"role\":\"passenger\"}"))
                .andExpect(status().isUnauthorized());
        mvc.perform(post("/api/auth/google").contentType(MediaType.APPLICATION_JSON).content("{\"credential\":\"test:x\",\"role\":\"admin\"}"))
                .andExpect(status().isBadRequest());
        mvc.perform(get("/api/rides").cookie(new Cookie(SessionTokenService.COOKIE_NAME, "tampered.token.value")))
                .andExpect(status().isUnauthorized());
        mvc.perform(get("/api/auth/config")).andExpect(status().isOk()).andExpect(jsonPath("$.googleConfigured").value(true));
    }

    @Test
    void rolesGateTheirOwnEndpointsAndCanBeSwitched() throws Exception {
        Cookie passenger = signIn("role-switcher", "passenger");
        mvc.perform(get("/api/driver/open-rides").cookie(passenger)).andExpect(status().isForbidden());

        MvcResult switched = mvc.perform(post("/api/auth/role").cookie(passenger).contentType(MediaType.APPLICATION_JSON)
                        .content("{\"role\":\"driver\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.activeRole").value("driver"))
                .andExpect(jsonPath("$.roles.length()").value(2))
                .andReturn();
        Cookie driver = switched.getResponse().getCookie(SessionTokenService.COOKIE_NAME);
        mvc.perform(get("/api/driver/open-rides").cookie(driver)).andExpect(status().isOk());
        mvc.perform(get("/api/rides").cookie(driver)).andExpect(status().isForbidden());
    }

    @Test
    void fullAuctionBookingAndTripLifecycle() throws Exception {
        Cookie passenger = signIn("asha", "passenger");
        Cookie driverA = signIn("ravi", "driver");
        Cookie driverB = signIn("meera", "driver");

        String rideId = createRide(passenger, ",\"maxFare\":400,\"auctionDurationSeconds\":120");

        mvc.perform(get("/api/driver/open-rides").cookie(driverA))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[?(@.id == '" + rideId + "')].maxFare").value(400.0));

        // Validation and business rules on bids
        mvc.perform(post("/api/driver/rides/" + rideId + "/bids").cookie(driverA).contentType(MediaType.APPLICATION_JSON)
                        .content(bidJson("-5", 4, "4.5")))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.fieldErrors.amount").exists());
        mvc.perform(post("/api/driver/rides/" + rideId + "/bids").cookie(driverA).contentType(MediaType.APPLICATION_JSON)
                        .content(bidJson("300", 4, "7")))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.fieldErrors.rating").exists());
        mvc.perform(post("/api/driver/rides/" + rideId + "/bids").cookie(driverA).contentType(MediaType.APPLICATION_JSON)
                        .content(bidJson("450", 4, "4.5")))
                .andExpect(status().isConflict());

        mvc.perform(post("/api/driver/rides/" + rideId + "/bids").cookie(driverA).contentType(MediaType.APPLICATION_JSON)
                        .content(bidJson("300", 4, "4.6")))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.myBidAmount").value(300.0));
        mvc.perform(post("/api/driver/rides/" + rideId + "/bids").cookie(driverA).contentType(MediaType.APPLICATION_JSON)
                        .content(bidJson("290", 4, "4.6")))
                .andExpect(status().isConflict());
        mvc.perform(post("/api/driver/rides/" + rideId + "/bids").cookie(driverB).contentType(MediaType.APPLICATION_JSON)
                        .content(bidJson("350", 9, "4.9")))
                .andExpect(status().isCreated());

        // Passenger compares bids with score breakdowns (cheapest first)
        MvcResult bids = mvc.perform(get("/api/rides/" + rideId + "/bids").cookie(passenger))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(2))
                .andExpect(jsonPath("$[0].amount").value(300.0))
                .andExpect(jsonPath("$[0].driverName").value("User ravi"))
                .andExpect(jsonPath("$[0].valueScore.components.length()").value(5))
                .andExpect(jsonPath("$[0].valueScore.components[0].score").value(100.0))
                .andReturn();
        String bidA = JsonPath.read(bids.getResponse().getContentAsString(), "$[0].id");
        String bidB = JsonPath.read(bids.getResponse().getContentAsString(), "$[1].id");

        // Another passenger cannot see or act on this ride
        Cookie stranger = signIn("stranger", "passenger");
        mvc.perform(get("/api/rides/" + rideId).cookie(stranger)).andExpect(status().isNotFound());
        mvc.perform(post("/api/rides/" + rideId + "/bids/" + bidA + "/accept").cookie(stranger)).andExpect(status().isNotFound());

        // Acceptance books the ride exactly once
        mvc.perform(post("/api/rides/" + rideId + "/bids/" + bidA + "/accept").cookie(passenger))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("booked"))
                .andExpect(jsonPath("$.selectedBidId").value(bidA));
        mvc.perform(post("/api/rides/" + rideId + "/bids/" + bidB + "/accept").cookie(passenger))
                .andExpect(status().isConflict());
        mvc.perform(post("/api/driver/rides/" + rideId + "/bids").cookie(signIn("late", "driver")).contentType(MediaType.APPLICATION_JSON)
                        .content(bidJson("200", 2, "5")))
                .andExpect(status().isConflict());

        // Only the chosen driver runs the trip
        mvc.perform(post("/api/driver/trips/" + rideId + "/start").cookie(driverB)).andExpect(status().isNotFound());
        mvc.perform(post("/api/driver/trips/" + rideId + "/complete").cookie(driverA)).andExpect(status().isConflict());
        mvc.perform(post("/api/driver/trips/" + rideId + "/start").cookie(driverA))
                .andExpect(status().isOk()).andExpect(jsonPath("$.status").value("active"));
        mvc.perform(get("/api/safety/rides/" + rideId).cookie(driverA))
                .andExpect(status().isOk()).andExpect(jsonPath("$.available").value(false));
        mvc.perform(post("/api/driver/trips/" + rideId + "/complete").cookie(driverA))
                .andExpect(status().isOk()).andExpect(jsonPath("$.status").value("completed"));

        mvc.perform(post("/api/rides/" + rideId + "/cancel").cookie(passenger)).andExpect(status().isConflict());
        mvc.perform(get("/api/rides").param("status", "completed").cookie(passenger))
                .andExpect(status().isOk()).andExpect(jsonPath("$[0].id").value(rideId));
        mvc.perform(get("/api/dashboard/summary").cookie(passenger))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.completedRides").value(1))
                .andExpect(jsonPath("$.passengerScore").doesNotExist());
    }

    @Test
    void biddingClosesWhenTheAuctionEnds() throws Exception {
        Cookie passenger = signIn("timer-passenger", "passenger");
        Cookie driver = signIn("timer-driver", "driver");
        String rideId = createRide(passenger, ",\"auctionDurationSeconds\":30");

        clock.advanceSeconds(31);
        mvc.perform(post("/api/driver/rides/" + rideId + "/bids").cookie(driver).contentType(MediaType.APPLICATION_JSON)
                        .content(bidJson("200", 3, "4.5")))
                .andExpect(status().isConflict());
        mvc.perform(get("/api/rides/" + rideId).cookie(passenger))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.acceptingBids").value(false));
    }

    @Test
    void rideRequestValidation() throws Exception {
        Cookie passenger = signIn("validator", "passenger");
        mvc.perform(post("/api/rides").cookie(passenger).contentType(MediaType.APPLICATION_JSON)
                        .content("{\"pickup\":\"A\",\"destination\":\"B\",\"vehicleType\":\"car\",\"auctionDurationSeconds\":5}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.fieldErrors.auctionDurationSeconds").exists());
        mvc.perform(post("/api/rides").cookie(passenger).contentType(MediaType.APPLICATION_JSON)
                        .content("{\"pickup\":\" \",\"destination\":\"B\",\"vehicleType\":\"car\",\"passengerCount\":12}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.fieldErrors.pickup").exists())
                .andExpect(jsonPath("$.fieldErrors.passengerCount").exists());
        mvc.perform(post("/api/rides").cookie(passenger).contentType(MediaType.APPLICATION_JSON)
                        .content("{\"pickup\":\"A\",\"destination\":\"B\",\"vehicleType\":\"spaceship\"}"))
                .andExpect(status().isBadRequest());
        mvc.perform(get("/api/rides").param("status", "flying").cookie(passenger)).andExpect(status().isBadRequest());
    }

    @Test
    void commutesAreSavedPerPassengerAndCanBePaused() throws Exception {
        Cookie passenger = signIn("commuter", "passenger");
        MvcResult created = mvc.perform(post("/api/commutes").cookie(passenger).contentType(MediaType.APPLICATION_JSON)
                        .content("{\"label\":\"Office\",\"pickup\":\"HSR\",\"destination\":\"Whitefield\",\"vehicleType\":\"auto\","
                                + "\"daysOfWeek\":[\"FRI\",\"MON\"],\"departureTime\":\"08:30\",\"targetArrival\":\"09:15\",\"maxFare\":250}"))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.daysOfWeek[0]").value("MON"))
                .andExpect(jsonPath("$.active").value(true))
                .andReturn();
        String id = JsonPath.read(created.getResponse().getContentAsString(), "$.id");

        mvc.perform(org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch("/api/commutes/" + id).cookie(passenger)
                        .contentType(MediaType.APPLICATION_JSON).content("{\"active\":false}"))
                .andExpect(status().isOk()).andExpect(jsonPath("$.active").value(false));
        mvc.perform(get("/api/commutes").cookie(signIn("other-commuter", "passenger")))
                .andExpect(status().isOk()).andExpect(jsonPath("$.length()").value(0));
        mvc.perform(post("/api/commutes").cookie(passenger).contentType(MediaType.APPLICATION_JSON)
                        .content("{\"label\":\"Bad\",\"pickup\":\"A\",\"destination\":\"B\",\"vehicleType\":\"car\","
                                + "\"daysOfWeek\":[],\"departureTime\":\"25:00\",\"targetArrival\":\"09:00\",\"maxFare\":0}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.fieldErrors.daysOfWeek").exists())
                .andExpect(jsonPath("$.fieldErrors.departureTime").exists())
                .andExpect(jsonPath("$.fieldErrors.maxFare").exists());
    }

    @Test
    void suggestedBidAndUnavailableIntegrationsAreHonest() throws Exception {
        Cookie driver = signIn("suggest", "driver");
        mvc.perform(get("/api/driver/suggested-bid").param("operatingCost", "200").cookie(driver))
                .andExpect(status().isOk()).andExpect(jsonPath("$.suggestedBid").value(270));

        Cookie passenger = signIn("fare", "passenger");
        String rideId = createRide(passenger, "");
        mvc.perform(get("/api/rides/" + rideId + "/fare-explanation").cookie(passenger))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.available").value(false))
                .andExpect(jsonPath("$.estimatedTotal").doesNotExist());
    }
}
