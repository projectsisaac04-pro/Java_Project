package com.reverseride.domain;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.Instant;
import java.util.UUID;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

class RideLifecycleTest {

    private static final Instant NOW = Instant.parse("2026-10-01T10:00:00Z");
    private final UUID passenger = UUID.randomUUID();
    private final UUID driver = UUID.randomUUID();

    private Ride newRide(String maxFare) {
        return Ride.openAuction(passenger, "Indiranagar", "MG Road", VehicleType.CAR, 1, null,
                maxFare == null ? null : new BigDecimal(maxFare), Duration.ofSeconds(120), NOW);
    }

    private Bid bidFor(Ride ride, UUID driverId, String amount) {
        return new Bid(ride.getId(), driverId, "Driver", "White sedan", new BigDecimal(amount), 5,
                new BigDecimal("4.5"), new BigDecimal("95"), new BigDecimal("90"), NOW);
    }

    @ParameterizedTest(name = "{0} -> {1} allowed={2}")
    @CsvSource({
            "DRAFT, AUCTION, true", "DRAFT, CANCELLED, true", "DRAFT, BOOKED, false",
            "AUCTION, BOOKED, true", "AUCTION, CANCELLED, true", "AUCTION, ACTIVE, false", "AUCTION, COMPLETED, false",
            "BOOKED, ACTIVE, true", "BOOKED, CANCELLED, true", "BOOKED, COMPLETED, false",
            "ACTIVE, COMPLETED, true", "ACTIVE, CANCELLED, false", "ACTIVE, BOOKED, false",
            "COMPLETED, CANCELLED, false", "COMPLETED, ACTIVE, false", "CANCELLED, AUCTION, false",
    })
    void transitionTable(RideStatus from, RideStatus to, boolean allowed) {
        assertThat(from.canTransitionTo(to)).isEqualTo(allowed);
    }

    @Test
    void newRequestOpensAnAuctionWithAnEndTime() {
        Ride ride = newRide(null);
        assertThat(ride.getStatus()).isEqualTo(RideStatus.AUCTION);
        assertThat(ride.getAuctionEndsAt()).isEqualTo(NOW.plusSeconds(120));
        assertThat(ride.isAcceptingBids(NOW.plusSeconds(119))).isTrue();
        assertThat(ride.isAcceptingBids(NOW.plusSeconds(120))).isFalse();
    }

    @Test
    void acceptingABidBooksTheRideOnce() {
        Ride ride = newRide(null);
        Bid first = bidFor(ride, driver, "250");
        ride.acceptBid(first, NOW);
        assertThat(ride.getStatus()).isEqualTo(RideStatus.BOOKED);
        assertThat(ride.getSelectedBidId()).isEqualTo(first.getId());

        Bid second = bidFor(ride, UUID.randomUUID(), "240");
        assertThatThrownBy(() -> ride.acceptBid(second, NOW)).isInstanceOf(RideStateException.class);
        assertThat(ride.getSelectedBidId()).isEqualTo(first.getId());
    }

    @Test
    void bidFromAnotherRideIsRejected() {
        Ride ride = newRide(null);
        Bid foreign = bidFor(newRide(null), driver, "250");
        assertThatThrownBy(() -> ride.acceptBid(foreign, NOW)).isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    void cancelledRideCannotBeBooked() {
        Ride ride = newRide(null);
        ride.transitionTo(RideStatus.CANCELLED, NOW);
        assertThatThrownBy(() -> ride.acceptBid(bidFor(ride, driver, "250"), NOW)).isInstanceOf(RideStateException.class);
    }

    @Test
    void bidRulesEnforceWindowFareLimitAndSelfBidding() {
        Ride ride = newRide("300");
        ride.ensureCanReceiveBid(driver, new BigDecimal("300"), NOW);

        assertThatThrownBy(() -> ride.ensureCanReceiveBid(driver, new BigDecimal("300.01"), NOW))
                .isInstanceOf(RideStateException.class).hasMessageContaining("maximum fare");
        assertThatThrownBy(() -> ride.ensureCanReceiveBid(passenger, new BigDecimal("100"), NOW))
                .isInstanceOf(RideStateException.class).hasMessageContaining("own ride");
        assertThatThrownBy(() -> ride.ensureCanReceiveBid(driver, new BigDecimal("100"), NOW.plusSeconds(121)))
                .isInstanceOf(RideStateException.class).hasMessageContaining("closed");
    }

    @Test
    void fullHappyPath() {
        Ride ride = newRide(null);
        ride.acceptBid(bidFor(ride, driver, "250"), NOW);
        ride.transitionTo(RideStatus.ACTIVE, NOW);
        ride.transitionTo(RideStatus.COMPLETED, NOW);
        assertThat(ride.getStatus()).isEqualTo(RideStatus.COMPLETED);
        assertThatThrownBy(() -> ride.transitionTo(RideStatus.CANCELLED, NOW)).isInstanceOf(RideStateException.class);
    }

    @Test
    void apiValuesAreLowerCase() {
        assertThat(RideStatus.AUCTION.apiValue()).isEqualTo("auction");
        assertThat(RideStatus.fromApi("Booked")).isEqualTo(RideStatus.BOOKED);
        assertThatThrownBy(() -> RideStatus.fromApi("flying")).isInstanceOf(IllegalArgumentException.class);
    }
}
