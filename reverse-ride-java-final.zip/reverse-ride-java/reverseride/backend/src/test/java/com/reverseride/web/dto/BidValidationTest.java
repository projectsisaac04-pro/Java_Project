package com.reverseride.web.dto;

import static org.assertj.core.api.Assertions.assertThat;

import java.math.BigDecimal;
import java.util.Set;
import java.util.stream.Collectors;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import com.reverseride.web.dto.RideDtos.PlaceBidRequest;

import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;

class BidValidationTest {

    private static ValidatorFactory factory;
    private static Validator validator;

    @BeforeAll
    static void setUp() {
        factory = Validation.buildDefaultValidatorFactory();
        validator = factory.getValidator();
    }

    @AfterAll
    static void tearDown() {
        factory.close();
    }

    private static PlaceBidRequest bid(String amount, Integer eta, String rating, String completion, String trust) {
        return new PlaceBidRequest("White hatchback", amount == null ? null : new BigDecimal(amount), eta,
                rating == null ? null : new BigDecimal(rating), completion == null ? null : new BigDecimal(completion),
                trust == null ? null : new BigDecimal(trust));
    }

    private static Set<String> invalidFields(PlaceBidRequest request) {
        return validator.validate(request).stream().map(v -> v.getPropertyPath().toString()).collect(Collectors.toSet());
    }

    @Test
    void validBidPasses() {
        assertThat(invalidFields(bid("249.50", 6, "4.7", "96.5", "88"))).isEmpty();
        assertThat(invalidFields(bid("1", 0, "0", "0", "0"))).isEmpty();
        assertThat(invalidFields(bid("100000", 180, "5", "100", "100"))).isEmpty();
    }

    @Test
    void rejectsNegativeOrZeroAmounts() {
        assertThat(invalidFields(bid("-10", 6, "4.7", "96", "88"))).containsExactly("amount");
        assertThat(invalidFields(bid("0", 6, "4.7", "96", "88"))).containsExactly("amount");
        assertThat(invalidFields(bid("12.345", 6, "4.7", "96", "88"))).containsExactly("amount");
    }

    @Test
    void rejectsNegativeEta() {
        assertThat(invalidFields(bid("200", -1, "4.7", "96", "88"))).containsExactly("etaMinutes");
        assertThat(invalidFields(bid("200", 181, "4.7", "96", "88"))).containsExactly("etaMinutes");
    }

    @Test
    void rejectsOutOfRangeRatingsAndPercentages() {
        assertThat(invalidFields(bid("200", 6, "5.1", "96", "88"))).containsExactly("rating");
        assertThat(invalidFields(bid("200", 6, "-0.1", "96", "88"))).containsExactly("rating");
        assertThat(invalidFields(bid("200", 6, "4.7", "100.5", "88"))).containsExactly("completionRate");
        assertThat(invalidFields(bid("200", 6, "4.7", "96", "101"))).containsExactly("trustScore");
        assertThat(invalidFields(bid("200", 6, "4.7", "96", "-1"))).containsExactly("trustScore");
    }

    @Test
    void requiresEveryField() {
        assertThat(invalidFields(new PlaceBidRequest(" ", null, null, null, null, null)))
                .containsExactlyInAnyOrder("vehicleLabel", "amount", "etaMinutes", "rating", "completionRate", "trustScore");
    }
}
