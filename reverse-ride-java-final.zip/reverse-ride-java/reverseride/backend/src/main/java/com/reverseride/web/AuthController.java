package com.reverseride.web;

import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.reverseride.auth.GoogleIdTokenVerifier;
import com.reverseride.auth.GoogleIdentity;
import com.reverseride.auth.SessionPrincipal;
import com.reverseride.auth.SessionTokenService;
import com.reverseride.config.AppProperties;
import com.reverseride.domain.UserAccount;
import com.reverseride.service.UserService;
import com.reverseride.web.dto.AuthDtos.AuthConfigResponse;
import com.reverseride.web.dto.AuthDtos.GoogleSignInRequest;
import com.reverseride.web.dto.AuthDtos.MeResponse;
import com.reverseride.web.dto.AuthDtos.SwitchRoleRequest;

import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final AppProperties.Google google;
    private final GoogleIdTokenVerifier verifier;
    private final UserService users;
    private final SessionTokenService sessions;

    public AuthController(AppProperties properties, GoogleIdTokenVerifier verifier, UserService users, SessionTokenService sessions) {
        this.google = properties.google();
        this.verifier = verifier;
        this.users = users;
        this.sessions = sessions;
    }

    /** Public: tells the web app whether it can render the Google button, and with which client ID. */
    @GetMapping("/config")
    public AuthConfigResponse config() {
        return new AuthConfigResponse(google.configured(), google.configured() ? google.clientId() : null);
    }

    /** Exchanges a Google ID token plus the chosen role for a ReverseRide session cookie. */
    @PostMapping("/google")
    public MeResponse signInWithGoogle(@Valid @RequestBody GoogleSignInRequest request, HttpServletResponse response) {
        GoogleIdentity identity = verifier.verify(request.credential());
        UserAccount user = users.signIn(identity, request.role());
        sessions.writeCookie(response, new SessionPrincipal(user.getId(), request.role()));
        return MeResponse.from(user, request.role());
    }

    @GetMapping("/me")
    public MeResponse me(@AuthenticationPrincipal SessionPrincipal principal) {
        return MeResponse.from(users.require(principal.userId()), principal.activeRole());
    }

    /** Switches between passenger and driver mode; the account gains the role if it did not have it. */
    @PostMapping("/role")
    public MeResponse switchRole(@AuthenticationPrincipal SessionPrincipal principal, @Valid @RequestBody SwitchRoleRequest request,
            HttpServletResponse response) {
        UserAccount user = users.switchRole(principal.userId(), request.role());
        sessions.writeCookie(response, new SessionPrincipal(user.getId(), request.role()));
        return MeResponse.from(user, request.role());
    }

    @PostMapping("/logout")
    public ResponseEntity<Void> logout(HttpServletResponse response) {
        sessions.clearCookie(response);
        return ResponseEntity.noContent().build();
    }
}
