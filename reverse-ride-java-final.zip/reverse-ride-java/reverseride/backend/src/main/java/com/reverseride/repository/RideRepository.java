package com.reverseride.repository;

import java.time.Instant;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import jakarta.persistence.LockModeType;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.reverseride.domain.Ride;
import com.reverseride.domain.RideStatus;

public interface RideRepository extends JpaRepository<Ride, UUID> {

    /** Row lock so bid placement and bid acceptance on the same ride are serialised. */
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select r from Ride r where r.id = :id")
    Optional<Ride> findByIdForUpdate(@Param("id") UUID id);

    List<Ride> findByPassengerIdOrderByCreatedAtDesc(UUID passengerId);

    List<Ride> findByPassengerIdAndStatusOrderByCreatedAtDesc(UUID passengerId, RideStatus status);

    long countByPassengerIdAndStatusIn(UUID passengerId, Collection<RideStatus> statuses);

    List<Ride> findByStatusAndAuctionEndsAtAfterOrderByAuctionEndsAtAsc(RideStatus status, Instant now);

    @Query("select r from Ride r where r.selectedBidId in (select b.id from Bid b where b.driverId = :driverId) order by r.createdAt desc")
    List<Ride> findTripsForDriver(@Param("driverId") UUID driverId);
}
