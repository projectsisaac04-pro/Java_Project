package com.reverseride.auth;

import java.util.UUID;

import com.reverseride.domain.Role;

/** The signed-in user and the role (passenger or driver) they are currently acting as. */
public record SessionPrincipal(UUID userId, Role activeRole) {
}
