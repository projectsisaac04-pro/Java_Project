package com.reverseride.config;

import java.time.Duration;
import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "reverseride")
public record AppProperties(Google google, Session session, Cors cors, Auction auction) {

    public record Google(String clientId) {
        public boolean configured() {
            return clientId != null && !clientId.isBlank();
        }
    }

    public record Session(String secret, Duration ttl, boolean cookieSecure) {
    }

    public record Cors(List<String> allowedOrigins) {
    }

    /** Auction window limits, in seconds. */
    public record Auction(int defaultSeconds, int minSeconds, int maxSeconds) {
    }
}
