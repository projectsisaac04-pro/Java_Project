package com.reverseride.service;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.springframework.stereotype.Component;

import com.reverseride.domain.Bid;
import com.reverseride.scoring.ValueScoreService;
import com.reverseride.scoring.ValueScoreService.Offer;
import com.reverseride.scoring.ValueScoreService.ValueScore;
import com.reverseride.web.dto.RideDtos.BidResponse;
import com.reverseride.web.dto.RideDtos.ScoreComponentResponse;
import com.reverseride.web.dto.RideDtos.ValueScoreResponse;

/** Turns a ride's bids into responses carrying their value-score breakdown. */
@Component
public class BidViews {

    private final ValueScoreService scoring;

    public BidViews(ValueScoreService scoring) {
        this.scoring = scoring;
    }

    public List<BidResponse> toResponses(List<Bid> bids, UUID selectedBidId) {
        List<ValueScore> scores = scoring.scoreAll(bids.stream()
                .map(b -> new Offer(b.getAmount(), b.getEtaMinutes(), b.getRating(), b.getCompletionRate(), b.getTrustScore()))
                .toList());
        List<BidResponse> responses = new ArrayList<>(bids.size());
        for (int i = 0; i < bids.size(); i++) {
            Bid bid = bids.get(i);
            ValueScore score = scores.get(i);
            List<ScoreComponentResponse> components = score.components().stream()
                    .map(c -> new ScoreComponentResponse(c.factor().name().toLowerCase(), c.factor().label(), c.factor().weight(),
                            c.score(), c.contribution()))
                    .toList();
            responses.add(new BidResponse(bid.getId(), bid.getRideId(), bid.getDriverName(), bid.getVehicleLabel(), bid.getAmount(),
                    bid.getEtaMinutes(), bid.getRating(), bid.getCompletionRate(), bid.getTrustScore(), bid.getCreatedAt(),
                    bid.getId().equals(selectedBidId), new ValueScoreResponse(score.total(), components)));
        }
        return responses;
    }
}
