package com.reverseride.domain;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "bids")
public class Bid {

    @Id
    private UUID id;

    @Column(name = "ride_id", nullable = false)
    private UUID rideId;

    @Column(name = "driver_id", nullable = false)
    private UUID driverId;

    @Column(name = "driver_name", nullable = false)
    private String driverName;

    @Column(name = "vehicle_label", nullable = false)
    private String vehicleLabel;

    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal amount;

    @Column(name = "eta_minutes", nullable = false)
    private int etaMinutes;

    @Column(nullable = false, precision = 2, scale = 1)
    private BigDecimal rating;

    @Column(name = "completion_rate", nullable = false, precision = 5, scale = 2)
    private BigDecimal completionRate;

    @Column(name = "trust_score", nullable = false, precision = 5, scale = 2)
    private BigDecimal trustScore;

    @Column(name = "created_at", nullable = false)
    private Instant createdAt;

    protected Bid() {
    }

    public Bid(UUID rideId, UUID driverId, String driverName, String vehicleLabel, BigDecimal amount, int etaMinutes,
            BigDecimal rating, BigDecimal completionRate, BigDecimal trustScore, Instant now) {
        this.id = UUID.randomUUID();
        this.rideId = rideId;
        this.driverId = driverId;
        this.driverName = driverName;
        this.vehicleLabel = vehicleLabel;
        this.amount = amount;
        this.etaMinutes = etaMinutes;
        this.rating = rating;
        this.completionRate = completionRate;
        this.trustScore = trustScore;
        this.createdAt = now;
    }

    public UUID getId() {
        return id;
    }

    public UUID getRideId() {
        return rideId;
    }

    public UUID getDriverId() {
        return driverId;
    }

    public String getDriverName() {
        return driverName;
    }

    public String getVehicleLabel() {
        return vehicleLabel;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public int getEtaMinutes() {
        return etaMinutes;
    }

    public BigDecimal getRating() {
        return rating;
    }

    public BigDecimal getCompletionRate() {
        return completionRate;
    }

    public BigDecimal getTrustScore() {
        return trustScore;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }
}
