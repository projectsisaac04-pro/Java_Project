package com.reverseride.domain;

import java.math.BigDecimal;
import java.time.DayOfWeek;
import java.time.Instant;
import java.time.LocalTime;
import java.util.List;
import java.util.UUID;

import jakarta.persistence.Column;
import jakarta.persistence.Convert;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/** A saved, repeatable ride brief. It never books a ride on its own. */
@Entity
@Table(name = "commutes")
public class Commute {

    @Id
    private UUID id;

    @Column(name = "passenger_id", nullable = false)
    private UUID passengerId;

    @Column(nullable = false)
    private String label;

    @Column(nullable = false)
    private String pickup;

    @Column(nullable = false)
    private String destination;

    @Enumerated(EnumType.STRING)
    @Column(name = "vehicle_type", nullable = false)
    private VehicleType vehicleType;

    @Convert(converter = DaysOfWeekConverter.class)
    @Column(name = "days_of_week", nullable = false)
    private List<DayOfWeek> daysOfWeek;

    @Column(name = "departure_time", nullable = false)
    private LocalTime departureTime;

    @Column(name = "target_arrival", nullable = false)
    private LocalTime targetArrival;

    @Column(name = "max_fare", nullable = false, precision = 10, scale = 2)
    private BigDecimal maxFare;

    @Column(nullable = false)
    private boolean active;

    @Column(name = "created_at", nullable = false)
    private Instant createdAt;

    protected Commute() {
    }

    public Commute(UUID passengerId, String label, String pickup, String destination, VehicleType vehicleType,
            List<DayOfWeek> daysOfWeek, LocalTime departureTime, LocalTime targetArrival, BigDecimal maxFare, Instant now) {
        this.id = UUID.randomUUID();
        this.passengerId = passengerId;
        this.label = label;
        this.pickup = pickup;
        this.destination = destination;
        this.vehicleType = vehicleType;
        this.daysOfWeek = List.copyOf(daysOfWeek);
        this.departureTime = departureTime;
        this.targetArrival = targetArrival;
        this.maxFare = maxFare;
        this.active = true;
        this.createdAt = now;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public UUID getId() {
        return id;
    }

    public String getLabel() {
        return label;
    }

    public String getPickup() {
        return pickup;
    }

    public String getDestination() {
        return destination;
    }

    public VehicleType getVehicleType() {
        return vehicleType;
    }

    public List<DayOfWeek> getDaysOfWeek() {
        return daysOfWeek;
    }

    public LocalTime getDepartureTime() {
        return departureTime;
    }

    public LocalTime getTargetArrival() {
        return targetArrival;
    }

    public BigDecimal getMaxFare() {
        return maxFare;
    }

    public boolean isActive() {
        return active;
    }
}
