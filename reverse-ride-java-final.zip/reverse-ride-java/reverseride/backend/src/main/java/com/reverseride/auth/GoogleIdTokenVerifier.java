package com.reverseride.auth;

/** Verifies a Google Identity Services ID token (the "credential" from the sign-in button). */
public interface GoogleIdTokenVerifier {

    /**
     * @throws com.reverseride.web.ApiException 503 when Google sign-in is not configured,
     *         401 when the token is invalid, expired, issued for another client, or the email is unverified
     */
    GoogleIdentity verify(String idToken);
}
