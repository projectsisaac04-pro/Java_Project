package com.reverseride.scoring;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import org.springframework.stereotype.Service;

/**
 * Transparent, deterministic value score for driver offers on one ride.
 *
 * <p>Every factor is first normalised to a 0–100 scale (higher is better), then combined with
 * fixed weights. Raw rupee amounts and minutes are never mixed with percentages directly.
 *
 * <ul>
 *   <li><b>Price (25%)</b> — relative to the cheapest offer on the same ride: {@code 100 × lowest / amount}.
 *       The cheapest offer scores 100; an offer twice as expensive scores 50.</li>
 *   <li><b>ETA (20%)</b> — relative to the fastest offer: {@code 100 × (fastest + 1) / (eta + 1)}.
 *       The +1 minute keeps a 0-minute ETA well-defined.</li>
 *   <li><b>Rating (20%)</b> — {@code rating / 5 × 100}.</li>
 *   <li><b>Completion rate (15%)</b> — already a percentage.</li>
 *   <li><b>Trust score (20%)</b> — already on a 0–100 scale.</li>
 * </ul>
 *
 * <p>The score only informs the passenger; it never selects a driver automatically.
 */
@Service
public class ValueScoreService {

    public static final BigDecimal SUGGESTED_BID_MULTIPLIER = new BigDecimal("1.35");

    private static final MathContext MC = MathContext.DECIMAL64;
    private static final BigDecimal HUNDRED = BigDecimal.valueOf(100);
    private static final BigDecimal MAX_RATING = BigDecimal.valueOf(5);

    public enum Factor {
        PRICE("Price", "0.25"),
        ETA("Arrival time", "0.20"),
        RATING("Rating", "0.20"),
        COMPLETION("Completion rate", "0.15"),
        TRUST("Trust score", "0.20");

        private final String label;
        private final BigDecimal weight;

        Factor(String label, String weight) {
            this.label = label;
            this.weight = new BigDecimal(weight);
        }

        public String label() {
            return label;
        }

        public BigDecimal weight() {
            return weight;
        }
    }

    public record Offer(BigDecimal amount, int etaMinutes, BigDecimal rating, BigDecimal completionRate, BigDecimal trustScore) {
    }

    /** {@code score} is the factor's 0–100 value; {@code contribution} is {@code score × weight}. */
    public record Component(Factor factor, BigDecimal score, BigDecimal contribution) {
    }

    public record ValueScore(BigDecimal total, List<Component> components) {
    }

    /** Scores each offer relative to the others; the result list is in the same order as the input. */
    public List<ValueScore> scoreAll(List<Offer> offers) {
        if (offers.isEmpty()) {
            return List.of();
        }
        for (Offer offer : offers) {
            if (offer.amount().signum() <= 0) {
                throw new IllegalArgumentException("Offer amounts must be positive");
            }
            if (offer.etaMinutes() < 0) {
                throw new IllegalArgumentException("ETA cannot be negative");
            }
        }
        BigDecimal lowestAmount = offers.stream().map(Offer::amount).min(Comparator.naturalOrder()).orElseThrow();
        int fastestEta = offers.stream().mapToInt(Offer::etaMinutes).min().orElseThrow();

        List<ValueScore> scores = new ArrayList<>(offers.size());
        for (Offer offer : offers) {
            BigDecimal price = HUNDRED.multiply(lowestAmount).divide(offer.amount(), MC);
            BigDecimal eta = HUNDRED.multiply(BigDecimal.valueOf(fastestEta + 1L))
                    .divide(BigDecimal.valueOf(offer.etaMinutes() + 1L), MC);
            BigDecimal rating = offer.rating().divide(MAX_RATING, MC).multiply(HUNDRED);
            scores.add(combine(List.of(
                    new Raw(Factor.PRICE, price),
                    new Raw(Factor.ETA, eta),
                    new Raw(Factor.RATING, rating),
                    new Raw(Factor.COMPLETION, offer.completionRate()),
                    new Raw(Factor.TRUST, offer.trustScore()))));
        }
        return scores;
    }

    /** Suggested driver offer: operating cost × 1.35, rounded to a whole rupee. A suggestion, not a fare. */
    public BigDecimal suggestedBid(BigDecimal operatingCost) {
        if (operatingCost == null || operatingCost.signum() <= 0) {
            throw new IllegalArgumentException("Operating cost must be positive");
        }
        return operatingCost.multiply(SUGGESTED_BID_MULTIPLIER).setScale(0, RoundingMode.HALF_UP);
    }

    private record Raw(Factor factor, BigDecimal score) {
    }

    private ValueScore combine(List<Raw> raws) {
        BigDecimal total = BigDecimal.ZERO;
        List<Component> components = new ArrayList<>(raws.size());
        for (Raw raw : raws) {
            BigDecimal score = clamp(raw.score());
            BigDecimal contribution = score.multiply(raw.factor().weight(), MC);
            total = total.add(contribution);
            components.add(new Component(raw.factor(), round(score), round(contribution)));
        }
        return new ValueScore(round(total), List.copyOf(components));
    }

    private static BigDecimal clamp(BigDecimal value) {
        return value.max(BigDecimal.ZERO).min(HUNDRED);
    }

    private static BigDecimal round(BigDecimal value) {
        return value.setScale(1, RoundingMode.HALF_UP);
    }
}
