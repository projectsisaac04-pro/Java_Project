package com.reverseride.web;

import java.util.List;
import java.util.UUID;

import org.springframework.http.HttpStatus;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.reverseride.auth.SessionPrincipal;
import com.reverseride.domain.RideStatus;
import com.reverseride.service.RideService;
import com.reverseride.web.dto.RideDtos.BidResponse;
import com.reverseride.web.dto.RideDtos.CreateRideRequest;
import com.reverseride.web.dto.RideDtos.DashboardSummaryResponse;
import com.reverseride.web.dto.RideDtos.FareExplanationResponse;
import com.reverseride.web.dto.RideDtos.RideResponse;

import jakarta.validation.Valid;

/** Passenger endpoints (requires passenger mode). */
@RestController
@RequestMapping("/api")
public class RideController {

    private final RideService rides;

    public RideController(RideService rides) {
        this.rides = rides;
    }

    @GetMapping("/rides")
    public List<RideResponse> list(@AuthenticationPrincipal SessionPrincipal me, @RequestParam(required = false) String status) {
        RideStatus filter;
        try {
            filter = status == null || status.isBlank() ? null : RideStatus.fromApi(status);
        } catch (IllegalArgumentException ex) {
            throw ApiException.invalidField("status", ex.getMessage());
        }
        return rides.list(me.userId(), filter);
    }

    @PostMapping("/rides")
    @ResponseStatus(HttpStatus.CREATED)
    public RideResponse create(@AuthenticationPrincipal SessionPrincipal me, @Valid @RequestBody CreateRideRequest request) {
        return rides.create(me.userId(), request);
    }

    @GetMapping("/rides/{rideId}")
    public RideResponse get(@AuthenticationPrincipal SessionPrincipal me, @PathVariable UUID rideId) {
        return rides.get(me.userId(), rideId);
    }

    @GetMapping("/rides/{rideId}/bids")
    public List<BidResponse> bids(@AuthenticationPrincipal SessionPrincipal me, @PathVariable UUID rideId) {
        return rides.bids(me.userId(), rideId);
    }

    @PostMapping("/rides/{rideId}/bids/{bidId}/accept")
    public RideResponse accept(@AuthenticationPrincipal SessionPrincipal me, @PathVariable UUID rideId, @PathVariable UUID bidId) {
        return rides.acceptBid(me.userId(), rideId, bidId);
    }

    @PostMapping("/rides/{rideId}/cancel")
    public RideResponse cancel(@AuthenticationPrincipal SessionPrincipal me, @PathVariable UUID rideId) {
        return rides.cancel(me.userId(), rideId);
    }

    /** No routing, traffic or pricing provider is integrated, so no figures are invented. */
    @GetMapping("/rides/{rideId}/fare-explanation")
    public FareExplanationResponse fareExplanation(@AuthenticationPrincipal SessionPrincipal me, @PathVariable UUID rideId) {
        rides.owned(me.userId(), rideId);
        return new FareExplanationResponse(false,
                "No routing, traffic or pricing provider is configured, so ReverseRide does not estimate this fare. Driver offers are the only prices shown.",
                null, null, null, null, null, null);
    }

    @GetMapping("/dashboard/summary")
    public DashboardSummaryResponse summary(@AuthenticationPrincipal SessionPrincipal me) {
        return rides.summary(me.userId());
    }
}
