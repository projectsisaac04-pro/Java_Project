package com.reverseride.domain;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

public enum VehicleType {
    BIKE,
    AUTO,
    CAR,
    PREMIUM;

    @JsonValue
    public String apiValue() {
        return ApiEnums.toApi(this);
    }

    @JsonCreator
    public static VehicleType fromApi(String value) {
        return ApiEnums.fromApi(VehicleType.class, value);
    }
}
