package com.reverseride.web.dto;

import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;

import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

import com.reverseride.domain.Commute;
import com.reverseride.domain.VehicleType;

public final class CommuteDtos {

    private static final String TIME_PATTERN = "^([01]\\d|2[0-3]):[0-5]\\d$";

    private CommuteDtos() {
    }

    public record CreateCommuteRequest(
            @NotBlank(message = "Give this commute a label") @Size(max = 120) String label,
            @NotBlank(message = "Add a pickup point") @Size(max = 300) String pickup,
            @NotBlank(message = "Add a destination") @Size(max = 300) String destination,
            @NotNull(message = "Choose a vehicle type") VehicleType vehicleType,
            @NotEmpty(message = "Pick at least one day") List<@Pattern(regexp = "^(?i)(MON|TUE|WED|THU|FRI|SAT|SUN)$", message = "Use MON..SUN") String> daysOfWeek,
            @NotNull(message = "Set a departure time") @Pattern(regexp = TIME_PATTERN, message = "Use HH:mm") String departureTime,
            @NotNull(message = "Set a target arrival") @Pattern(regexp = TIME_PATTERN, message = "Use HH:mm") String targetArrival,
            @NotNull(message = "Set a maximum fare")
            @DecimalMin(value = "1.00", message = "Maximum fare must be at least ₹1")
            @DecimalMax(value = "100000.00", message = "Maximum fare must be at most ₹1,00,000")
            @Digits(integer = 6, fraction = 2, message = "Use at most 2 decimal places") BigDecimal maxFare) {
    }

    public record UpdateCommuteRequest(@NotNull(message = "Set active to true or false") Boolean active) {
    }

    public record CommuteResponse(
            UUID id,
            String label,
            String pickup,
            String destination,
            VehicleType vehicleType,
            List<String> daysOfWeek,
            String departureTime,
            String targetArrival,
            BigDecimal maxFare,
            boolean active) {

        public static CommuteResponse from(Commute commute) {
            List<String> days = commute.getDaysOfWeek().stream().map(d -> d.name().substring(0, 3)).toList();
            return new CommuteResponse(commute.getId(), commute.getLabel(), commute.getPickup(), commute.getDestination(),
                    commute.getVehicleType(), days, commute.getDepartureTime().toString(), commute.getTargetArrival().toString(),
                    commute.getMaxFare(), commute.isActive());
        }
    }
}
