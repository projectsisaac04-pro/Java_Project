package com.reverseride.auth;

import java.io.IOException;
import java.util.List;

import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.OncePerRequestFilter;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/** Authenticates requests from the session cookie. Authority is the active role only. */
public class SessionAuthenticationFilter extends OncePerRequestFilter {

    private final SessionTokenService tokens;

    public SessionAuthenticationFilter(SessionTokenService tokens) {
        this.tokens = tokens;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
            throws ServletException, IOException {
        Cookie[] cookies = request.getCookies();
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if (SessionTokenService.COOKIE_NAME.equals(cookie.getName()) && !cookie.getValue().isBlank()) {
                    tokens.parse(cookie.getValue()).ifPresent(principal -> {
                        var authority = new SimpleGrantedAuthority("ROLE_" + principal.activeRole().name());
                        var authentication = new UsernamePasswordAuthenticationToken(principal, null, List.of(authority));
                        SecurityContextHolder.getContext().setAuthentication(authentication);
                    });
                }
            }
        }
        chain.doFilter(request, response);
    }
}
