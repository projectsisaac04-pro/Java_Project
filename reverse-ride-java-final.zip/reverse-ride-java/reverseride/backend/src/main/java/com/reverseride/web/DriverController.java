package com.reverseride.web;

import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;

import org.springframework.http.HttpStatus;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.reverseride.auth.SessionPrincipal;
import com.reverseride.domain.RideStatus;
import com.reverseride.scoring.ValueScoreService;
import com.reverseride.service.DriverService;
import com.reverseride.web.dto.RideDtos.DriverTripResponse;
import com.reverseride.web.dto.RideDtos.OpenRideResponse;
import com.reverseride.web.dto.RideDtos.PlaceBidRequest;
import com.reverseride.web.dto.RideDtos.SuggestedBidResponse;

import jakarta.validation.Valid;

/** Driver endpoints (requires driver mode). */
@RestController
@RequestMapping("/api/driver")
public class DriverController {

    private static final BigDecimal MAX_OPERATING_COST = new BigDecimal("100000");

    private final DriverService drivers;
    private final ValueScoreService scoring;

    public DriverController(DriverService drivers, ValueScoreService scoring) {
        this.drivers = drivers;
        this.scoring = scoring;
    }

    @GetMapping("/open-rides")
    public List<OpenRideResponse> openRides(@AuthenticationPrincipal SessionPrincipal me) {
        return drivers.openRides(me.userId());
    }

    @PostMapping("/rides/{rideId}/bids")
    @ResponseStatus(HttpStatus.CREATED)
    public OpenRideResponse placeBid(@AuthenticationPrincipal SessionPrincipal me, @PathVariable UUID rideId,
            @Valid @RequestBody PlaceBidRequest request) {
        return drivers.placeBid(me.userId(), rideId, request);
    }

    @GetMapping("/trips")
    public List<DriverTripResponse> trips(@AuthenticationPrincipal SessionPrincipal me) {
        return drivers.trips(me.userId());
    }

    @PostMapping("/trips/{rideId}/start")
    public DriverTripResponse start(@AuthenticationPrincipal SessionPrincipal me, @PathVariable UUID rideId) {
        return drivers.advanceTrip(me.userId(), rideId, RideStatus.ACTIVE);
    }

    @PostMapping("/trips/{rideId}/complete")
    public DriverTripResponse complete(@AuthenticationPrincipal SessionPrincipal me, @PathVariable UUID rideId) {
        return drivers.advanceTrip(me.userId(), rideId, RideStatus.COMPLETED);
    }

    @GetMapping("/suggested-bid")
    public SuggestedBidResponse suggestedBid(@RequestParam BigDecimal operatingCost) {
        if (operatingCost.signum() <= 0 || operatingCost.compareTo(MAX_OPERATING_COST) > 0) {
            throw ApiException.invalidField("operatingCost", "Operating cost must be between ₹1 and ₹1,00,000");
        }
        return new SuggestedBidResponse(operatingCost, ValueScoreService.SUGGESTED_BID_MULTIPLIER, scoring.suggestedBid(operatingCost),
                "A starting point based on your operating cost × 1.35. You choose the final offer; it is not a guaranteed fare.");
    }
}
