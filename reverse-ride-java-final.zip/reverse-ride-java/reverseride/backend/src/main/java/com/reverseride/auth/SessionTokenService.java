package com.reverseride.auth;

import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.text.ParseException;
import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.util.Date;
import java.util.Optional;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseCookie;
import org.springframework.stereotype.Service;

import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.JWSHeader;
import com.nimbusds.jose.crypto.MACSigner;
import com.nimbusds.jose.crypto.MACVerifier;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;
import com.reverseride.config.AppProperties;
import com.reverseride.domain.Role;

import jakarta.servlet.http.HttpServletResponse;

/** Issues and verifies the HMAC-signed session token kept in an HttpOnly cookie. */
@Service
public class SessionTokenService {

    public static final String COOKIE_NAME = "rr_session";

    private static final Logger log = LoggerFactory.getLogger(SessionTokenService.class);
    private static final String ISSUER = "reverseride";

    private final byte[] secret;
    private final Duration ttl;
    private final boolean cookieSecure;
    private final Clock clock;

    public SessionTokenService(AppProperties properties, Clock clock) {
        AppProperties.Session session = properties.session();
        this.secret = resolveSecret(session.secret());
        this.ttl = session.ttl();
        this.cookieSecure = session.cookieSecure();
        this.clock = clock;
    }

    public String issue(SessionPrincipal principal) {
        Instant now = clock.instant();
        JWTClaimsSet claims = new JWTClaimsSet.Builder()
                .issuer(ISSUER)
                .subject(principal.userId().toString())
                .claim("role", principal.activeRole().name())
                .issueTime(Date.from(now))
                .expirationTime(Date.from(now.plus(ttl)))
                .build();
        SignedJWT jwt = new SignedJWT(new JWSHeader(JWSAlgorithm.HS256), claims);
        try {
            jwt.sign(new MACSigner(secret));
        } catch (JOSEException ex) {
            throw new IllegalStateException("Could not sign session token", ex);
        }
        return jwt.serialize();
    }

    public Optional<SessionPrincipal> parse(String token) {
        try {
            SignedJWT jwt = SignedJWT.parse(token);
            if (!JWSAlgorithm.HS256.equals(jwt.getHeader().getAlgorithm()) || !jwt.verify(new MACVerifier(secret))) {
                return Optional.empty();
            }
            JWTClaimsSet claims = jwt.getJWTClaimsSet();
            Date expires = claims.getExpirationTime();
            if (!ISSUER.equals(claims.getIssuer()) || expires == null || !clock.instant().isBefore(expires.toInstant())) {
                return Optional.empty();
            }
            return Optional.of(new SessionPrincipal(UUID.fromString(claims.getSubject()), Role.valueOf(claims.getStringClaim("role"))));
        } catch (ParseException | JOSEException | IllegalArgumentException | NullPointerException ex) {
            return Optional.empty();
        }
    }

    public void writeCookie(HttpServletResponse response, SessionPrincipal principal) {
        response.addHeader(HttpHeaders.SET_COOKIE, cookie(issue(principal), ttl).toString());
    }

    public void clearCookie(HttpServletResponse response) {
        response.addHeader(HttpHeaders.SET_COOKIE, cookie("", Duration.ZERO).toString());
    }

    private ResponseCookie cookie(String value, Duration maxAge) {
        return ResponseCookie.from(COOKIE_NAME, value)
                .httpOnly(true)
                .secure(cookieSecure)
                .sameSite("Lax")
                .path("/")
                .maxAge(maxAge)
                .build();
    }

    private static byte[] resolveSecret(String configured) {
        if (configured == null || configured.isBlank()) {
            log.warn("SESSION_SECRET is not set; using a random secret. Everyone is signed out when the API restarts.");
            byte[] random = new byte[32];
            new SecureRandom().nextBytes(random);
            return random;
        }
        byte[] bytes = configured.getBytes(StandardCharsets.UTF_8);
        if (bytes.length < 32) {
            throw new IllegalStateException("SESSION_SECRET must be at least 32 bytes long.");
        }
        return bytes;
    }
}
