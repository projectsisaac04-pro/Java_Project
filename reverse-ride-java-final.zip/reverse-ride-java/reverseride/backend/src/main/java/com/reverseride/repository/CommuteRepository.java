package com.reverseride.repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

import com.reverseride.domain.Commute;

public interface CommuteRepository extends JpaRepository<Commute, UUID> {

    List<Commute> findByPassengerIdOrderByLabelAsc(UUID passengerId);

    Optional<Commute> findByIdAndPassengerId(UUID id, UUID passengerId);

    long countByPassengerId(UUID passengerId);
}
