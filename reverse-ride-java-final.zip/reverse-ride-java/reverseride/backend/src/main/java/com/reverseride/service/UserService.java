package com.reverseride.service;

import java.time.Clock;
import java.util.UUID;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.reverseride.auth.GoogleIdentity;
import com.reverseride.domain.Role;
import com.reverseride.domain.UserAccount;
import com.reverseride.repository.UserRepository;
import com.reverseride.web.ApiException;

@Service
public class UserService {

    private final UserRepository users;
    private final Clock clock;

    public UserService(UserRepository users, Clock clock) {
        this.users = users;
        this.clock = clock;
    }

    /** Creates the account on first sign-in, refreshes the Google profile, and grants the chosen role. */
    @Transactional
    public UserAccount signIn(GoogleIdentity identity, Role role) {
        String email = limit(identity.email(), 320);
        String name = limit(identity.name(), 200);
        String picture = limit(identity.pictureUrl(), 1000);
        UserAccount user = users.findByGoogleSubject(identity.subject())
                .map(existing -> {
                    existing.updateProfile(email, name, picture, clock.instant());
                    return existing;
                })
                .orElseGet(() -> users.save(UserAccount.fromGoogle(identity.subject(), email, name, picture, clock.instant())));
        user.grantRole(role);
        return user;
    }

    @Transactional
    public UserAccount switchRole(UUID userId, Role role) {
        UserAccount user = require(userId);
        user.grantRole(role);
        return user;
    }

    @Transactional(readOnly = true)
    public UserAccount require(UUID userId) {
        return users.findById(userId)
                .orElseThrow(() -> new ApiException(HttpStatus.UNAUTHORIZED, "Your session is no longer valid. Please sign in again."));
    }

    private static String limit(String value, int max) {
        if (value == null) {
            return null;
        }
        return value.length() <= max ? value : value.substring(0, max);
    }
}
