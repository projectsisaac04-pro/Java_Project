package com.reverseride.repository;

import java.util.Optional;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

import com.reverseride.domain.UserAccount;

public interface UserRepository extends JpaRepository<UserAccount, UUID> {

    Optional<UserAccount> findByGoogleSubject(String googleSubject);
}
