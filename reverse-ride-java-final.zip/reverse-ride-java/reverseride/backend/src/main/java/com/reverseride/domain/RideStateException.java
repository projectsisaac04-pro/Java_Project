package com.reverseride.domain;

/** A request conflicts with the ride's current lifecycle state. Mapped to HTTP 409. */
public class RideStateException extends RuntimeException {

    public RideStateException(String message) {
        super(message);
    }
}
