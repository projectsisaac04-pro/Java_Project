package com.reverseride.auth;

import java.util.List;
import java.util.Set;

import org.springframework.http.HttpStatus;
import org.springframework.security.oauth2.core.DelegatingOAuth2TokenValidator;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtClaimNames;
import org.springframework.security.oauth2.jwt.JwtClaimValidator;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.jwt.JwtException;
import org.springframework.security.oauth2.jwt.JwtTimestampValidator;
import org.springframework.security.oauth2.jwt.NimbusJwtDecoder;
import org.springframework.stereotype.Component;

import com.reverseride.config.AppProperties;
import com.reverseride.web.ApiException;

/** Checks signature (Google JWKS), issuer, audience (our client ID), expiry and email verification. */
@Component
public class NimbusGoogleIdTokenVerifier implements GoogleIdTokenVerifier {

    private static final String GOOGLE_JWKS_URI = "https://www.googleapis.com/oauth2/v3/certs";
    private static final Set<String> GOOGLE_ISSUERS = Set.of("https://accounts.google.com", "accounts.google.com");

    private final AppProperties.Google google;
    private volatile JwtDecoder decoder;

    public NimbusGoogleIdTokenVerifier(AppProperties properties) {
        this.google = properties.google();
    }

    @Override
    public GoogleIdentity verify(String idToken) {
        if (!google.configured()) {
            throw new ApiException(HttpStatus.SERVICE_UNAVAILABLE, "Google sign-in is not configured on this server.");
        }
        Jwt jwt;
        try {
            jwt = decoder().decode(idToken);
        } catch (JwtException ex) {
            throw new ApiException(HttpStatus.UNAUTHORIZED, "Google could not confirm this sign-in. Please try again.");
        }
        Object emailVerified = jwt.getClaims().get("email_verified");
        if (!Boolean.TRUE.equals(emailVerified) && !"true".equals(emailVerified)) {
            throw new ApiException(HttpStatus.UNAUTHORIZED, "Your Google account email is not verified.");
        }
        String email = jwt.getClaimAsString("email");
        String name = jwt.getClaimAsString("name");
        return new GoogleIdentity(jwt.getSubject(), email, name == null || name.isBlank() ? email : name, jwt.getClaimAsString("picture"));
    }

    private JwtDecoder decoder() {
        JwtDecoder current = decoder;
        if (current == null) {
            synchronized (this) {
                if (decoder == null) {
                    NimbusJwtDecoder built = NimbusJwtDecoder.withJwkSetUri(GOOGLE_JWKS_URI).build();
                    built.setJwtValidator(new DelegatingOAuth2TokenValidator<>(
                            new JwtTimestampValidator(),
                            new JwtClaimValidator<Object>(JwtClaimNames.ISS, iss -> iss != null && GOOGLE_ISSUERS.contains(iss.toString())),
                            new JwtClaimValidator<List<String>>(JwtClaimNames.AUD, aud -> aud != null && aud.contains(google.clientId()))));
                    decoder = built;
                }
                current = decoder;
            }
        }
        return current;
    }
}
