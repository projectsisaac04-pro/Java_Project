package com.reverseride.service;

import java.time.Clock;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.reverseride.domain.Bid;
import com.reverseride.domain.Ride;
import com.reverseride.domain.RideStateException;
import com.reverseride.domain.RideStatus;
import com.reverseride.domain.UserAccount;
import com.reverseride.repository.BidRepository;
import com.reverseride.repository.RideRepository;
import com.reverseride.web.ApiException;
import com.reverseride.web.dto.RideDtos.DriverTripResponse;
import com.reverseride.web.dto.RideDtos.OpenRideResponse;
import com.reverseride.web.dto.RideDtos.PlaceBidRequest;

/** Driver-side operations: open requests, bidding, and running booked trips. */
@Service
public class DriverService {

    private final RideRepository rides;
    private final BidRepository bids;
    private final UserService users;
    private final Clock clock;

    public DriverService(RideRepository rides, BidRepository bids, UserService users, Clock clock) {
        this.rides = rides;
        this.bids = bids;
        this.users = users;
        this.clock = clock;
    }

    /** Auctions still inside their bidding window, excluding the driver's own passenger requests. */
    @Transactional(readOnly = true)
    public List<OpenRideResponse> openRides(UUID driverId) {
        List<Ride> open = rides.findByStatusAndAuctionEndsAtAfterOrderByAuctionEndsAtAsc(RideStatus.AUCTION, clock.instant())
                .stream().filter(r -> !r.getPassengerId().equals(driverId)).toList();
        List<UUID> ids = open.stream().map(Ride::getId).toList();
        Map<UUID, Long> counts = bids.countByRideIds(ids);
        Map<UUID, Bid> mine = ids.isEmpty() ? Map.of()
                : bids.findByDriverIdAndRideIdIn(driverId, ids).stream().collect(Collectors.toMap(Bid::getRideId, Function.identity()));
        return open.stream().map(r -> OpenRideResponse.from(r, counts.getOrDefault(r.getId(), 0L), mine.get(r.getId()))).toList();
    }

    @Transactional
    public OpenRideResponse placeBid(UUID driverId, UUID rideId, PlaceBidRequest request) {
        Ride ride = rides.findByIdForUpdate(rideId).orElseThrow(() -> ApiException.notFound("Ride"));
        Instant now = clock.instant();
        ride.ensureCanReceiveBid(driverId, request.amount(), now);
        if (bids.existsByRideIdAndDriverId(rideId, driverId)) {
            throw new RideStateException("You have already placed a bid on this ride.");
        }
        UserAccount driver = users.require(driverId);
        Bid bid = bids.save(new Bid(rideId, driverId, driver.getDisplayName(), request.vehicleLabel().trim(), request.amount(),
                request.etaMinutes(), request.rating(), request.completionRate(), request.trustScore(), now));
        return OpenRideResponse.from(ride, bids.countByRideIds(List.of(rideId)).getOrDefault(rideId, 0L), bid);
    }

    /** Rides where this driver's bid was accepted. */
    @Transactional(readOnly = true)
    public List<DriverTripResponse> trips(UUID driverId) {
        List<Ride> trips = rides.findTripsForDriver(driverId);
        Map<UUID, Bid> selected = bids.findByIdIn(trips.stream().map(Ride::getSelectedBidId).toList()).stream()
                .collect(Collectors.toMap(Bid::getId, Function.identity()));
        return trips.stream().map(r -> DriverTripResponse.from(r, selected.get(r.getSelectedBidId()))).toList();
    }

    @Transactional
    public DriverTripResponse advanceTrip(UUID driverId, UUID rideId, RideStatus next) {
        Ride ride = rides.findByIdForUpdate(rideId).orElseThrow(() -> ApiException.notFound("Trip"));
        Bid selected = Optional.ofNullable(ride.getSelectedBidId()).flatMap(bids::findById)
                .filter(b -> b.getDriverId().equals(driverId))
                .orElseThrow(() -> ApiException.notFound("Trip"));
        ride.transitionTo(next, clock.instant());
        return DriverTripResponse.from(ride, selected);
    }

    /** True when the user is the driver whose bid was accepted for this ride. */
    @Transactional(readOnly = true)
    public boolean isAssignedDriver(UUID driverId, Ride ride) {
        return ride.getSelectedBidId() != null
                && bids.findById(ride.getSelectedBidId()).map(b -> b.getDriverId().equals(driverId)).orElse(false);
    }
}
