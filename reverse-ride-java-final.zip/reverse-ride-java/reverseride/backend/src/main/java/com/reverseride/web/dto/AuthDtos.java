package com.reverseride.web.dto;

import java.util.List;
import java.util.UUID;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import com.reverseride.domain.Role;
import com.reverseride.domain.UserAccount;

public final class AuthDtos {

    private AuthDtos() {
    }

    public record AuthConfigResponse(boolean googleConfigured, String googleClientId) {
    }

    /** {@code credential} is the ID token returned by the Google Identity Services button. */
    public record GoogleSignInRequest(
            @NotBlank(message = "Missing Google credential") String credential,
            @NotNull(message = "Choose passenger or driver") Role role) {
    }

    public record SwitchRoleRequest(@NotNull(message = "Choose passenger or driver") Role role) {
    }

    public record MeResponse(UUID id, String email, String name, String pictureUrl, Role activeRole, List<Role> roles) {

        public static MeResponse from(UserAccount user, Role activeRole) {
            List<Role> roles = user.getRoles().stream().sorted().toList();
            return new MeResponse(user.getId(), user.getEmail(), user.getDisplayName(), user.getPictureUrl(), activeRole, roles);
        }
    }
}
