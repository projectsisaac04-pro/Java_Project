package com.reverseride.domain;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

public enum Role {
    PASSENGER,
    DRIVER;

    @JsonValue
    public String apiValue() {
        return ApiEnums.toApi(this);
    }

    @JsonCreator
    public static Role fromApi(String value) {
        return ApiEnums.fromApi(Role.class, value);
    }
}
