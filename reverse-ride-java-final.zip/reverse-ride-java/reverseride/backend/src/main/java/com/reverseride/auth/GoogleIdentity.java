package com.reverseride.auth;

/** The verified claims we use from a Google ID token. */
public record GoogleIdentity(String subject, String email, String name, String pictureUrl) {
}
