package com.reverseride.service;

import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.util.EnumSet;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.reverseride.config.AppProperties;
import com.reverseride.domain.Bid;
import com.reverseride.domain.Ride;
import com.reverseride.domain.RideStatus;
import com.reverseride.repository.BidRepository;
import com.reverseride.repository.CommuteRepository;
import com.reverseride.repository.RideRepository;
import com.reverseride.web.ApiException;
import com.reverseride.web.dto.RideDtos.BidResponse;
import com.reverseride.web.dto.RideDtos.CreateRideRequest;
import com.reverseride.web.dto.RideDtos.DashboardSummaryResponse;
import com.reverseride.web.dto.RideDtos.RideResponse;

/** Passenger-side ride operations. Every lookup is scoped to the signed-in passenger. */
@Service
public class RideService {

    private final RideRepository rides;
    private final BidRepository bids;
    private final CommuteRepository commutes;
    private final BidViews bidViews;
    private final AppProperties.Auction auction;
    private final Clock clock;

    public RideService(RideRepository rides, BidRepository bids, CommuteRepository commutes, BidViews bidViews,
            AppProperties properties, Clock clock) {
        this.rides = rides;
        this.bids = bids;
        this.commutes = commutes;
        this.bidViews = bidViews;
        this.auction = properties.auction();
        this.clock = clock;
    }

    @Transactional
    public RideResponse create(UUID passengerId, CreateRideRequest request) {
        int seconds = request.auctionDurationSeconds() == null ? auction.defaultSeconds() : request.auctionDurationSeconds();
        if (seconds < auction.minSeconds() || seconds > auction.maxSeconds()) {
            throw ApiException.invalidField("auctionDurationSeconds",
                    "Auction must last between " + auction.minSeconds() + " and " + auction.maxSeconds() + " seconds");
        }
        Instant now = clock.instant();
        Ride ride = Ride.openAuction(passengerId, request.pickup().trim(), request.destination().trim(), request.vehicleType(),
                request.passengerCount() == null ? 1 : request.passengerCount(), request.targetArrival(), request.maxFare(),
                Duration.ofSeconds(seconds), now);
        rides.save(ride);
        return RideResponse.from(ride, 0, now);
    }

    @Transactional(readOnly = true)
    public List<RideResponse> list(UUID passengerId, RideStatus status) {
        List<Ride> found = status == null
                ? rides.findByPassengerIdOrderByCreatedAtDesc(passengerId)
                : rides.findByPassengerIdAndStatusOrderByCreatedAtDesc(passengerId, status);
        Map<UUID, Long> counts = bids.countByRideIds(found.stream().map(Ride::getId).toList());
        Instant now = clock.instant();
        return found.stream().map(r -> RideResponse.from(r, counts.getOrDefault(r.getId(), 0L), now)).toList();
    }

    @Transactional(readOnly = true)
    public RideResponse get(UUID passengerId, UUID rideId) {
        Ride ride = owned(passengerId, rideId);
        return RideResponse.from(ride, bids.countByRideIds(List.of(rideId)).getOrDefault(rideId, 0L), clock.instant());
    }

    @Transactional(readOnly = true)
    public List<BidResponse> bids(UUID passengerId, UUID rideId) {
        Ride ride = owned(passengerId, rideId);
        return bidViews.toResponses(bids.findByRideIdOrderByAmountAscCreatedAtAsc(rideId), ride.getSelectedBidId());
    }

    /** Locks the ride row, checks the bid belongs to it and the ride is still open, then books it. */
    @Transactional
    public RideResponse acceptBid(UUID passengerId, UUID rideId, UUID bidId) {
        Ride ride = rides.findByIdForUpdate(rideId)
                .filter(r -> r.getPassengerId().equals(passengerId))
                .orElseThrow(() -> ApiException.notFound("Ride"));
        Bid bid = bids.findById(bidId)
                .filter(b -> b.getRideId().equals(rideId))
                .orElseThrow(() -> ApiException.notFound("Bid"));
        Instant now = clock.instant();
        ride.acceptBid(bid, now);
        return RideResponse.from(ride, bids.countByRideIds(List.of(rideId)).getOrDefault(rideId, 0L), now);
    }

    @Transactional
    public RideResponse cancel(UUID passengerId, UUID rideId) {
        Ride ride = rides.findByIdForUpdate(rideId)
                .filter(r -> r.getPassengerId().equals(passengerId))
                .orElseThrow(() -> ApiException.notFound("Ride"));
        Instant now = clock.instant();
        ride.transitionTo(RideStatus.CANCELLED, now);
        return RideResponse.from(ride, bids.countByRideIds(List.of(rideId)).getOrDefault(rideId, 0L), now);
    }

    @Transactional(readOnly = true)
    public DashboardSummaryResponse summary(UUID passengerId) {
        long active = rides.countByPassengerIdAndStatusIn(passengerId, EnumSet.of(RideStatus.AUCTION, RideStatus.BOOKED, RideStatus.ACTIVE));
        long completed = rides.countByPassengerIdAndStatusIn(passengerId, EnumSet.of(RideStatus.COMPLETED));
        // No rating history exists yet, so there is no passenger score to report.
        return new DashboardSummaryResponse(active, completed, commutes.countByPassengerId(passengerId), null);
    }

    /** Ride visible to the passenger who owns it; anyone else gets a 404. */
    @Transactional(readOnly = true)
    public Ride owned(UUID passengerId, UUID rideId) {
        return rides.findById(rideId)
                .filter(r -> r.getPassengerId().equals(passengerId))
                .orElseThrow(() -> ApiException.notFound("Ride"));
    }
}
