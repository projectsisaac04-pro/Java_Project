package com.reverseride.repository;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.reverseride.domain.Bid;

public interface BidRepository extends JpaRepository<Bid, UUID> {

    List<Bid> findByRideIdOrderByAmountAscCreatedAtAsc(UUID rideId);

    boolean existsByRideIdAndDriverId(UUID rideId, UUID driverId);

    List<Bid> findByDriverIdAndRideIdIn(UUID driverId, Collection<UUID> rideIds);

    List<Bid> findByIdIn(Collection<UUID> ids);

    @Query("select b.rideId, count(b) from Bid b where b.rideId in :rideIds group by b.rideId")
    List<Object[]> countRowsByRideIds(@Param("rideIds") Collection<UUID> rideIds);

    default Map<UUID, Long> countByRideIds(Collection<UUID> rideIds) {
        if (rideIds.isEmpty()) {
            return Map.of();
        }
        return countRowsByRideIds(rideIds).stream()
                .collect(Collectors.toMap(row -> (UUID) row[0], row -> ((Number) row[1]).longValue()));
    }
}
