package com.reverseride.domain;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

/**
 * Ride lifecycle:
 *
 * <pre>
 * draft ──► auction ──► booked ──► active ──► completed
 *   │          │           │
 *   └──────────┴───────────┴──► cancelled
 * </pre>
 */
public enum RideStatus {
    DRAFT,
    AUCTION,
    BOOKED,
    ACTIVE,
    COMPLETED,
    CANCELLED;

    public boolean canTransitionTo(RideStatus next) {
        return switch (this) {
            case DRAFT -> next == AUCTION || next == CANCELLED;
            case AUCTION -> next == BOOKED || next == CANCELLED;
            case BOOKED -> next == ACTIVE || next == CANCELLED;
            case ACTIVE -> next == COMPLETED;
            case COMPLETED, CANCELLED -> false;
        };
    }

    /** Statuses that still need the passenger's attention. */
    public boolean isInProgress() {
        return this == AUCTION || this == BOOKED || this == ACTIVE;
    }

    @JsonValue
    public String apiValue() {
        return ApiEnums.toApi(this);
    }

    @JsonCreator
    public static RideStatus fromApi(String value) {
        return ApiEnums.fromApi(RideStatus.class, value);
    }
}
