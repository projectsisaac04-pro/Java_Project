package com.reverseride.domain;

import java.util.Arrays;
import java.util.Locale;
import java.util.stream.Collectors;

/** Enums are stored upper-case in the database and exposed lower-case in the API. */
public final class ApiEnums {

    private ApiEnums() {
    }

    public static String toApi(Enum<?> value) {
        return value.name().toLowerCase(Locale.ROOT);
    }

    public static <E extends Enum<E>> E fromApi(Class<E> type, String value) {
        if (value != null) {
            for (E constant : type.getEnumConstants()) {
                if (constant.name().equalsIgnoreCase(value.trim())) {
                    return constant;
                }
            }
        }
        String allowed = Arrays.stream(type.getEnumConstants()).map(ApiEnums::toApi).collect(Collectors.joining(", "));
        throw new IllegalArgumentException("'" + value + "' is not one of: " + allowed);
    }
}
