package com.reverseride.web;

import java.util.List;
import java.util.UUID;

import org.springframework.http.HttpStatus;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.reverseride.auth.SessionPrincipal;
import com.reverseride.service.CommuteService;
import com.reverseride.web.dto.CommuteDtos.CommuteResponse;
import com.reverseride.web.dto.CommuteDtos.CreateCommuteRequest;
import com.reverseride.web.dto.CommuteDtos.UpdateCommuteRequest;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/commutes")
public class CommuteController {

    private final CommuteService commutes;

    public CommuteController(CommuteService commutes) {
        this.commutes = commutes;
    }

    @GetMapping
    public List<CommuteResponse> list(@AuthenticationPrincipal SessionPrincipal me) {
        return commutes.list(me.userId());
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public CommuteResponse create(@AuthenticationPrincipal SessionPrincipal me, @Valid @RequestBody CreateCommuteRequest request) {
        return commutes.create(me.userId(), request);
    }

    @PatchMapping("/{commuteId}")
    public CommuteResponse update(@AuthenticationPrincipal SessionPrincipal me, @PathVariable UUID commuteId,
            @Valid @RequestBody UpdateCommuteRequest request) {
        return commutes.setActive(me.userId(), commuteId, request.active());
    }
}
