package com.reverseride.domain;

import java.time.DayOfWeek;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import jakarta.persistence.AttributeConverter;
import jakarta.persistence.Converter;

/** Stores days as "MON,TUE,WED" so the column stays portable across databases. */
@Converter
public class DaysOfWeekConverter implements AttributeConverter<List<DayOfWeek>, String> {

    @Override
    public String convertToDatabaseColumn(List<DayOfWeek> days) {
        return days.stream().sorted().map(d -> d.name().substring(0, 3)).collect(Collectors.joining(","));
    }

    @Override
    public List<DayOfWeek> convertToEntityAttribute(String column) {
        return Arrays.stream(column.split(",")).map(DaysOfWeekConverter::parse).toList();
    }

    public static DayOfWeek parse(String shortName) {
        String code = shortName.trim().toUpperCase();
        for (DayOfWeek day : DayOfWeek.values()) {
            if (day.name().startsWith(code) && code.length() == 3) {
                return day;
            }
        }
        throw new IllegalArgumentException("'" + shortName + "' is not a day code (MON..SUN)");
    }
}
