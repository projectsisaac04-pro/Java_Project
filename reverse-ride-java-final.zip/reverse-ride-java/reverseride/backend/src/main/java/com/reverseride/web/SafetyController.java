package com.reverseride.web;

import java.util.List;
import java.util.UUID;

import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.reverseride.auth.SessionPrincipal;
import com.reverseride.domain.Ride;
import com.reverseride.repository.RideRepository;
import com.reverseride.service.DriverService;
import com.reverseride.web.dto.RideDtos.SafetyLogResponse;

/**
 * Safety log boundary. No monitoring, emergency or event-recording integration exists yet, so the
 * response says so explicitly instead of implying that a quiet log means a monitored trip.
 */
@RestController
@RequestMapping("/api/safety")
public class SafetyController {

    private final RideRepository rides;
    private final DriverService drivers;

    public SafetyController(RideRepository rides, DriverService drivers) {
        this.rides = rides;
        this.drivers = drivers;
    }

    @GetMapping("/rides/{rideId}")
    public SafetyLogResponse log(@AuthenticationPrincipal SessionPrincipal me, @PathVariable UUID rideId) {
        Ride ride = rides.findById(rideId)
                .filter(r -> r.getPassengerId().equals(me.userId()) || drivers.isAssignedDriver(me.userId(), r))
                .orElseThrow(() -> ApiException.notFound("Ride"));
        return new SafetyLogResponse(false,
                "Trip monitoring and safety-event recording are not connected yet. Nothing about trip " + ride.getId().toString().substring(0, 8)
                        + " is being monitored or logged.",
                List.of());
    }
}
