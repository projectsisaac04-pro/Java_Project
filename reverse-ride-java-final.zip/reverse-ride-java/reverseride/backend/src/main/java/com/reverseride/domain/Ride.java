package com.reverseride.domain;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.Instant;
import java.util.UUID;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Version;

@Entity
@Table(name = "rides")
public class Ride {

    @Id
    private UUID id;

    @Column(name = "passenger_id", nullable = false)
    private UUID passengerId;

    @Column(nullable = false)
    private String pickup;

    @Column(nullable = false)
    private String destination;

    @Enumerated(EnumType.STRING)
    @Column(name = "vehicle_type", nullable = false)
    private VehicleType vehicleType;

    @Column(name = "passenger_count", nullable = false)
    private int passengerCount;

    @Column(name = "target_arrival")
    private Instant targetArrival;

    @Column(name = "max_fare", precision = 10, scale = 2)
    private BigDecimal maxFare;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private RideStatus status;

    @Column(name = "auction_ends_at")
    private Instant auctionEndsAt;

    @Column(name = "selected_bid_id")
    private UUID selectedBidId;

    @Column(name = "created_at", nullable = false)
    private Instant createdAt;

    @Column(name = "updated_at", nullable = false)
    private Instant updatedAt;

    @Version
    private long version;

    protected Ride() {
    }

    /** A new passenger request goes straight into an auction with a fixed bidding window. */
    public static Ride openAuction(UUID passengerId, String pickup, String destination, VehicleType vehicleType,
            int passengerCount, Instant targetArrival, BigDecimal maxFare, Duration auctionDuration, Instant now) {
        Ride ride = new Ride();
        ride.id = UUID.randomUUID();
        ride.passengerId = passengerId;
        ride.pickup = pickup;
        ride.destination = destination;
        ride.vehicleType = vehicleType;
        ride.passengerCount = passengerCount;
        ride.targetArrival = targetArrival;
        ride.maxFare = maxFare;
        ride.status = RideStatus.AUCTION;
        ride.auctionEndsAt = now.plus(auctionDuration);
        ride.createdAt = now;
        ride.updatedAt = now;
        return ride;
    }

    /** Drivers may bid only while the ride is in auction and the bidding window has not closed. */
    public boolean isAcceptingBids(Instant now) {
        return status == RideStatus.AUCTION && auctionEndsAt != null && now.isBefore(auctionEndsAt);
    }

    /**
     * Rejects a bid that cannot be placed on this ride. The bidding window closes at
     * {@link #auctionEndsAt}; bids above the passenger's fare limit are refused.
     */
    public void ensureCanReceiveBid(UUID driverId, BigDecimal amount, Instant now) {
        if (passengerId.equals(driverId)) {
            throw new RideStateException("You cannot bid on your own ride request.");
        }
        if (status != RideStatus.AUCTION) {
            throw new RideStateException("This ride is no longer taking bids (status: " + status.apiValue() + ").");
        }
        if (!isAcceptingBids(now)) {
            throw new RideStateException("Bidding for this ride closed at " + auctionEndsAt + ".");
        }
        if (maxFare != null && amount.compareTo(maxFare) > 0) {
            throw new RideStateException("Your offer is above the passenger's maximum fare of ₹" + maxFare.toPlainString() + ".");
        }
    }

    /**
     * Books the ride with the chosen bid. The passenger may choose while the ride is still in
     * auction, including after the bidding window closes, but only one bid can ever be accepted.
     */
    public void acceptBid(Bid bid, Instant now) {
        if (!id.equals(bid.getRideId())) {
            throw new IllegalArgumentException("Bid " + bid.getId() + " does not belong to ride " + id);
        }
        if (selectedBidId != null) {
            throw new RideStateException("A driver has already been chosen for this ride.");
        }
        if (status != RideStatus.AUCTION) {
            throw new RideStateException("Bids can only be accepted while the ride is in auction (status: " + status.apiValue() + ").");
        }
        selectedBidId = bid.getId();
        transitionTo(RideStatus.BOOKED, now);
    }

    public void transitionTo(RideStatus next, Instant now) {
        if (!status.canTransitionTo(next)) {
            throw new RideStateException("A ride cannot move from " + status.apiValue() + " to " + next.apiValue() + ".");
        }
        status = next;
        updatedAt = now;
    }

    public UUID getId() {
        return id;
    }

    public UUID getPassengerId() {
        return passengerId;
    }

    public String getPickup() {
        return pickup;
    }

    public String getDestination() {
        return destination;
    }

    public VehicleType getVehicleType() {
        return vehicleType;
    }

    public int getPassengerCount() {
        return passengerCount;
    }

    public Instant getTargetArrival() {
        return targetArrival;
    }

    public BigDecimal getMaxFare() {
        return maxFare;
    }

    public RideStatus getStatus() {
        return status;
    }

    public Instant getAuctionEndsAt() {
        return auctionEndsAt;
    }

    public UUID getSelectedBidId() {
        return selectedBidId;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }
}
