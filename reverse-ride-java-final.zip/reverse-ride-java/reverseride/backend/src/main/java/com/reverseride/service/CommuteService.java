package com.reverseride.service;

import java.time.Clock;
import java.time.DayOfWeek;
import java.time.LocalTime;
import java.util.List;
import java.util.UUID;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.reverseride.domain.Commute;
import com.reverseride.domain.DaysOfWeekConverter;
import com.reverseride.repository.CommuteRepository;
import com.reverseride.web.ApiException;
import com.reverseride.web.dto.CommuteDtos.CommuteResponse;
import com.reverseride.web.dto.CommuteDtos.CreateCommuteRequest;

/** Saved commutes are templates only; they never create or book rides automatically. */
@Service
public class CommuteService {

    private final CommuteRepository commutes;
    private final Clock clock;

    public CommuteService(CommuteRepository commutes, Clock clock) {
        this.commutes = commutes;
        this.clock = clock;
    }

    @Transactional(readOnly = true)
    public List<CommuteResponse> list(UUID passengerId) {
        return commutes.findByPassengerIdOrderByLabelAsc(passengerId).stream().map(CommuteResponse::from).toList();
    }

    @Transactional
    public CommuteResponse create(UUID passengerId, CreateCommuteRequest request) {
        List<DayOfWeek> days = request.daysOfWeek().stream().map(DaysOfWeekConverter::parse).distinct().sorted().toList();
        Commute commute = new Commute(passengerId, request.label().trim(), request.pickup().trim(), request.destination().trim(),
                request.vehicleType(), days, LocalTime.parse(request.departureTime()), LocalTime.parse(request.targetArrival()),
                request.maxFare(), clock.instant());
        return CommuteResponse.from(commutes.save(commute));
    }

    @Transactional
    public CommuteResponse setActive(UUID passengerId, UUID commuteId, boolean active) {
        Commute commute = commutes.findByIdAndPassengerId(commuteId, passengerId).orElseThrow(() -> ApiException.notFound("Commute"));
        commute.setActive(active);
        return CommuteResponse.from(commute);
    }
}
