package com.reverseride.web.dto;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;
import java.util.UUID;

import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.Future;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import com.reverseride.domain.Bid;
import com.reverseride.domain.Ride;
import com.reverseride.domain.RideStatus;
import com.reverseride.domain.VehicleType;

public final class RideDtos {

    private RideDtos() {
    }

    public record CreateRideRequest(
            @NotBlank(message = "Add a pickup point") @Size(max = 300) String pickup,
            @NotBlank(message = "Add a destination") @Size(max = 300) String destination,
            @NotNull(message = "Choose a vehicle type") VehicleType vehicleType,
            @Min(value = 1, message = "At least 1 passenger") @Max(value = 8, message = "At most 8 passengers") Integer passengerCount,
            @Future(message = "Target arrival must be in the future") Instant targetArrival,
            @DecimalMin(value = "1.00", message = "Maximum fare must be at least ₹1")
            @DecimalMax(value = "100000.00", message = "Maximum fare must be at most ₹1,00,000")
            @Digits(integer = 6, fraction = 2, message = "Use at most 2 decimal places") BigDecimal maxFare,
            Integer auctionDurationSeconds) {
    }

    public record RideResponse(
            UUID id,
            String pickup,
            String destination,
            VehicleType vehicleType,
            int passengerCount,
            Instant targetArrival,
            BigDecimal maxFare,
            RideStatus status,
            Instant auctionEndsAt,
            boolean acceptingBids,
            UUID selectedBidId,
            long bidCount,
            Instant createdAt) {

        public static RideResponse from(Ride ride, long bidCount, Instant now) {
            return new RideResponse(ride.getId(), ride.getPickup(), ride.getDestination(), ride.getVehicleType(),
                    ride.getPassengerCount(), ride.getTargetArrival(), ride.getMaxFare(), ride.getStatus(),
                    ride.getAuctionEndsAt(), ride.isAcceptingBids(now), ride.getSelectedBidId(), bidCount, ride.getCreatedAt());
        }
    }

    public record PlaceBidRequest(
            @NotBlank(message = "Describe your vehicle") @Size(max = 120) String vehicleLabel,
            @NotNull(message = "Enter your offer")
            @DecimalMin(value = "1.00", message = "Offer must be at least ₹1")
            @DecimalMax(value = "100000.00", message = "Offer must be at most ₹1,00,000")
            @Digits(integer = 6, fraction = 2, message = "Use at most 2 decimal places") BigDecimal amount,
            @NotNull(message = "Enter your ETA")
            @Min(value = 0, message = "ETA cannot be negative") @Max(value = 180, message = "ETA must be 180 minutes or less") Integer etaMinutes,
            @NotNull(message = "Enter your rating")
            @DecimalMin(value = "0.0", message = "Rating must be between 0 and 5")
            @DecimalMax(value = "5.0", message = "Rating must be between 0 and 5")
            @Digits(integer = 1, fraction = 1, message = "Use one decimal place") BigDecimal rating,
            @NotNull(message = "Enter your completion rate")
            @DecimalMin(value = "0", message = "Completion rate must be between 0 and 100")
            @DecimalMax(value = "100", message = "Completion rate must be between 0 and 100")
            @Digits(integer = 3, fraction = 2, message = "Use at most 2 decimal places") BigDecimal completionRate,
            @NotNull(message = "Enter your trust score")
            @DecimalMin(value = "0", message = "Trust score must be between 0 and 100")
            @DecimalMax(value = "100", message = "Trust score must be between 0 and 100")
            @Digits(integer = 3, fraction = 2, message = "Use at most 2 decimal places") BigDecimal trustScore) {
    }

    public record ScoreComponentResponse(String factor, String label, BigDecimal weight, BigDecimal score, BigDecimal contribution) {
    }

    public record ValueScoreResponse(BigDecimal total, List<ScoreComponentResponse> components) {
    }

    public record BidResponse(
            UUID id,
            UUID rideId,
            String driverName,
            String vehicleLabel,
            BigDecimal amount,
            int etaMinutes,
            BigDecimal rating,
            BigDecimal completionRate,
            BigDecimal trustScore,
            Instant createdAt,
            boolean selected,
            ValueScoreResponse valueScore) {
    }

    /** What a driver sees about an open request. The passenger's identity is not shared. */
    public record OpenRideResponse(
            UUID id,
            String pickup,
            String destination,
            VehicleType vehicleType,
            int passengerCount,
            Instant targetArrival,
            BigDecimal maxFare,
            Instant auctionEndsAt,
            long bidCount,
            BigDecimal myBidAmount) {

        public static OpenRideResponse from(Ride ride, long bidCount, Bid myBid) {
            return new OpenRideResponse(ride.getId(), ride.getPickup(), ride.getDestination(), ride.getVehicleType(),
                    ride.getPassengerCount(), ride.getTargetArrival(), ride.getMaxFare(), ride.getAuctionEndsAt(), bidCount,
                    myBid == null ? null : myBid.getAmount());
        }
    }

    public record DriverTripResponse(
            UUID id,
            String pickup,
            String destination,
            VehicleType vehicleType,
            int passengerCount,
            Instant targetArrival,
            RideStatus status,
            BigDecimal agreedAmount,
            int etaMinutes,
            String vehicleLabel,
            Instant createdAt) {

        public static DriverTripResponse from(Ride ride, Bid bid) {
            return new DriverTripResponse(ride.getId(), ride.getPickup(), ride.getDestination(), ride.getVehicleType(),
                    ride.getPassengerCount(), ride.getTargetArrival(), ride.getStatus(), bid.getAmount(), bid.getEtaMinutes(),
                    bid.getVehicleLabel(), ride.getCreatedAt());
        }
    }

    public record SuggestedBidResponse(BigDecimal operatingCost, BigDecimal multiplier, BigDecimal suggestedBid, String note) {
    }

    /** Fare breakdown. All figures are null while no routing/traffic/pricing provider is configured. */
    public record FareExplanationResponse(
            boolean available,
            String reason,
            BigDecimal estimatedTotal,
            BigDecimal distanceKm,
            BigDecimal trafficComponent,
            BigDecimal demandComponent,
            BigDecimal timeComponent,
            Integer estimatedMinutes) {
    }

    public record SafetyEventResponse(UUID id, String type, String severity, String message, Instant createdAt) {
    }

    public record SafetyLogResponse(boolean available, String reason, List<SafetyEventResponse> events) {
    }

    public record DashboardSummaryResponse(long activeRides, long completedRides, long savedCommutes, BigDecimal passengerScore) {
    }
}
