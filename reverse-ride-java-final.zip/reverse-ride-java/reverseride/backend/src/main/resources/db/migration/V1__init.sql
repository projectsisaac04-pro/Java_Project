-- ReverseRide initial schema. No seed data: the marketplace starts empty.

CREATE TABLE users (
    id              UUID                     PRIMARY KEY,
    google_subject  VARCHAR(255)             NOT NULL,
    email           VARCHAR(320)             NOT NULL,
    display_name    VARCHAR(200)             NOT NULL,
    picture_url     VARCHAR(1000),
    created_at      TIMESTAMP WITH TIME ZONE NOT NULL,
    last_login_at   TIMESTAMP WITH TIME ZONE NOT NULL,
    CONSTRAINT uq_users_google_subject UNIQUE (google_subject)
);

CREATE TABLE user_roles (
    user_id  UUID        NOT NULL REFERENCES users (id) ON DELETE CASCADE,
    role     VARCHAR(20) NOT NULL,
    PRIMARY KEY (user_id, role),
    CONSTRAINT ck_user_roles_role CHECK (role IN ('PASSENGER', 'DRIVER'))
);

CREATE TABLE rides (
    id               UUID                     PRIMARY KEY,
    passenger_id     UUID                     NOT NULL REFERENCES users (id),
    pickup           VARCHAR(300)             NOT NULL,
    destination      VARCHAR(300)             NOT NULL,
    vehicle_type     VARCHAR(20)              NOT NULL,
    passenger_count  INTEGER                  NOT NULL,
    target_arrival   TIMESTAMP WITH TIME ZONE,
    max_fare         NUMERIC(10, 2),
    status           VARCHAR(20)              NOT NULL,
    auction_ends_at  TIMESTAMP WITH TIME ZONE,
    selected_bid_id  UUID,
    created_at       TIMESTAMP WITH TIME ZONE NOT NULL,
    updated_at       TIMESTAMP WITH TIME ZONE NOT NULL,
    version          BIGINT                   NOT NULL DEFAULT 0,
    CONSTRAINT ck_rides_vehicle_type CHECK (vehicle_type IN ('BIKE', 'AUTO', 'CAR', 'PREMIUM')),
    CONSTRAINT ck_rides_status CHECK (status IN ('DRAFT', 'AUCTION', 'BOOKED', 'ACTIVE', 'COMPLETED', 'CANCELLED')),
    CONSTRAINT ck_rides_passenger_count CHECK (passenger_count BETWEEN 1 AND 8),
    CONSTRAINT ck_rides_max_fare CHECK (max_fare IS NULL OR max_fare > 0),
    CONSTRAINT ck_rides_auction_end CHECK (status <> 'AUCTION' OR auction_ends_at IS NOT NULL)
);

CREATE INDEX idx_rides_passenger_created ON rides (passenger_id, created_at);
CREATE INDEX idx_rides_status_auction_end ON rides (status, auction_ends_at);

CREATE TABLE bids (
    id               UUID                     PRIMARY KEY,
    ride_id          UUID                     NOT NULL REFERENCES rides (id) ON DELETE CASCADE,
    driver_id        UUID                     NOT NULL REFERENCES users (id),
    driver_name      VARCHAR(200)             NOT NULL,
    vehicle_label    VARCHAR(120)             NOT NULL,
    amount           NUMERIC(10, 2)           NOT NULL,
    eta_minutes      INTEGER                  NOT NULL,
    rating           NUMERIC(2, 1)            NOT NULL,
    completion_rate  NUMERIC(5, 2)            NOT NULL,
    trust_score      NUMERIC(5, 2)            NOT NULL,
    created_at       TIMESTAMP WITH TIME ZONE NOT NULL,
    CONSTRAINT uq_bids_ride_driver UNIQUE (ride_id, driver_id),
    CONSTRAINT ck_bids_amount CHECK (amount > 0),
    CONSTRAINT ck_bids_eta CHECK (eta_minutes BETWEEN 0 AND 180),
    CONSTRAINT ck_bids_rating CHECK (rating BETWEEN 0 AND 5),
    CONSTRAINT ck_bids_completion CHECK (completion_rate BETWEEN 0 AND 100),
    CONSTRAINT ck_bids_trust CHECK (trust_score BETWEEN 0 AND 100)
);

CREATE INDEX idx_bids_driver ON bids (driver_id);

ALTER TABLE rides
    ADD CONSTRAINT fk_rides_selected_bid FOREIGN KEY (selected_bid_id) REFERENCES bids (id);

CREATE TABLE commutes (
    id               UUID                     PRIMARY KEY,
    passenger_id     UUID                     NOT NULL REFERENCES users (id),
    label            VARCHAR(120)             NOT NULL,
    pickup           VARCHAR(300)             NOT NULL,
    destination      VARCHAR(300)             NOT NULL,
    vehicle_type     VARCHAR(20)              NOT NULL,
    days_of_week     VARCHAR(40)              NOT NULL,
    departure_time   TIME                     NOT NULL,
    target_arrival   TIME                     NOT NULL,
    max_fare         NUMERIC(10, 2)           NOT NULL,
    active           BOOLEAN                  NOT NULL DEFAULT TRUE,
    created_at       TIMESTAMP WITH TIME ZONE NOT NULL,
    CONSTRAINT ck_commutes_vehicle_type CHECK (vehicle_type IN ('BIKE', 'AUTO', 'CAR', 'PREMIUM')),
    CONSTRAINT ck_commutes_max_fare CHECK (max_fare > 0),
    CONSTRAINT ck_commutes_days CHECK (days_of_week <> '')
);

CREATE INDEX idx_commutes_passenger ON commutes (passenger_id);
