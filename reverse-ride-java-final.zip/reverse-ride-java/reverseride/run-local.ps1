<#
  ReverseRide - start the Java API and the website together on Windows.

  Usage (from the reverseride folder, e.g. in the VS Code terminal):
      .\run.cmd               start everything
      .\run.cmd -Check        only check your setup, start nothing

  Settings are read from reverseride\.env (copy .env.example to .env and fill it in).
  Press Ctrl+C to stop both servers.
#>
param(
    [switch]$Check,
    [switch]$NoBrowser
)

$ErrorActionPreference = 'Stop'
$Root = $PSScriptRoot
$Backend = Join-Path $Root 'backend'
$Frontend = Join-Path $Root 'frontend'

function Info($msg) { Write-Host "  $msg" }
function Ok($msg) { Write-Host "  [ok]   $msg" -ForegroundColor Green }
function Warn($msg) { Write-Host "  [warn] $msg" -ForegroundColor Yellow }
function Fail($msg) { Write-Host "  [fail] $msg" -ForegroundColor Red; exit 1 }

Write-Host ''
Write-Host 'ReverseRide local launcher' -ForegroundColor Cyan
Write-Host ''

# --- 1. Load settings from .env (values already set in the terminal win) ---
$envFile = Join-Path $Root '.env'
if (Test-Path $envFile) {
    foreach ($line in Get-Content $envFile) {
        if ($line -match '^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$' -and -not $line.TrimStart().StartsWith('#')) {
            $name = $Matches[1]; $value = $Matches[2].Trim('"').Trim("'")
            if ($value -ne '' -and -not [Environment]::GetEnvironmentVariable($name)) {
                [Environment]::SetEnvironmentVariable($name, $value)
            }
        }
    }
    Ok "Loaded settings from .env"
} else {
    Warn "No .env file. Copy .env.example to .env and fill it in to skip the questions below."
}

# --- 2. Java 21+ ---
function Get-JavaMajor($javaExe) {
    if (-not (Test-Path $javaExe)) { return 0 }
    # java prints its version on stderr; read it through cmd so PowerShell does not treat it as an error.
    $out = cmd /c "`"$javaExe`" -version 2>&1" | Select-Object -First 1
    if ("$out" -match 'version "(\d+)') { return [int]$Matches[1] }
    return 0
}
$javaHome = $env:JAVA_HOME
if (-not $javaHome -or (Get-JavaMajor (Join-Path $javaHome 'bin\java.exe')) -lt 21) {
    $candidate = Get-ChildItem 'C:\Program Files\Java', 'C:\Program Files\Eclipse Adoptium', 'C:\Program Files\Microsoft' -Directory -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -like 'jdk*' } |
        Where-Object { (Get-JavaMajor (Join-Path $_.FullName 'bin\java.exe')) -ge 21 } |
        Sort-Object Name | Select-Object -First 1
    if (-not $candidate) { Fail "Java 21 or newer was not found. Install a JDK 21 and try again." }
    $env:JAVA_HOME = $candidate.FullName
}
Ok "Java: $env:JAVA_HOME"

# --- 3. Node.js and pnpm ---
if (-not (Get-Command node -ErrorAction SilentlyContinue)) { Fail "Node.js was not found. Install Node.js 20+ from https://nodejs.org" }
if (-not (Get-Command pnpm -ErrorAction SilentlyContinue)) { Fail "pnpm was not found. Run:  npm install -g pnpm" }
Ok "Node $(node -v), pnpm $(pnpm -v)"

# --- 4. Free ports ---
function Test-PortFree($port) {
    -not (Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue)
}
if (-not $env:PORT) {
    $env:PORT = (8080..8090 | Where-Object { Test-PortFree $_ } | Select-Object -First 1)
    if (-not $env:PORT) { Fail "Ports 8080-8090 are all in use. Set PORT in .env." }
} elseif (-not (Test-PortFree ([int]$env:PORT))) {
    Fail "Port $env:PORT (API) is already in use. Change PORT in .env."
}
$apiPort = [int]$env:PORT
Ok "API port: $apiPort"
if (-not (Test-PortFree 5173)) { Fail "Port 5173 (website) is already in use. Close the other program or dev server." }
Ok "Website port: 5173"

# --- 5. Database settings ---
if (-not $env:DATABASE_URL) { $env:DATABASE_URL = 'jdbc:postgresql://localhost:5432/reverseride' }
if (-not $env:DATABASE_USERNAME) { $env:DATABASE_USERNAME = 'postgres' }
if (-not $env:DATABASE_PASSWORD -and -not $Check) {
    $secure = Read-Host "  PostgreSQL password for user '$env:DATABASE_USERNAME'" -AsSecureString
    $env:DATABASE_PASSWORD = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure))
}
Ok "Database: $env:DATABASE_URL (user $env:DATABASE_USERNAME)"

# Create the database if it does not exist yet (needs psql; tables are created by the API itself).
$psql = (Get-Command psql -ErrorAction SilentlyContinue).Source
if (-not $psql) {
    $psql = Get-ChildItem 'C:\Program Files\PostgreSQL\*\bin\psql.exe' -ErrorAction SilentlyContinue | Sort-Object FullName -Descending | Select-Object -First 1 -ExpandProperty FullName
}
if ($env:DATABASE_URL -match '^jdbc:postgresql://([^/:?]+)(?::(\d+))?/([^?]+)') {
    $dbHost = $Matches[1]; $dbPort = if ($Matches[2]) { $Matches[2] } else { '5432' }; $dbName = $Matches[3]
    if ($psql -and -not $Check) {
        $env:PGPASSWORD = $env:DATABASE_PASSWORD
        try {
            $exists = & $psql -h $dbHost -p $dbPort -U $env:DATABASE_USERNAME -d postgres -tAc "SELECT 1 FROM pg_database WHERE datname = '$dbName'" 2>&1
            if ($LASTEXITCODE -ne 0) { Fail "Could not connect to PostgreSQL: $exists" }
            if ("$exists".Trim() -ne '1') {
                & $psql -h $dbHost -p $dbPort -U $env:DATABASE_USERNAME -d postgres -c "CREATE DATABASE `"$dbName`"" | Out-Null
                Ok "Created database '$dbName'"
            } else {
                Ok "Database '$dbName' exists"
            }
        } finally {
            Remove-Item Env:PGPASSWORD -ErrorAction SilentlyContinue
        }
    } elseif (-not $psql) {
        Warn "psql not found, so the database was not checked. Make sure '$dbName' exists."
    }
} else {
    Fail "DATABASE_URL must look like jdbc:postgresql://host:5432/dbname"
}

# --- 6. Google and session settings ---
if ($env:GOOGLE_CLIENT_ID) { Ok "Google client ID is set" }
else { Warn "GOOGLE_CLIENT_ID is not set. The site will start, but Google sign-in stays disabled (see README step 1)." }
if (-not $env:SESSION_SECRET) {
    $bytes = New-Object byte[] 48
    [Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($bytes)
    $env:SESSION_SECRET = [Convert]::ToBase64String($bytes)
    Warn "SESSION_SECRET not set; using a temporary one (you will be signed out when you restart)."
}
$env:API_PROXY_TARGET = "http://localhost:$apiPort"

if ($Check) {
    Write-Host ''
    Write-Host 'Setup check finished. Run .\run.cmd without -Check to start.' -ForegroundColor Cyan
    exit 0
}

# --- 7. Install website packages on first run ---
if (-not (Test-Path (Join-Path $Frontend 'node_modules'))) {
    Info 'Installing website packages (first run only)...'
    Push-Location $Frontend
    try { pnpm install; if ($LASTEXITCODE -ne 0) { Fail 'pnpm install failed' } } finally { Pop-Location }
}

# --- 8. Start the API, wait until healthy, then start the website ---
Write-Host ''
Info "Starting the Java API on http://localhost:$apiPort (the first start downloads Maven packages and can take a few minutes)..."
$api = Start-Process -FilePath (Join-Path $Backend 'mvnw.cmd') -ArgumentList '-q', 'spring-boot:run' -WorkingDirectory $Backend -NoNewWindow -PassThru

function Stop-Api {
    if ($api -and -not $api.HasExited) {
        Info 'Stopping the Java API...'
        & taskkill /PID $api.Id /T /F 2>&1 | Out-Null
    }
}

try {
    $deadline = (Get-Date).AddMinutes(6)
    $healthy = $false
    while ((Get-Date) -lt $deadline) {
        if ($api.HasExited) { Fail 'The Java API stopped while starting. Read the error above (often a wrong database password).' }
        try {
            $r = Invoke-WebRequest -Uri "http://localhost:$apiPort/api/health" -UseBasicParsing -TimeoutSec 2
            if ($r.StatusCode -eq 200) { $healthy = $true; break }
        } catch { }
        Start-Sleep -Seconds 2
    }
    if (-not $healthy) { Fail 'The Java API did not become ready within 6 minutes.' }
    Ok "API is running on http://localhost:$apiPort"

    Write-Host ''
    Write-Host '  ReverseRide is starting at http://localhost:5173   (Ctrl+C stops everything)' -ForegroundColor Cyan
    Write-Host ''
    if (-not $NoBrowser) {
        Start-Job -ScriptBlock { Start-Sleep -Seconds 4; Start-Process 'http://localhost:5173' } | Out-Null
    }
    Push-Location $Frontend
    try { pnpm dev } finally { Pop-Location }
}
finally {
    Stop-Api
}
