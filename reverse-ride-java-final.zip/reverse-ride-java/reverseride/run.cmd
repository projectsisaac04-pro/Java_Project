@echo off
rem Starts ReverseRide (Java API + website). Works in VS Code's terminal, PowerShell or Command Prompt.
rem Runs the PowerShell launcher without changing your system's script execution policy.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run-local.ps1" %*
